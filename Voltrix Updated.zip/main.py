# Modifying is not allowed
# All rights reserverd
import voltrix

if __name__ == "__main__":
    voltrix.start_bot()